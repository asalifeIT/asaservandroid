function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["aduanlaundry-aduanlaundry-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/aduanlaundry/aduanlaundry.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/aduanlaundry/aduanlaundry.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAduanlaundryAduanlaundryPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = " <ion-content>\r\n  <ion-header class=\"ion-no-border\">\r\n    <ion-item lines=\"none\">\r\n      <ion-buttons slot=\"start\">\r\n        <ion-button (click)=\"util.openSideMenu()\">\r\n          <ion-icon name=\"menu\"></ion-icon>\r\n        </ion-button>\r\n      </ion-buttons>\r\n      <ion-label color=\"dark\">\r\n      Form Aduan Laundry\r\n    </ion-label>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-icon (click)=\"onBack()\" name=\"arrow-undo\"></ion-icon>\r\n    </ion-buttons>\r\n    </ion-item>\r\n   </ion-header>\r\n   \r\n  <div class=\"main_content ion-padding\">\r\n\r\n    <ion-label class=\"sub_heading\">Deskripsi</ion-label>\r\n    <ion-label class=\"sub_heading\">Silahkan mengisi aduan apabila ditemukan hal-hal yang tidak berkenan</ion-label>\r\n\r\n  <div>\r\n  <form class=\"container\" [formGroup]=\"FormAduanLaundry\" (ngSubmit)=\"submitAduanLaundry()\">\r\n    <ion-item>  \r\n    <ion-label>* Pilihan Mess </ion-label>\r\n        <ion-select formControlName=\"mess\">\r\n          <ion-select-option ngvalue=\"Mess Cheerful\">Mess Cheerful</ion-select-option>\r\n          <ion-select-option ngvalue=\"Mess Funtastik\">Mess Funtastik</ion-select-option>\r\n          <ion-select-option ngvalue=\"Mess Joyfull\">Mess Joyfull</ion-select-option>\r\n          <ion-select-option ngvalue=\"Mess Safety\">Mess Safety</ion-select-option>\r\n          <ion-select-option ngvalue=\"Mess Integrity\">Mess Integrity</ion-select-option> \r\n          <ion-select-option ngvalue=\"Mess Synergy\">Mess Synergy</ion-select-option>\r\n          <ion-select-option ngvalue=\"Mess Greatful\">Mess Greatful</ion-select-option>\r\n          <ion-select-option ngvalue=\"Mess Happyness\">Mess Happyness</ion-select-option>\r\n          <ion-select-option ngvalue=\"Mess Powerfull\">Mess Powerfull</ion-select-option>\r\n        </ion-select></ion-item>  \r\n      <ion-item><ion-input type=\"text\" placeholder=\"2. Masukkan No Kamar\" formControlName=\"no_kamar\"></ion-input></ion-item>\r\n      <ion-item> <ion-input type=\"text\" placeholder=\"3. Masukkan Jenis Pakaian\" formControlName=\"jenis_pakaian\"></ion-input></ion-item>\r\n        <ion-item><ion-input type=\"text\" placeholder=\"4. Masukkan Jenis Deviasi\" formControlName=\"jenis_deviasi\"></ion-input></ion-item>\r\n          <ion-item>\r\n            <ion-label>Klik Tanggal</ion-label>\r\n            <ion-datetime value=\"2022-02-20\" placeholder=\"Select Date\" formControlName=\"tanggal_loundry\"></ion-datetime>  \r\n        </ion-item>\r\n         <ion-button type=\"submit\" expand=\"block\" color=\"primary\">Submit</ion-button>\r\n      </form>\r\n    </div>\r\n  </div>\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/aduanlaundry/aduanlaundry-routing.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/aduanlaundry/aduanlaundry-routing.module.ts ***!
    \*************************************************************/

  /*! exports provided: AduanlaundryPageRoutingModule */

  /***/
  function srcAppAduanlaundryAduanlaundryRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AduanlaundryPageRoutingModule", function () {
      return AduanlaundryPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _aduanlaundry_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./aduanlaundry.page */
    "./src/app/aduanlaundry/aduanlaundry.page.ts");

    var routes = [{
      path: '',
      component: _aduanlaundry_page__WEBPACK_IMPORTED_MODULE_3__["AduanlaundryPage"]
    }];

    var AduanlaundryPageRoutingModule = /*#__PURE__*/_createClass(function AduanlaundryPageRoutingModule() {
      _classCallCheck(this, AduanlaundryPageRoutingModule);
    });

    AduanlaundryPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AduanlaundryPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/aduanlaundry/aduanlaundry.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/aduanlaundry/aduanlaundry.module.ts ***!
    \*****************************************************/

  /*! exports provided: AduanlaundryPageModule */

  /***/
  function srcAppAduanlaundryAduanlaundryModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AduanlaundryPageModule", function () {
      return AduanlaundryPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _aduanlaundry_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./aduanlaundry-routing.module */
    "./src/app/aduanlaundry/aduanlaundry-routing.module.ts");
    /* harmony import */


    var _aduanlaundry_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./aduanlaundry.page */
    "./src/app/aduanlaundry/aduanlaundry.page.ts");

    var AduanlaundryPageModule = /*#__PURE__*/_createClass(function AduanlaundryPageModule() {
      _classCallCheck(this, AduanlaundryPageModule);
    });

    AduanlaundryPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _aduanlaundry_routing_module__WEBPACK_IMPORTED_MODULE_5__["AduanlaundryPageRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]],
      declarations: [_aduanlaundry_page__WEBPACK_IMPORTED_MODULE_6__["AduanlaundryPage"]]
    })], AduanlaundryPageModule);
    /***/
  },

  /***/
  "./src/app/aduanlaundry/aduanlaundry.page.scss":
  /*!*****************************************************!*\
    !*** ./src/app/aduanlaundry/aduanlaundry.page.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppAduanlaundryAduanlaundryPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "@charset \"UTF-8\";\n/*\n  Authors : bunchdevelopers (Rahul Jograna)\n  Website : https://bunchdevelopers.com/\n  App Name : ionic6Template Pack\n  This App Template Source code is licensed as per the\n  terms found in the Website https://bunchdevelopers.com/license\n  Copyright and Good Faith Purchasers © 2021-present bunchdevelopers.\n*/\n.main-header {\n  height: 26vh;\n  width: 150%;\n  background: linear-gradient(45deg, var(--ion-color-tertiary) 30%, var(--ion-color-primary) 100%);\n  box-shadow: 0 1px 30px var(--ion-color-light);\n  border-radius: 0 0 50% 50%;\n  margin-left: -14vh;\n  margin-top: -60px;\n}\n.bg_img {\n  height: 250px;\n  width: 100%;\n  background-position: center center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n.bg_img .back_div {\n  width: 100%;\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n  padding-top: 40px;\n}\n.bg_img .back_div ion-buttons {\n  padding: 5px 2px 5px 2px;\n  margin: 10px;\n}\n.bg_img .back_div ion-buttons ion-button {\n  height: 40px;\n  width: 40px;\n  border: 1px solid #0a0000;\n  --border-radius: 50%;\n  border-radius: 50%;\n}\n.bg_img .back_div ion-buttons ion-button ion-icon {\n  color: #030000;\n}\n.bg_img .back_div .btn ion-button {\n  border: none;\n}\n.title {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n  position: relative;\n}\n.title .sub_heading {\n  font-family: \"regular\";\n  font-size: 15px;\n}\n.title .sub_ttl {\n  position: absolute;\n  right: 5px;\n  top: 45px;\n  font-size: 13px;\n  color: #0b0501;\n}\n.rate ion-icon {\n  margin-right: 5px;\n  font-size: 20px;\n  color: #ff7c31;\n}\n.sub_heading {\n  font-family: \"bold\";\n  color: #0f0e0e;\n  margin-top: 10px;\n  font-size: 13px;\n}\n.main_title {\n  font-family: \"bold\";\n  color: black;\n  font-size: 18px;\n  margin-top: 20px;\n}\np {\n  font-family: \"regular\";\n}\nion-item {\n  --background: transparent;\n  background: #f8f9fff3;\n  padding: 10px 0px 10px 0px;\n  margin: 20px 0px 20px 0px;\n  border-radius: 10px;\n}\nion-item ion-label {\n  font-family: \"bold\";\n  font-size: 15px;\n  --background: #f8f9fff3;\n  margin-bottom: 11px;\n}\nion-item ion-select {\n  font-size: 13px;\n  --background: #f8f9fff3;\n}\nion-item ion-select ion-select-option {\n  --background: #f8f9fff3;\n}\nion-row ion-col {\n  position: relative;\n  padding: 0px;\n}\nion-row ion-col .btn {\n  display: flex;\n  flex-direction: row;\n  position: absolute;\n  bottom: 5px;\n  right: 0px;\n}\nion-row ion-col .btn ion-buttons {\n  display: flex;\n  text-align: center;\n  margin: 0px 0px 0px 0px;\n}\nion-row ion-col .btn ion-buttons ion-button {\n  background: linear-gradient(#ffa124, #ff7c31);\n  border-radius: 30%;\n  height: 35px;\n  width: 40px;\n}\nion-row ion-col .btn .label_number {\n  display: flex;\n  justify-content: center;\n}\nion-row ion-col .btn .label_number ion-button {\n  border: 1px solid #ff7c31;\n  background: #ffff;\n}\nion-row ion-col .btn .label_number ion-label {\n  color: #ff7c31;\n  font-family: \"bold\";\n}\n.content_button {\n  margin-top: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWR1YW5sYXVuZHJ5L2FkdWFubGF1bmRyeS5wYWdlLnNjc3MiLCJzcmMvYXBwL2FkdWFubGF1bmRyeS9FOlxcYXNhc2VydmFuZHJvaWQvc3JjXFxhcHBcXGFkdWFubGF1bmRyeVxcYWR1YW5sYXVuZHJ5LnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxnQkFBZ0I7QUNBaEI7Ozs7Ozs7Q0FBQTtBQVNBO0VBQ0ksWUFBQTtFQUNBLFdBQUE7RUFDQSxnR0FBQTtFQUNBLDZDQUFBO0VBQ0EsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FEQ0o7QUNDRTtFQUNJLGFBQUE7RUFDQSxXQUFBO0VBQ0Esa0NBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0FERU47QUNETTtFQUNFLFdBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0EsaUJBQUE7QURHUjtBQ0ZRO0VBQ0Usd0JBQUE7RUFDQSxZQUFBO0FESVY7QUNIVTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EseUJBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0FES1o7QUNKWTtFQUNFLGNBQUE7QURNZDtBQ0RVO0VBQ0UsWUFBQTtBREdaO0FDR0k7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSw4QkFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7QURBTjtBQ0NNO0VBQ0Usc0JBQUE7RUFDQSxlQUFBO0FEQ1I7QUNDTTtFQUNFLGtCQUFBO0VBQ0EsVUFBQTtFQUNBLFNBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtBRENSO0FDSU07RUFDRSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FERFI7QUNLSTtFQUNFLG1CQUFBO0VBQ0EsY0FBQTtFQUNBLGdCQUFBO0VBQ0EsZUFBQTtBREZOO0FDS0k7RUFDRSxtQkFBQTtFQUNBLFlBQUE7RUFDQSxlQUFBO0VBQ0EsZ0JBQUE7QURGTjtBQ0tJO0VBQ0Usc0JBQUE7QURGTjtBQ0tJO0VBQ0UseUJBQUE7RUFDQSxxQkFBQTtFQUNBLDBCQUFBO0VBQ0EseUJBQUE7RUFDQSxtQkFBQTtBREZOO0FDR007RUFDRSxtQkFBQTtFQUNBLGVBQUE7RUFDQSx1QkFBQTtFQUNBLG1CQUFBO0FERFI7QUNHTTtFQUNFLGVBQUE7RUFDQSx1QkFBQTtBRERSO0FDRVE7RUFDRSx1QkFBQTtBREFWO0FDTU07RUFDRSxrQkFBQTtFQUNBLFlBQUE7QURIUjtBQ0lRO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0JBQUE7RUFDQSxXQUFBO0VBQ0EsVUFBQTtBREZWO0FDR1U7RUFDRSxhQUFBO0VBQ0Esa0JBQUE7RUFDQSx1QkFBQTtBRERaO0FDRVk7RUFDRSw2Q0FBQTtFQUNBLGtCQUFBO0VBQ0EsWUFBQTtFQUNBLFdBQUE7QURBZDtBQ0dVO0VBQ0UsYUFBQTtFQUNBLHVCQUFBO0FERFo7QUNFWTtFQUNFLHlCQUFBO0VBQ0EsaUJBQUE7QURBZDtBQ0VZO0VBQ0UsY0FBQTtFQUNBLG1CQUFBO0FEQWQ7QUNPSTtFQUNFLGdCQUFBO0FESk4iLCJmaWxlIjoic3JjL2FwcC9hZHVhbmxhdW5kcnkvYWR1YW5sYXVuZHJ5LnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBjaGFyc2V0IFwiVVRGLThcIjtcbi8qXG4gIEF1dGhvcnMgOiBidW5jaGRldmVsb3BlcnMgKFJhaHVsIEpvZ3JhbmEpXG4gIFdlYnNpdGUgOiBodHRwczovL2J1bmNoZGV2ZWxvcGVycy5jb20vXG4gIEFwcCBOYW1lIDogaW9uaWM2VGVtcGxhdGUgUGFja1xuICBUaGlzIEFwcCBUZW1wbGF0ZSBTb3VyY2UgY29kZSBpcyBsaWNlbnNlZCBhcyBwZXIgdGhlXG4gIHRlcm1zIGZvdW5kIGluIHRoZSBXZWJzaXRlIGh0dHBzOi8vYnVuY2hkZXZlbG9wZXJzLmNvbS9saWNlbnNlXG4gIENvcHlyaWdodCBhbmQgR29vZCBGYWl0aCBQdXJjaGFzZXJzIMKpIDIwMjEtcHJlc2VudCBidW5jaGRldmVsb3BlcnMuXG4qL1xuLm1haW4taGVhZGVyIHtcbiAgaGVpZ2h0OiAyNnZoO1xuICB3aWR0aDogMTUwJTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDQ1ZGVnLCB2YXIoLS1pb24tY29sb3ItdGVydGlhcnkpIDMwJSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpIDEwMCUpO1xuICBib3gtc2hhZG93OiAwIDFweCAzMHB4IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG4gIGJvcmRlci1yYWRpdXM6IDAgMCA1MCUgNTAlO1xuICBtYXJnaW4tbGVmdDogLTE0dmg7XG4gIG1hcmdpbi10b3A6IC02MHB4O1xufVxuXG4uYmdfaW1nIHtcbiAgaGVpZ2h0OiAyNTBweDtcbiAgd2lkdGg6IDEwMCU7XG4gIGJhY2tncm91bmQtcG9zaXRpb246IGNlbnRlciBjZW50ZXI7XG4gIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XG4gIGJhY2tncm91bmQtc2l6ZTogY292ZXI7XG59XG4uYmdfaW1nIC5iYWNrX2RpdiB7XG4gIHdpZHRoOiAxMDAlO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIHBhZGRpbmctdG9wOiA0MHB4O1xufVxuLmJnX2ltZyAuYmFja19kaXYgaW9uLWJ1dHRvbnMge1xuICBwYWRkaW5nOiA1cHggMnB4IDVweCAycHg7XG4gIG1hcmdpbjogMTBweDtcbn1cbi5iZ19pbWcgLmJhY2tfZGl2IGlvbi1idXR0b25zIGlvbi1idXR0b24ge1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiA0MHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCAjMGEwMDAwO1xuICAtLWJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuLmJnX2ltZyAuYmFja19kaXYgaW9uLWJ1dHRvbnMgaW9uLWJ1dHRvbiBpb24taWNvbiB7XG4gIGNvbG9yOiAjMDMwMDAwO1xufVxuLmJnX2ltZyAuYmFja19kaXYgLmJ0biBpb24tYnV0dG9uIHtcbiAgYm9yZGVyOiBub25lO1xufVxuXG4udGl0bGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cbi50aXRsZSAuc3ViX2hlYWRpbmcge1xuICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XG4gIGZvbnQtc2l6ZTogMTVweDtcbn1cbi50aXRsZSAuc3ViX3R0bCB7XG4gIHBvc2l0aW9uOiBhYnNvbHV0ZTtcbiAgcmlnaHQ6IDVweDtcbiAgdG9wOiA0NXB4O1xuICBmb250LXNpemU6IDEzcHg7XG4gIGNvbG9yOiAjMGIwNTAxO1xufVxuXG4ucmF0ZSBpb24taWNvbiB7XG4gIG1hcmdpbi1yaWdodDogNXB4O1xuICBmb250LXNpemU6IDIwcHg7XG4gIGNvbG9yOiAjZmY3YzMxO1xufVxuXG4uc3ViX2hlYWRpbmcge1xuICBmb250LWZhbWlseTogXCJib2xkXCI7XG4gIGNvbG9yOiAjMGYwZTBlO1xuICBtYXJnaW4tdG9wOiAxMHB4O1xuICBmb250LXNpemU6IDEzcHg7XG59XG5cbi5tYWluX3RpdGxlIHtcbiAgZm9udC1mYW1pbHk6IFwiYm9sZFwiO1xuICBjb2xvcjogYmxhY2s7XG4gIGZvbnQtc2l6ZTogMThweDtcbiAgbWFyZ2luLXRvcDogMjBweDtcbn1cblxucCB7XG4gIGZvbnQtZmFtaWx5OiBcInJlZ3VsYXJcIjtcbn1cblxuaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xuICBiYWNrZ3JvdW5kOiAjZjhmOWZmZjM7XG4gIHBhZGRpbmc6IDEwcHggMHB4IDEwcHggMHB4O1xuICBtYXJnaW46IDIwcHggMHB4IDIwcHggMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuaW9uLWl0ZW0gaW9uLWxhYmVsIHtcbiAgZm9udC1mYW1pbHk6IFwiYm9sZFwiO1xuICBmb250LXNpemU6IDE1cHg7XG4gIC0tYmFja2dyb3VuZDogI2Y4ZjlmZmYzO1xuICBtYXJnaW4tYm90dG9tOiAxMXB4O1xufVxuaW9uLWl0ZW0gaW9uLXNlbGVjdCB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgLS1iYWNrZ3JvdW5kOiAjZjhmOWZmZjM7XG59XG5pb24taXRlbSBpb24tc2VsZWN0IGlvbi1zZWxlY3Qtb3B0aW9uIHtcbiAgLS1iYWNrZ3JvdW5kOiAjZjhmOWZmZjM7XG59XG5cbmlvbi1yb3cgaW9uLWNvbCB7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbiAgcGFkZGluZzogMHB4O1xufVxuaW9uLXJvdyBpb24tY29sIC5idG4ge1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGJvdHRvbTogNXB4O1xuICByaWdodDogMHB4O1xufVxuaW9uLXJvdyBpb24tY29sIC5idG4gaW9uLWJ1dHRvbnMge1xuICBkaXNwbGF5OiBmbGV4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIG1hcmdpbjogMHB4IDBweCAwcHggMHB4O1xufVxuaW9uLXJvdyBpb24tY29sIC5idG4gaW9uLWJ1dHRvbnMgaW9uLWJ1dHRvbiB7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgjZmZhMTI0LCAjZmY3YzMxKTtcbiAgYm9yZGVyLXJhZGl1czogMzAlO1xuICBoZWlnaHQ6IDM1cHg7XG4gIHdpZHRoOiA0MHB4O1xufVxuaW9uLXJvdyBpb24tY29sIC5idG4gLmxhYmVsX251bWJlciB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xufVxuaW9uLXJvdyBpb24tY29sIC5idG4gLmxhYmVsX251bWJlciBpb24tYnV0dG9uIHtcbiAgYm9yZGVyOiAxcHggc29saWQgI2ZmN2MzMTtcbiAgYmFja2dyb3VuZDogI2ZmZmY7XG59XG5pb24tcm93IGlvbi1jb2wgLmJ0biAubGFiZWxfbnVtYmVyIGlvbi1sYWJlbCB7XG4gIGNvbG9yOiAjZmY3YzMxO1xuICBmb250LWZhbWlseTogXCJib2xkXCI7XG59XG5cbi5jb250ZW50X2J1dHRvbiB7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG59IiwiLypcclxuICBBdXRob3JzIDogYnVuY2hkZXZlbG9wZXJzIChSYWh1bCBKb2dyYW5hKVxyXG4gIFdlYnNpdGUgOiBodHRwczovL2J1bmNoZGV2ZWxvcGVycy5jb20vXHJcbiAgQXBwIE5hbWUgOiBpb25pYzZUZW1wbGF0ZSBQYWNrXHJcbiAgVGhpcyBBcHAgVGVtcGxhdGUgU291cmNlIGNvZGUgaXMgbGljZW5zZWQgYXMgcGVyIHRoZVxyXG4gIHRlcm1zIGZvdW5kIGluIHRoZSBXZWJzaXRlIGh0dHBzOi8vYnVuY2hkZXZlbG9wZXJzLmNvbS9saWNlbnNlXHJcbiAgQ29weXJpZ2h0IGFuZCBHb29kIEZhaXRoIFB1cmNoYXNlcnMgwqkgMjAyMS1wcmVzZW50IGJ1bmNoZGV2ZWxvcGVycy5cclxuKi9cclxuXHJcbi5tYWluLWhlYWRlciB7XHJcbiAgICBoZWlnaHQ6MjZ2aDtcclxuICAgIHdpZHRoOiAxNTAlO1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDQ1ZGVnLCB2YXIoLS1pb24tY29sb3ItdGVydGlhcnkpIDMwJSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpIDEwMCUpO1xyXG4gICAgYm94LXNoYWRvdzogMCAxcHggMzBweCB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMCAwIDUwJSA1MCU7XHJcbiAgICBtYXJnaW4tbGVmdDogLTE0dmg7XHJcbiAgICBtYXJnaW4tdG9wOiAtNjBweDtcclxuICB9XHJcbiAgLmJnX2ltZyB7XHJcbiAgICAgIGhlaWdodDogMjUwcHg7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xyXG4gICAgICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xyXG4gICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICAgICAuYmFja19kaXYge1xyXG4gICAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICBwYWRkaW5nLXRvcDogNDBweDtcclxuICAgICAgICBpb24tYnV0dG9ucyB7XHJcbiAgICAgICAgICBwYWRkaW5nOiA1cHggMnB4IDVweCAycHg7XHJcbiAgICAgICAgICBtYXJnaW46IDEwcHg7XHJcbiAgICAgICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICAgICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgICAgICAgICB3aWR0aDogNDBweDtcclxuICAgICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgcmdiKDEwLCAwLCAwKTtcclxuICAgICAgICAgICAgLS1ib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDUwJTtcclxuICAgICAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgICAgIGNvbG9yOiByZ2IoMywgMCwgMCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgLmJ0biB7XHJcbiAgICAgICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgXHJcbiAgICAudGl0bGUge1xyXG4gICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgLnN1Yl9oZWFkaW5nIHtcclxuICAgICAgICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICB9XHJcbiAgICAgIC5zdWJfdHRsIHtcclxuICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgcmlnaHQ6IDVweDtcclxuICAgICAgICB0b3A6IDQ1cHg7XHJcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgIGNvbG9yOiAjMGIwNTAxO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuICAgIC5yYXRlIHtcclxuICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMjBweDtcclxuICAgICAgICBjb2xvcjogI2ZmN2MzMTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgXHJcbiAgICAuc3ViX2hlYWRpbmcge1xyXG4gICAgICBmb250LWZhbWlseTogXCJib2xkXCI7XHJcbiAgICAgIGNvbG9yOiAjMGYwZTBlO1xyXG4gICAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIC5tYWluX3RpdGxlIHtcclxuICAgICAgZm9udC1mYW1pbHk6IFwiYm9sZFwiO1xyXG4gICAgICBjb2xvcjogYmxhY2s7XHJcbiAgICAgIGZvbnQtc2l6ZTogMThweDtcclxuICAgICAgbWFyZ2luLXRvcDogMjBweDtcclxuICAgIH1cclxuICAgIFxyXG4gICAgcCB7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiBcInJlZ3VsYXJcIjtcclxuICAgIH1cclxuICAgIFxyXG4gICAgaW9uLWl0ZW0ge1xyXG4gICAgICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gICAgICBiYWNrZ3JvdW5kOiAjZjhmOWZmZjM7XHJcbiAgICAgIHBhZGRpbmc6IDEwcHggMHB4IDEwcHggMHB4O1xyXG4gICAgICBtYXJnaW46IDIwcHggMHB4IDIwcHggMHB4O1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBcImJvbGRcIjtcclxuICAgICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZjhmOWZmZjM7XHJcbiAgICAgICAgbWFyZ2luLWJvdHRvbTogMTFweDtcclxuICAgICAgfVxyXG4gICAgICBpb24tc2VsZWN0IHtcclxuICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZjhmOWZmZjM7XHJcbiAgICAgICAgaW9uLXNlbGVjdC1vcHRpb24ge1xyXG4gICAgICAgICAgLS1iYWNrZ3JvdW5kOiAjZjhmOWZmZjM7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGlvbi1yb3cge1xyXG4gICAgICBpb24tY29sIHtcclxuICAgICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgICAgcGFkZGluZzogMHB4O1xyXG4gICAgICAgIC5idG4ge1xyXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICAgICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgICAgICBib3R0b206IDVweDtcclxuICAgICAgICAgIHJpZ2h0OiAwcHg7XHJcbiAgICAgICAgICBpb24tYnV0dG9ucyB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgICAgbWFyZ2luOiAwcHggMHB4IDBweCAwcHg7XHJcbiAgICAgICAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgjZmZhMTI0LCAjZmY3YzMxKTtcclxuICAgICAgICAgICAgICBib3JkZXItcmFkaXVzOiAzMCU7XHJcbiAgICAgICAgICAgICAgaGVpZ2h0OiAzNXB4O1xyXG4gICAgICAgICAgICAgIHdpZHRoOiA0MHB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAubGFiZWxfbnVtYmVyIHtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkICNmZjdjMzE7XHJcbiAgICAgICAgICAgICAgYmFja2dyb3VuZDogI2ZmZmY7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW9uLWxhYmVsIHtcclxuICAgICAgICAgICAgICBjb2xvcjogI2ZmN2MzMTtcclxuICAgICAgICAgICAgICBmb250LWZhbWlseTogXCJib2xkXCI7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG4gICAgLmNvbnRlbnRfYnV0dG9uIHtcclxuICAgICAgbWFyZ2luLXRvcDogMzBweDtcclxuICAgIH1cclxuICAgICJdfQ== */";
    /***/
  },

  /***/
  "./src/app/aduanlaundry/aduanlaundry.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/aduanlaundry/aduanlaundry.page.ts ***!
    \***************************************************/

  /*! exports provided: AduanlaundryPage */

  /***/
  function srcAppAduanlaundryAduanlaundryPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AduanlaundryPage", function () {
      return AduanlaundryPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _services_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../services/service.service */
    "./src/app/services/service.service.ts");
    /* harmony import */


    var rxjs_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! rxjs/index */
    "./node_modules/rxjs/index.js");
    /* harmony import */


    var rxjs_index__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(rxjs_index__WEBPACK_IMPORTED_MODULE_6__);
    /* harmony import */


    var src_app_services_util_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! src/app/services/util.service */
    "./src/app/services/util.service.ts");

    var AduanlaundryPage = /*#__PURE__*/function () {
      function AduanlaundryPage(formBuilder, navCtrl, loadingController, modalController, platform, toastController, serviceService, router, util) {
        _classCallCheck(this, AduanlaundryPage);

        this.formBuilder = formBuilder;
        this.navCtrl = navCtrl;
        this.loadingController = loadingController;
        this.modalController = modalController;
        this.platform = platform;
        this.toastController = toastController;
        this.serviceService = serviceService;
        this.router = router;
        this.util = util;
        this.authenticationState = new rxjs_index__WEBPACK_IMPORTED_MODULE_6__["ReplaySubject"]();
        this.validations = {
          'mess': [{
            type: 'required',
            message: 'pilihan mess harus di isi'
          }],
          'no_kamar': [{
            type: 'required',
            message: 'nomor kamar harus di isi'
          }],
          'jenis_pakaian': [{
            type: 'required',
            message: 'jenis pakaian harus diisi.'
          }],
          'jenis_deviasi': [{
            type: 'required',
            message: 'jenis deviasi harus diisi.'
          }],
          'tanggal_laundry': [{
            type: 'required',
            message: 'pilihan tanggal harus diisi.'
          }]
        };
      }

      _createClass(AduanlaundryPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.FormAduanLaundry = this.formBuilder.group({
            mess: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])),
            no_kamar: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])),
            jenis_pakaian: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])),
            jenis_deviasi: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required])),
            tanggal_loundry: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required]))
          });
        }
      }, {
        key: "submitAduanLaundry",
        value: function submitAduanLaundry() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadingController.create({
                      message: 'Please wait...'
                    });

                  case 2:
                    loading = _context.sent;
                    _context.next = 5;
                    return loading.present();

                  case 5:
                    this.serviceService.submitaduanlaundry(this.FormAduanLaundry.value, 'laundry/add').subscribe(function (data) {
                      _this.presentToast("Aduan Anda Terkirim");

                      console.log(_this.FormAduanLaundry.value);

                      _this.FormAduanLaundry.reset();

                      loading.dismiss();
                    }, function (error) {
                      console.log(error);

                      _this.presentToast("Aduan Anda Terkirim");

                      console.log(_this.FormAduanLaundry.value);

                      _this.FormAduanLaundry.reset();

                      loading.dismiss();
                    });

                  case 6:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "presentToast",
        value: function presentToast(Message) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var toast;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.toastController.create({
                      message: Message,
                      duration: 2500,
                      position: "bottom"
                    });

                  case 2:
                    toast = _context2.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "onBack",
        value: function onBack() {
          this.router.navigate(['home']);
        }
      }]);

      return AduanlaundryPage;
    }();

    AduanlaundryPage.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"]
      }, {
        type: _services_service_service__WEBPACK_IMPORTED_MODULE_5__["ServiceService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"]
      }, {
        type: src_app_services_util_service__WEBPACK_IMPORTED_MODULE_7__["UtilService"]
      }];
    };

    AduanlaundryPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
      selector: 'app-aduanlaundry',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./aduanlaundry.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/aduanlaundry/aduanlaundry.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./aduanlaundry.page.scss */
      "./src/app/aduanlaundry/aduanlaundry.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"], _services_service_service__WEBPACK_IMPORTED_MODULE_5__["ServiceService"], _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"], src_app_services_util_service__WEBPACK_IMPORTED_MODULE_7__["UtilService"]])], AduanlaundryPage);
    /***/
  }
}]);
//# sourceMappingURL=aduanlaundry-aduanlaundry-module-es5.js.map