function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["home-home-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html":
  /*!***************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html ***!
    \***************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHomeHomePageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\r\n  <ion-item lines=\"none\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-button (click)=\"util.openSideMenu()\">\r\n        <ion-icon name=\"menu\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-label color=\"light\">\r\n      Menu Dashboard\r\n    </ion-label>\r\n    <ion-buttons slot=\"end\" color=\"light\">\r\n      <ion-icon (click)=\"logout()\" name=\"power-sharp\"></ion-icon>\r\n    </ion-buttons>\r\n  </ion-item>\r\n </ion-header>\r\n\r\n <ion-content [fullscreen]=\"true\" color=\"light\">\r\n  <div class=\"main-header\"></div>\r\n    <ion-grid>\r\n    <ion-note color=\"light\" class=\"ion-margin-start\">\r\n      ASA SERVICE \r\n         </ion-note><br>\r\n         <ion-note color=\"light\" class=\"ion-margin-start\">\r\n        Selamat datang! {{Username}}\r\n             </ion-note>\r\n\r\n    <ion-row>\r\n      <ion-col size=\"6\">\r\n        <ion-label>  \r\n          <ion-note color=\"light\" class=\"ion-margin-start\">\r\n          </ion-note>\r\n        </ion-label>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row class=\"ion-margin-horizontal ion-margin-top\">\r\n            <ion-col>\r\n        <ion-label color=\"light\">\r\n          <b></b>\r\n        </ion-label>\r\n      </ion-col>\r\n    </ion-row>\r\n\r\n    <ion-row class=\"ion-margin-horizontal\">\r\n      <ion-col *ngFor=\"let item of features\" size=\"6\">\r\n        <ion-card class=\"ion-text-center\">\r\n          <ion-card-header>\r\n            <div align=\"center\"  (click)=\"openRest()\" >\r\n              <ion-thumbnail [style.background]=\"item?.background\">\r\n                <img [src]=\"item?.src\" />\r\n              </ion-thumbnail>\r\n            </div>\r\n          </ion-card-header>\r\n          <ion-card-content>\r\n            <ion-label color=\"dark\">{{ item?.name }}</ion-label>\r\n           </ion-card-content>\r\n        </ion-card>\r\n      </ion-col>\r\n\r\n      <ion-col *ngFor=\"let item of laundry\" size=\"6\">\r\n        <ion-card class=\"ion-text-center\">\r\n          <ion-card-header>\r\n            <div align=\"center\"(click)=\"openLaundry()\" >\r\n              <ion-thumbnail [style.background]=\"item?.background\">\r\n                <img [src]=\"item?.src\" />\r\n              </ion-thumbnail>\r\n            </div>\r\n          </ion-card-header>\r\n          <ion-card-content>\r\n            <ion-label color=\"dark\">{{ item?.name }}</ion-label>\r\n             </ion-card-content>\r\n        </ion-card>\r\n      </ion-col>\r\n\r\n      <ion-col *ngFor=\"let item of housekeeping\" size=\"6\">\r\n        <ion-card class=\"ion-text-center\">\r\n          <ion-card-header>\r\n            <div align=\"center\"(click)=\"openHkeeping()\" >\r\n              <ion-thumbnail [style.background]=\"item?.background\">\r\n                <img [src]=\"item?.src\" />\r\n              </ion-thumbnail>\r\n            </div>\r\n          </ion-card-header>\r\n          <ion-card-content>\r\n            <ion-label color=\"dark\">{{ item?.name }}</ion-label>\r\n             </ion-card-content>\r\n        </ion-card>\r\n      </ion-col>\r\n\r\n      <ion-col *ngFor=\"let item of admaintan\" size=\"6\">\r\n        <ion-card class=\"ion-text-center\">\r\n          <ion-card-header>\r\n            <div align=\"center\"(click)=\"openAdmaintan()\" >\r\n              <ion-thumbnail [style.background]=\"item?.background\">\r\n                <img [src]=\"item?.src\" />\r\n              </ion-thumbnail>\r\n            </div>\r\n          </ion-card-header>\r\n          <ion-card-content>\r\n            <ion-label color=\"dark\">{{ item?.name }}</ion-label>\r\n             </ion-card-content>\r\n        </ion-card>\r\n      </ion-col>\r\n\r\n    </ion-row>\r\n  </ion-grid>\r\n\r\n\r\n</ion-content>\r\n";
    /***/
  },

  /***/
  "./src/app/home/home.module.ts":
  /*!*************************************!*\
    !*** ./src/app/home/home.module.ts ***!
    \*************************************/

  /*! exports provided: HomePageModule */

  /***/
  function srcAppHomeHomeModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePageModule", function () {
      return HomePageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _home_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./home.page */
    "./src/app/home/home.page.ts");

    var HomePageModule = /*#__PURE__*/_createClass(function HomePageModule() {
      _classCallCheck(this, HomePageModule);
    });

    HomePageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_4__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["IonicModule"], _angular_router__WEBPACK_IMPORTED_MODULE_5__["RouterModule"].forChild([{
        path: '',
        component: _home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]
      }])],
      declarations: [_home_page__WEBPACK_IMPORTED_MODULE_6__["HomePage"]]
    })], HomePageModule);
    /***/
  },

  /***/
  "./src/app/home/home.page.scss":
  /*!*************************************!*\
    !*** ./src/app/home/home.page.scss ***!
    \*************************************/

  /*! exports provided: default */

  /***/
  function srcAppHomeHomePageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "ion-header {\n  background: transparent;\n}\nion-header ion-label {\n  font-size: 10px;\n  font-family: \"regular\";\n}\nion-header ion-item {\n  --background: transparent;\n}\nion-header ion-item ion-avatar {\n  background: transparent;\n}\nion-content * {\n  font-family: \"regular\";\n}\nion-content .main-header {\n  height: 55vh;\n  width: 150%;\n  background: linear-gradient(90deg, var(--ion-color-tertiary) 10%, var(--ion-color-primary) 100%);\n  box-shadow: 0 1px 10px var(--ion-color-light);\n  border-radius: 0 0 50% 50%;\n  margin-left: -14vh;\n  margin-top: -60px;\n}\nion-content ion-icon {\n  width: 5px;\n  height: 5px;\n}\nion-content ion-note {\n  font-family: \"regular\";\n  font-size: 12px;\n  margin-left: 10vh;\n}\nion-content ion-grid {\n  width: 100%;\n  position: absolute;\n  top: 45px;\n  left: 0;\n  transform: translateY(10vh);\n  padding-bottom: 8vh;\n}\nion-content ion-grid ion-row ion-col ion-label ion-note {\n  font-size: 0.4rem;\n}\nion-content ion-grid ion-row ion-col ion-label ion-chip ion-label {\n  font-size: rem;\n  font-weight: regular;\n  letter-spacing: 0.5px;\n  text-shadow: 1px 1px 1px var(--ion-color-medium);\n}\nion-content ion-grid ion-row ion-col ion-label b {\n  font-size: 0.5rem;\n}\nion-content ion-grid ion-row ion-col ion-button {\n  height: 3em !important;\n  transform: translateY(10%);\n  text-transform: none;\n}\nion-content ion-grid ion-row ion-col ion-button ion-text {\n  font-size: 0.5rem;\n  font-weight: bold;\n  text-shadow: 1px 1px 1px var(--ion-color-medium);\n}\nion-content ion-grid ion-row ion-col ion-button ion-icon {\n  font-size: 1rem;\n}\nion-content ion-grid ion-row ion-col ion-card {\n  box-shadow: -1px 11px 10px -6px #206eeb;\n  border-radius: 10px !important;\n  margin: 5px 5px;\n}\nion-content ion-grid ion-row ion-col ion-card ion-thumbnail {\n  width: 10vh;\n  height: 10vh;\n  border-radius: 10px;\n}\nion-content ion-grid ion-row ion-col ion-card ion-thumbnail img {\n  width: 10vh;\n  height: 10vh;\n  transform: translateY(10%);\n}\nion-content ion-grid ion-row ion-col ion-card ion-card-content ion-label {\n  font-weight: \"regular\";\n  font-size: 15px;\n  letter-spacing: 0.1px;\n  text-shadow: 1px 1px 1px var(--ion-color-medium);\n}\nion-content ion-grid ion-list {\n  background: transparent;\n}\nion-content ion-grid ion-list ion-item {\n  width: 95%;\n  margin: auto;\n  border-radius: 5px;\n  margin-bottom: 2vh;\n}\nion-content ion-grid ion-list ion-item p {\n  font-size: 0.65rem;\n}\nion-content ion-grid ion-list ion-item ion-text {\n  font-weight: 800;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG9tZS9FOlxcYXNhc2VydmFuZHJvaWQvc3JjXFxhcHBcXGhvbWVcXGhvbWUucGFnZS5zY3NzIiwic3JjL2FwcC9ob21lL2hvbWUucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBO0VBS0UsdUJBQUE7QUNIRjtBRERFO0VBQ0UsZUFBQTtFQUNBLHNCQUFBO0FDR0o7QURBRTtFQUNFLHlCQUFBO0FDRUo7QURESTtFQUNFLHVCQUFBO0FDR047QURHRTtFQUNFLHNCQUFBO0FDQUo7QURHRTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EsZ0dBQUE7RUFDQSw2Q0FBQTtFQUNBLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBQ0RKO0FESUU7RUFDRSxVQUFBO0VBQ0EsV0FBQTtBQ0ZKO0FET0E7RUFDRSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBQ0xGO0FEUUU7RUFDRSxXQUFBO0VBQ0Esa0JBQUE7RUFDQSxTQUFBO0VBQ0EsT0FBQTtFQUNBLDJCQUFBO0VBQ0EsbUJBQUE7QUNOSjtBRFVXO0VBQ0MsaUJBQUE7QUNSWjtBRFdZO0VBQ0UsY0FBQTtFQUNBLG9CQUFBO0VBQ0EscUJBQUE7RUFDQSxnREFBQTtBQ1RkO0FEWVU7RUFDRSxpQkFBQTtBQ1ZaO0FEYVE7RUFDRSxzQkFBQTtFQUNBLDBCQUFBO0VBQ0Esb0JBQUE7QUNYVjtBRFlVO0VBQ0UsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdEQUFBO0FDVlo7QURZVTtFQUNFLGVBQUE7QUNWWjtBRGFRO0VBQ0UsdUNBQUE7RUFDQSw4QkFBQTtFQUNBLGVBQUE7QUNYVjtBRFlVO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBQ1ZaO0FEV1k7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLDBCQUFBO0FDVGQ7QURhWTtFQUNFLHNCQUFBO0VBQ0EsZUFBQTtFQUNBLHFCQUFBO0VBQ0EsZ0RBQUE7QUNYZDtBRGlCSTtFQUNFLHVCQUFBO0FDZk47QURnQk07RUFDRSxVQUFBO0VBQ0EsWUFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QUNkUjtBRGVRO0VBQ0Usa0JBQUE7QUNiVjtBRGVRO0VBQ0UsZ0JBQUE7QUNiViIsImZpbGUiOiJzcmMvYXBwL2hvbWUvaG9tZS5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJpb24taGVhZGVyIHtcclxuICBpb24tbGFiZWx7XHJcbiAgICBmb250LXNpemU6MTBweDtcclxuICAgIGZvbnQtZmFtaWx5OiBcInJlZ3VsYXJcIjtcclxuICAgfVxyXG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xyXG4gIGlvbi1pdGVtIHtcclxuICAgIC0tYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICBpb24tYXZhdGFyIHtcclxuICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICB9XHJcbiAgfVxyXG59XHJcblxyXG5pb24tY29udGVudCB7XHJcbiAgKiB7XHJcbiAgICBmb250LWZhbWlseTpcInJlZ3VsYXJcIjtcclxuICB9XHJcblxyXG4gIC5tYWluLWhlYWRlciB7XHJcbiAgICBoZWlnaHQ6IDU1dmg7XHJcbiAgICB3aWR0aDogMTUwJTtcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg5MGRlZywgdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KSAxMCUsIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAxMDAlKTtcclxuICAgIGJveC1zaGFkb3c6IDAgMXB4IDEwcHggdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDAgMCA1MCUgNTAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IC0xNHZoO1xyXG4gICAgbWFyZ2luLXRvcDogLTYwcHg7XHJcbiAgfVxyXG5cclxuICBpb24taWNvbiB7XHJcbiAgICB3aWR0aDogNXB4O1xyXG4gICAgaGVpZ2h0OjVweDtcclxuXHJcbiAgfVxyXG5cclxuXHJcbmlvbi1ub3Rle1xyXG4gIGZvbnQtZmFtaWx5OiBcInJlZ3VsYXJcIjtcclxuICBmb250LXNpemU6IDEycHg7XHJcbiAgbWFyZ2luLWxlZnQ6MTB2aDtcclxufVxyXG5cclxuICBpb24tZ3JpZCB7XHJcbiAgICB3aWR0aDogMTAwJTtcclxuICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgIHRvcDogNDVweDtcclxuICAgIGxlZnQ6IDA7XHJcbiAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMTB2aCk7XHJcbiAgICBwYWRkaW5nLWJvdHRvbTogOHZoO1xyXG4gICAgaW9uLXJvdyB7XHJcbiAgICAgIGlvbi1jb2wge1xyXG4gICAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgICAgaW9uLW5vdGUge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDAuNHJlbTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlvbi1jaGlwIHtcclxuICAgICAgICAgICAgaW9uLWxhYmVsIHtcclxuICAgICAgICAgICAgICBmb250LXNpemU6IHJlbTtcclxuICAgICAgICAgICAgICBmb250LXdlaWdodDogcmVndWxhcjtcclxuICAgICAgICAgICAgICBsZXR0ZXItc3BhY2luZzogMC41cHg7XHJcbiAgICAgICAgICAgICAgdGV4dC1zaGFkb3c6IDFweCAxcHggMXB4IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBiIHtcclxuICAgICAgICAgICAgZm9udC1zaXplOiAwLjVyZW07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgICAgaGVpZ2h0OiAzZW0gIWltcG9ydGFudDtcclxuICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgxMCUpO1xyXG4gICAgICAgICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XHJcbiAgICAgICAgICBpb24tdGV4dCB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMC41cmVtO1xyXG4gICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgICAgdGV4dC1zaGFkb3c6IDFweCAxcHggMXB4IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDFyZW07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlvbi1jYXJkIHtcclxuICAgICAgICAgIGJveC1zaGFkb3c6IC0xcHggMTFweCAxMHB4IC02cHggcmdiKDMyLCAxMTAsIDIzNSk7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICBtYXJnaW46IDVweCA1cHg7XHJcbiAgICAgICAgICBpb24tdGh1bWJuYWlsIHtcclxuICAgICAgICAgICAgd2lkdGg6MTB2aDtcclxuICAgICAgICAgICAgaGVpZ2h0OjEwdmg7XHJcbiAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgICAgICAgIGltZyB7XHJcbiAgICAgICAgICAgICAgd2lkdGg6IDEwdmg7XHJcbiAgICAgICAgICAgICAgaGVpZ2h0OjEwdmg7XHJcbiAgICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDEwJSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlvbi1jYXJkLWNvbnRlbnQge1xyXG4gICAgICAgICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiBcInJlZ3VsYXJcIjtcclxuICAgICAgICAgICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICAgICAgICAgICAgbGV0dGVyLXNwYWNpbmc6IDAuMXB4O1xyXG4gICAgICAgICAgICAgIHRleHQtc2hhZG93OiAxcHggMXB4IDFweCB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaW9uLWxpc3Qge1xyXG4gICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgaW9uLWl0ZW0ge1xyXG4gICAgICAgIHdpZHRoOiA5NSU7XHJcbiAgICAgICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgICAgICBtYXJnaW4tYm90dG9tOiAydmg7XHJcbiAgICAgICAgcCB7XHJcbiAgICAgICAgICBmb250LXNpemU6IDAuNjVyZW07XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGlvbi10ZXh0IHtcclxuICAgICAgICAgIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG59IiwiaW9uLWhlYWRlciB7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuaW9uLWhlYWRlciBpb24tbGFiZWwge1xuICBmb250LXNpemU6IDEwcHg7XG4gIGZvbnQtZmFtaWx5OiBcInJlZ3VsYXJcIjtcbn1cbmlvbi1oZWFkZXIgaW9uLWl0ZW0ge1xuICAtLWJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuaW9uLWhlYWRlciBpb24taXRlbSBpb24tYXZhdGFyIHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG5cbmlvbi1jb250ZW50ICoge1xuICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XG59XG5pb24tY29udGVudCAubWFpbi1oZWFkZXIge1xuICBoZWlnaHQ6IDU1dmg7XG4gIHdpZHRoOiAxNTAlO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeSkgMTAlLCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgMTAwJSk7XG4gIGJveC1zaGFkb3c6IDAgMXB4IDEwcHggdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgYm9yZGVyLXJhZGl1czogMCAwIDUwJSA1MCU7XG4gIG1hcmdpbi1sZWZ0OiAtMTR2aDtcbiAgbWFyZ2luLXRvcDogLTYwcHg7XG59XG5pb24tY29udGVudCBpb24taWNvbiB7XG4gIHdpZHRoOiA1cHg7XG4gIGhlaWdodDogNXB4O1xufVxuaW9uLWNvbnRlbnQgaW9uLW5vdGUge1xuICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XG4gIGZvbnQtc2l6ZTogMTJweDtcbiAgbWFyZ2luLWxlZnQ6IDEwdmg7XG59XG5pb24tY29udGVudCBpb24tZ3JpZCB7XG4gIHdpZHRoOiAxMDAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogNDVweDtcbiAgbGVmdDogMDtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDEwdmgpO1xuICBwYWRkaW5nLWJvdHRvbTogOHZoO1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLXJvdyBpb24tY29sIGlvbi1sYWJlbCBpb24tbm90ZSB7XG4gIGZvbnQtc2l6ZTogMC40cmVtO1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLXJvdyBpb24tY29sIGlvbi1sYWJlbCBpb24tY2hpcCBpb24tbGFiZWwge1xuICBmb250LXNpemU6IHJlbTtcbiAgZm9udC13ZWlnaHQ6IHJlZ3VsYXI7XG4gIGxldHRlci1zcGFjaW5nOiAwLjVweDtcbiAgdGV4dC1zaGFkb3c6IDFweCAxcHggMXB4IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLXJvdyBpb24tY29sIGlvbi1sYWJlbCBiIHtcbiAgZm9udC1zaXplOiAwLjVyZW07XG59XG5pb24tY29udGVudCBpb24tZ3JpZCBpb24tcm93IGlvbi1jb2wgaW9uLWJ1dHRvbiB7XG4gIGhlaWdodDogM2VtICFpbXBvcnRhbnQ7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgxMCUpO1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1yb3cgaW9uLWNvbCBpb24tYnV0dG9uIGlvbi10ZXh0IHtcbiAgZm9udC1zaXplOiAwLjVyZW07XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB0ZXh0LXNoYWRvdzogMXB4IDFweCAxcHggdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG59XG5pb24tY29udGVudCBpb24tZ3JpZCBpb24tcm93IGlvbi1jb2wgaW9uLWJ1dHRvbiBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMXJlbTtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1yb3cgaW9uLWNvbCBpb24tY2FyZCB7XG4gIGJveC1zaGFkb3c6IC0xcHggMTFweCAxMHB4IC02cHggIzIwNmVlYjtcbiAgYm9yZGVyLXJhZGl1czogMTBweCAhaW1wb3J0YW50O1xuICBtYXJnaW46IDVweCA1cHg7XG59XG5pb24tY29udGVudCBpb24tZ3JpZCBpb24tcm93IGlvbi1jb2wgaW9uLWNhcmQgaW9uLXRodW1ibmFpbCB7XG4gIHdpZHRoOiAxMHZoO1xuICBoZWlnaHQ6IDEwdmg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5pb24tY29udGVudCBpb24tZ3JpZCBpb24tcm93IGlvbi1jb2wgaW9uLWNhcmQgaW9uLXRodW1ibmFpbCBpbWcge1xuICB3aWR0aDogMTB2aDtcbiAgaGVpZ2h0OiAxMHZoO1xuICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMTAlKTtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1yb3cgaW9uLWNvbCBpb24tY2FyZCBpb24tY2FyZC1jb250ZW50IGlvbi1sYWJlbCB7XG4gIGZvbnQtd2VpZ2h0OiBcInJlZ3VsYXJcIjtcbiAgZm9udC1zaXplOiAxNXB4O1xuICBsZXR0ZXItc3BhY2luZzogMC4xcHg7XG4gIHRleHQtc2hhZG93OiAxcHggMXB4IDFweCB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1saXN0IHtcbiAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XG59XG5pb24tY29udGVudCBpb24tZ3JpZCBpb24tbGlzdCBpb24taXRlbSB7XG4gIHdpZHRoOiA5NSU7XG4gIG1hcmdpbjogYXV0bztcbiAgYm9yZGVyLXJhZGl1czogNXB4O1xuICBtYXJnaW4tYm90dG9tOiAydmg7XG59XG5pb24tY29udGVudCBpb24tZ3JpZCBpb24tbGlzdCBpb24taXRlbSBwIHtcbiAgZm9udC1zaXplOiAwLjY1cmVtO1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLWxpc3QgaW9uLWl0ZW0gaW9uLXRleHQge1xuICBmb250LXdlaWdodDogODAwO1xufSJdfQ== */";
    /***/
  },

  /***/
  "./src/app/home/home.page.ts":
  /*!***********************************!*\
    !*** ./src/app/home/home.page.ts ***!
    \***********************************/

  /*! exports provided: HomePage */

  /***/
  function srcAppHomeHomePageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HomePage", function () {
      return HomePage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _services_service_service__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ../services/service.service */
    "./src/app/services/service.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var src_app_services_util_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! src/app/services/util.service */
    "./src/app/services/util.service.ts");

    var HomePage = /*#__PURE__*/function () {
      function HomePage(loadingController, serviceService, router, util) {
        _classCallCheck(this, HomePage);

        this.loadingController = loadingController;
        this.serviceService = serviceService;
        this.router = router;
        this.util = util;
        this.features = [{
          id: 1,
          name: 'Catering',
          src: 'assets/svg/dining.svg',
          background: '',
          page: ''
        }];
        this.laundry = [{
          id: 1,
          name: 'Laundry',
          src: 'assets/svg/washing-machine.svg',
          background: '',
          page: ''
        }];
        this.housekeeping = [{
          id: 1,
          name: 'House Keeping',
          src: 'assets/svg/handyman.svg',
          background: '',
          page: ''
        }];
        this.admaintan = [{
          id: 1,
          name: 'Maintenance',
          src: 'assets/svg/builder.svg',
          background: '',
          page: ''
        }];
      }

      _createClass(HomePage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          var _this = this;

          //ambil data dari localstorage
          var dataStorage = JSON.parse(localStorage.getItem(this.serviceService.TOKEN_KEY)); // this.Username=dataStorage.data.Username;

          this.serviceService.CekUser().subscribe(function (data) {
            _this.DataLogin = data;
            console.log(_this.DataLogin);
            _this.Username = _this.DataLogin.body.name;
          }, function (error) {
            console.log("error");
          });
        }
      }, {
        key: "logout",
        value: function logout() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var loading;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadingController.create({
                      message: 'Please wait...'
                    });

                  case 2:
                    loading = _context.sent;
                    _context.next = 5;
                    return loading.present();

                  case 5:
                    localStorage.clear();
                    this.serviceService.logout();
                    loading.dismiss();

                  case 8:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "openRest",
        value: function openRest() {
          this.router.navigate(['catering']);
        }
      }, {
        key: "openHkeeping",
        value: function openHkeeping() {
          this.router.navigate(['housekeeping']);
        }
      }, {
        key: "openLaundry",
        value: function openLaundry() {
          this.router.navigate(['aduanlaundry']);
        }
      }, {
        key: "openAdmaintan",
        value: function openAdmaintan() {
          this.router.navigate(['aduanmaintenance']);
        }
      }]);

      return HomePage;
    }();

    HomePage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"]
      }, {
        type: _services_service_service__WEBPACK_IMPORTED_MODULE_3__["ServiceService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"]
      }, {
        type: src_app_services_util_service__WEBPACK_IMPORTED_MODULE_5__["UtilService"]
      }];
    };

    HomePage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-home',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./home.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/home/home.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./home.page.scss */
      "./src/app/home/home.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_2__["LoadingController"], _services_service_service__WEBPACK_IMPORTED_MODULE_3__["ServiceService"], _angular_router__WEBPACK_IMPORTED_MODULE_4__["Router"], src_app_services_util_service__WEBPACK_IMPORTED_MODULE_5__["UtilService"]])], HomePage);
    /***/
  }
}]);
//# sourceMappingURL=home-home-module-es5.js.map