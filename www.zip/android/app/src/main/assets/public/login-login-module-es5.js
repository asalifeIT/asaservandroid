function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["login-login-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html":
  /*!*****************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html ***!
    \*****************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppLoginLoginPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "  \r\n  <div class=\"main-header\">\r\n <ion-card-title>\r\n   <br>\r\n   <br>\r\n   <br>\r\n   <br>\r\n   <br>\r\n   <br>\r\n    <ion-label class=\"heading\">SELAMAT DATANG</ion-label><br>\r\n     ASTRO SERVICE - MEMBER ASTRA\r\n     <ion-grid>\r\n      <img src=\"assets/images/profile.png\"/>\r\n       </ion-grid>\r\n  </ion-card-title>\r\n  </div><br><br><br>\r\n  <ion-grid>\r\n    <ion-card>\r\n\r\n   </ion-card>\r\n\r\n   <ion-card class=\"ion-no-margin\">\r\n    <ion-card-header>\r\n\r\n  <form [formGroup]=\"FormLogin\" (ngSubmit)=\"login()\">\r\n    <ion-item>\r\n      <div color=\"dark\"  slot=\"start\">\r\n        <ion-icon slot=\"icon-only\" name=\"person\" ></ion-icon>\r\n    </div>\r\n      <ion-input type=\"text\" name=\"nrp\" placeholder=\"Masukkan NRP\" formControlName=\"nrp\"></ion-input>\r\n    </ion-item> \r\n    <div class=\"error-container\">\r\n      <ng-container *ngFor=\"let validation of validations.nrp\">\r\n        <div class=\"error-message\" *ngIf=\"FormLogin.get('nrp').hasError(validation.type) && (FormLogin.get('nrp').dirty || FormLogin.get('nrp').touched)\">\r\n          <span>{{ validation.message }}</span>\r\n          <br><br>\r\n        </div>\r\n      </ng-container>\r\n    </div> \r\n\r\n    <ion-item>\r\n      <div color=\"dark\"  slot=\"start\">\r\n        <ion-icon slot=\"icon-only\" name=\"lock-closed\"></ion-icon>\r\n    </div>\r\n      <ion-input type=\"text\" name=\"password\" placeholder=\"Masukkan Password\" formControlName=\"password\" *ngIf=\"showPasswordText\"></ion-input>\r\n      <ion-input type=\"password\" name=\"password\" placeholder=\"Masukkan Password\"   formControlName=\"password\" *ngIf=\"!showPasswordText\"></ion-input>\r\n      <ion-icon color=\"dark\" slot=\"icon-only\" (click)=\"showPasswordText = !showPasswordText\" *ngIf=\"showPasswordText\" name=\"eye\"  slot=\"end\" class=\"ion-align-self-center\"></ion-icon>\r\n      <ion-icon color=\"dark\" slot=\"icon-only\" (click)=\"showPasswordText = !showPasswordText\" *ngIf=\"!showPasswordText\" name=\"eye-off\" slot=\"end\" class=\"ion-align-self-center\"></ion-icon>\r\n    </ion-item>\r\n    <div class=\"error-container\">\r\n      <ng-container *ngFor=\"let validation of validations.password\">\r\n        <div class=\"error-message\" *ngIf=\"FormLogin.get('password').hasError(validation.type) && (FormLogin.get('password').dirty || FormLogin.get('password').touched)\">\r\n          <span>{{ validation.message }}</span>\r\n          <br>\r\n        </div>\r\n      </ng-container>\r\n    </div>\r\n<section>\r\n         <ion-button class=\"expand-block\" type=\"submit\"  [disabled]=\"!FormLogin.valid\">Login</ion-button>\r\n        </section>\r\n  </form>\r\n</ion-card-header></ion-card>\r\n  </ion-grid>\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n\r\n";
    /***/
  },

  /***/
  "./src/app/login/login-routing.module.ts":
  /*!***********************************************!*\
    !*** ./src/app/login/login-routing.module.ts ***!
    \***********************************************/

  /*! exports provided: LoginPageRoutingModule */

  /***/
  function srcAppLoginLoginRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginPageRoutingModule", function () {
      return LoginPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _login_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./login.page */
    "./src/app/login/login.page.ts");

    var routes = [{
      path: '',
      component: _login_page__WEBPACK_IMPORTED_MODULE_3__["LoginPage"]
    }];

    var LoginPageRoutingModule = /*#__PURE__*/_createClass(function LoginPageRoutingModule() {
      _classCallCheck(this, LoginPageRoutingModule);
    });

    LoginPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], LoginPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/login/login.module.ts":
  /*!***************************************!*\
    !*** ./src/app/login/login.module.ts ***!
    \***************************************/

  /*! exports provided: LoginPageModule */

  /***/
  function srcAppLoginLoginModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginPageModule", function () {
      return LoginPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _login_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./login-routing.module */
    "./src/app/login/login-routing.module.ts");
    /* harmony import */


    var _login_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./login.page */
    "./src/app/login/login.page.ts");

    var LoginPageModule = /*#__PURE__*/_createClass(function LoginPageModule() {
      _classCallCheck(this, LoginPageModule);
    });

    LoginPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _login_routing_module__WEBPACK_IMPORTED_MODULE_5__["LoginPageRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]],
      declarations: [_login_page__WEBPACK_IMPORTED_MODULE_6__["LoginPage"]]
    })], LoginPageModule);
    /***/
  },

  /***/
  "./src/app/login/login.page.scss":
  /*!***************************************!*\
    !*** ./src/app/login/login.page.scss ***!
    \***************************************/

  /*! exports provided: default */

  /***/
  function srcAppLoginLoginPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "@charset \"UTF-8\";\n/*\n  Authors : bunchdevelopers (Rahul Jograna)\n  Website : https://bunchdevelopers.com/\n  App Name : ionic6Template Pack\n  This App Template Source code is licensed as per the\n  terms found in the Website https://bunchdevelopers.com/license\n  Copyright and Good Faith Purchasers © 2021-present bunchdevelopers.\n*/\n.main-header {\n  height: 45vh;\n  width: 150%;\n  background: linear-gradient(90deg, var(--ion-color-tertiary) 10%, var(--ion-color-primary) 100%);\n  box-shadow: 0 1px 10px var(--ion-color-light);\n  border-radius: 0 0 50% 50%;\n  margin-left: -14vh;\n  margin-top: -60px;\n}\nimg {\n  width: 20vh;\n  height: 20vh;\n  margin-top: 8vh;\n  margin-left: 10vh;\n  margin-right: 10vh;\n  position: relative;\n}\n.button {\n  display: flex;\n  justify-content: flex-end;\n}\n.title {\n  display: flex;\n  justify-content: center;\n  flex-direction: column;\n  text-align: center;\n  margin-top: 3rem;\n}\n.title .heading {\n  font-family: \"Poppins\";\n  font-size: 15px;\n}\n.title .sub_heading {\n  margin-top: 0px;\n}\n.title span {\n  color: #0f0602;\n}\n.main_div {\n  margin: 20px 0px 30px 0px;\n  padding: 10px;\n}\n.main_div ion-item {\n  margin: 20px 0px 0px 0px;\n  border: 1px solid #d7d8da;\n  --padding-start: 0px;\n  --background: #f4f5f8;\n  border-radius: 10px;\n}\n.main_div ion-input {\n  margin: 10px;\n  --padding-start: 10px;\n}\n.main_div ion-label {\n  margin: 16px;\n  --padding-start: 10px;\n}\n.main_div .btn {\n  display: flex;\n  justify-content: flex-end;\n}\n.main_div .orDiv {\n  margin: 1em 0px 1em 0px;\n  display: flex;\n  flex-direction: row;\n  align-items: center;\n  text-align: center;\n  justify-content: center;\n}\n.main_div .orDiv .line {\n  width: 30%;\n  border-bottom: 1px solid lightgray;\n}\n.content_button {\n  margin-top: 50px;\n}\nion-content {\n  --ion-background-color:#E1EAF9 !important;\n}\nion-toolbar {\n  --ion-background-color: transparent;\n  --opacity:0;\n}\nion-card {\n  background-color: transparent !important;\n  padding: 0 !important;\n  position: relative;\n}\nion-card-title {\n  font-family: \"regular\";\n  margin-top: 30px;\n  font-size: 10px;\n  color: #faf6f6;\n  text-align: center;\n  font-weight: 600;\n  position: relative;\n}\nion-card-subtitle {\n  padding-top: 15px;\n  font-size: 11px;\n  color: #898585;\n  text-align: center;\n  font-weight: 300;\n}\nion-header {\n  position: absolute;\n}\nion-card {\n  --ion-background-color:transparent;\n  box-shadow: none !important;\n}\n.signin-btns {\n  margin-top: 35px;\n  text-align: center;\n  color: #F0F4FA;\n}\n.loginbtn {\n  --ion-color-primary:#215AB7;\n}\n.text-tag {\n  margin-top: 40px;\n  text-align: center;\n}\n.text-tag span {\n  font-size: 13px;\n  font-weight: normal;\n  color: #898585;\n}\n.social-btns {\n  margin-top: 30px;\n  text-align: center;\n}\n.social-btns ion-button {\n  width: 40px;\n  padding-left: 5px !important;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic3JjL2FwcC9sb2dpbi9FOlxcYXNhc2VydmFuZHJvaWQvc3JjXFxhcHBcXGxvZ2luXFxsb2dpbi5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FDQWhCOzs7Ozs7O0NBQUE7QUFVQTtFQUNFLFlBQUE7RUFDRSxXQUFBO0VBQ0EsZ0dBQUE7RUFDQSw2Q0FBQTtFQUNBLDBCQUFBO0VBQ0Esa0JBQUE7RUFDQSxpQkFBQTtBREFKO0FDR0E7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtFQUNBLGtCQUFBO0VBQ0Esa0JBQUE7QURBRjtBQ0lBO0VBQ0UsYUFBQTtFQUNBLHlCQUFBO0FEREY7QUNJQTtFQUNFLGFBQUE7RUFDQSx1QkFBQTtFQUNBLHNCQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBRERGO0FDRUU7RUFDRSxzQkFBQTtFQUNBLGVBQUE7QURBSjtBQ0dFO0VBQ0UsZUFBQTtBRERKO0FDR0U7RUFDRSxjQUFBO0FEREo7QUNJQTtFQUNFLHlCQUFBO0VBQ0EsYUFBQTtBRERGO0FDRUU7RUFDRSx3QkFBQTtFQUNBLHlCQUFBO0VBQ0Esb0JBQUE7RUFDQSxxQkFBQTtFQUNBLG1CQUFBO0FEQUo7QUNFRTtFQUNFLFlBQUE7RUFDQSxxQkFBQTtBREFKO0FDRUU7RUFDRSxZQUFBO0VBQ0EscUJBQUE7QURBSjtBQ0dFO0VBQ0UsYUFBQTtFQUNBLHlCQUFBO0FEREo7QUNHRTtFQUNFLHVCQUFBO0VBQ0EsYUFBQTtFQUNBLG1CQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0FEREo7QUNFSTtFQUNFLFVBQUE7RUFDQSxrQ0FBQTtBREFOO0FDS0E7RUFDRSxnQkFBQTtBREZGO0FDTUE7RUFDRSx5Q0FBQTtBREhGO0FDTUE7RUFDRSxtQ0FBQTtFQUNBLFdBQUE7QURIRjtBQ01BO0VBQ0Usd0NBQUE7RUFDQSxxQkFBQTtFQUNBLGtCQUFBO0FESEY7QUNRQTtFQUNFLHNCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0VBQ0EsY0FBQTtFQUNBLGtCQUFBO0VBQ0EsZ0JBQUE7RUFDQSxrQkFBQTtBRExGO0FDUUE7RUFDRSxpQkFBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0VBQ0Esa0JBQUE7RUFDQSxnQkFBQTtBRExGO0FDUUE7RUFDRSxrQkFBQTtBRExGO0FDUUE7RUFDRSxrQ0FBQTtFQUNGLDJCQUFBO0FETEE7QUNRQTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7RUFDQSxjQUFBO0FETEY7QUNRQTtFQUNFLDJCQUFBO0FETEY7QUNRQTtFQUNFLGdCQUFBO0VBQ0Esa0JBQUE7QURMRjtBQ01FO0VBQ0UsZUFBQTtFQUNBLG1CQUFBO0VBQ0EsY0FBQTtBREpKO0FDUUE7RUFDRSxnQkFBQTtFQUNBLGtCQUFBO0FETEY7QUNNRTtFQUNFLFdBQUE7RUFDQSw0QkFBQTtBREpKIiwiZmlsZSI6InNyYy9hcHAvbG9naW4vbG9naW4ucGFnZS5zY3NzIiwic291cmNlc0NvbnRlbnQiOlsiQGNoYXJzZXQgXCJVVEYtOFwiO1xuLypcbiAgQXV0aG9ycyA6IGJ1bmNoZGV2ZWxvcGVycyAoUmFodWwgSm9ncmFuYSlcbiAgV2Vic2l0ZSA6IGh0dHBzOi8vYnVuY2hkZXZlbG9wZXJzLmNvbS9cbiAgQXBwIE5hbWUgOiBpb25pYzZUZW1wbGF0ZSBQYWNrXG4gIFRoaXMgQXBwIFRlbXBsYXRlIFNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIGFzIHBlciB0aGVcbiAgdGVybXMgZm91bmQgaW4gdGhlIFdlYnNpdGUgaHR0cHM6Ly9idW5jaGRldmVsb3BlcnMuY29tL2xpY2Vuc2VcbiAgQ29weXJpZ2h0IGFuZCBHb29kIEZhaXRoIFB1cmNoYXNlcnMgwqkgMjAyMS1wcmVzZW50IGJ1bmNoZGV2ZWxvcGVycy5cbiovXG4ubWFpbi1oZWFkZXIge1xuICBoZWlnaHQ6IDQ1dmg7XG4gIHdpZHRoOiAxNTAlO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoOTBkZWcsIHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeSkgMTAlLCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgMTAwJSk7XG4gIGJveC1zaGFkb3c6IDAgMXB4IDEwcHggdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgYm9yZGVyLXJhZGl1czogMCAwIDUwJSA1MCU7XG4gIG1hcmdpbi1sZWZ0OiAtMTR2aDtcbiAgbWFyZ2luLXRvcDogLTYwcHg7XG59XG5cbmltZyB7XG4gIHdpZHRoOiAyMHZoO1xuICBoZWlnaHQ6IDIwdmg7XG4gIG1hcmdpbi10b3A6IDh2aDtcbiAgbWFyZ2luLWxlZnQ6IDEwdmg7XG4gIG1hcmdpbi1yaWdodDogMTB2aDtcbiAgcG9zaXRpb246IHJlbGF0aXZlO1xufVxuXG4uYnV0dG9uIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcbn1cblxuLnRpdGxlIHtcbiAgZGlzcGxheTogZmxleDtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAgbWFyZ2luLXRvcDogM3JlbTtcbn1cbi50aXRsZSAuaGVhZGluZyB7XG4gIGZvbnQtZmFtaWx5OiBcIlBvcHBpbnNcIjtcbiAgZm9udC1zaXplOiAxNXB4O1xufVxuLnRpdGxlIC5zdWJfaGVhZGluZyB7XG4gIG1hcmdpbi10b3A6IDBweDtcbn1cbi50aXRsZSBzcGFuIHtcbiAgY29sb3I6ICMwZjA2MDI7XG59XG5cbi5tYWluX2RpdiB7XG4gIG1hcmdpbjogMjBweCAwcHggMzBweCAwcHg7XG4gIHBhZGRpbmc6IDEwcHg7XG59XG4ubWFpbl9kaXYgaW9uLWl0ZW0ge1xuICBtYXJnaW46IDIwcHggMHB4IDBweCAwcHg7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNkN2Q4ZGE7XG4gIC0tcGFkZGluZy1zdGFydDogMHB4O1xuICAtLWJhY2tncm91bmQ6ICNmNGY1Zjg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG4ubWFpbl9kaXYgaW9uLWlucHV0IHtcbiAgbWFyZ2luOiAxMHB4O1xuICAtLXBhZGRpbmctc3RhcnQ6IDEwcHg7XG59XG4ubWFpbl9kaXYgaW9uLWxhYmVsIHtcbiAgbWFyZ2luOiAxNnB4O1xuICAtLXBhZGRpbmctc3RhcnQ6IDEwcHg7XG59XG4ubWFpbl9kaXYgLmJ0biB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XG59XG4ubWFpbl9kaXYgLm9yRGl2IHtcbiAgbWFyZ2luOiAxZW0gMHB4IDFlbSAwcHg7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGZsZXgtZGlyZWN0aW9uOiByb3c7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbiAganVzdGlmeS1jb250ZW50OiBjZW50ZXI7XG59XG4ubWFpbl9kaXYgLm9yRGl2IC5saW5lIHtcbiAgd2lkdGg6IDMwJTtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbn1cblxuLmNvbnRlbnRfYnV0dG9uIHtcbiAgbWFyZ2luLXRvcDogNTBweDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiNFMUVBRjkgIWltcG9ydGFudDtcbn1cblxuaW9uLXRvb2xiYXIge1xuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudDtcbiAgLS1vcGFjaXR5OjA7XG59XG5cbmlvbi1jYXJkIHtcbiAgYmFja2dyb3VuZC1jb2xvcjogdHJhbnNwYXJlbnQgIWltcG9ydGFudDtcbiAgcGFkZGluZzogMCAhaW1wb3J0YW50O1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG5cbmlvbi1jYXJkLXRpdGxlIHtcbiAgZm9udC1mYW1pbHk6IFwicmVndWxhclwiO1xuICBtYXJnaW4tdG9wOiAzMHB4O1xuICBmb250LXNpemU6IDEwcHg7XG4gIGNvbG9yOiAjZmFmNmY2O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG4gIGZvbnQtd2VpZ2h0OiA2MDA7XG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcbn1cblxuaW9uLWNhcmQtc3VidGl0bGUge1xuICBwYWRkaW5nLXRvcDogMTVweDtcbiAgZm9udC1zaXplOiAxMXB4O1xuICBjb2xvcjogIzg5ODU4NTtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBmb250LXdlaWdodDogMzAwO1xufVxuXG5pb24taGVhZGVyIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xufVxuXG5pb24tY2FyZCB7XG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6dHJhbnNwYXJlbnQ7XG4gIGJveC1zaGFkb3c6IG5vbmUgIWltcG9ydGFudDtcbn1cblxuLnNpZ25pbi1idG5zIHtcbiAgbWFyZ2luLXRvcDogMzVweDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBjb2xvcjogI0YwRjRGQTtcbn1cblxuLmxvZ2luYnRuIHtcbiAgLS1pb24tY29sb3ItcHJpbWFyeTojMjE1QUI3O1xufVxuXG4udGV4dC10YWcge1xuICBtYXJnaW4tdG9wOiA0MHB4O1xuICB0ZXh0LWFsaWduOiBjZW50ZXI7XG59XG4udGV4dC10YWcgc3BhbiB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgZm9udC13ZWlnaHQ6IG5vcm1hbDtcbiAgY29sb3I6ICM4OTg1ODU7XG59XG5cbi5zb2NpYWwtYnRucyB7XG4gIG1hcmdpbi10b3A6IDMwcHg7XG4gIHRleHQtYWxpZ246IGNlbnRlcjtcbn1cbi5zb2NpYWwtYnRucyBpb24tYnV0dG9uIHtcbiAgd2lkdGg6IDQwcHg7XG4gIHBhZGRpbmctbGVmdDogNXB4ICFpbXBvcnRhbnQ7XG59IiwiLypcclxuICBBdXRob3JzIDogYnVuY2hkZXZlbG9wZXJzIChSYWh1bCBKb2dyYW5hKVxyXG4gIFdlYnNpdGUgOiBodHRwczovL2J1bmNoZGV2ZWxvcGVycy5jb20vXHJcbiAgQXBwIE5hbWUgOiBpb25pYzZUZW1wbGF0ZSBQYWNrXHJcbiAgVGhpcyBBcHAgVGVtcGxhdGUgU291cmNlIGNvZGUgaXMgbGljZW5zZWQgYXMgcGVyIHRoZVxyXG4gIHRlcm1zIGZvdW5kIGluIHRoZSBXZWJzaXRlIGh0dHBzOi8vYnVuY2hkZXZlbG9wZXJzLmNvbS9saWNlbnNlXHJcbiAgQ29weXJpZ2h0IGFuZCBHb29kIEZhaXRoIFB1cmNoYXNlcnMgwqkgMjAyMS1wcmVzZW50IGJ1bmNoZGV2ZWxvcGVycy5cclxuKi9cclxuXHJcblxyXG4ubWFpbi1oZWFkZXIge1xyXG4gIGhlaWdodDogNDV2aDtcclxuICAgIHdpZHRoOiAxNTAlO1xyXG4gICAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDkwZGVnLCB2YXIoLS1pb24tY29sb3ItdGVydGlhcnkpIDEwJSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpIDEwMCUpO1xyXG4gICAgYm94LXNoYWRvdzogMCAxcHggMTBweCB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gICAgYm9yZGVyLXJhZGl1czogMCAwIDUwJSA1MCU7XHJcbiAgICBtYXJnaW4tbGVmdDogLTE0dmg7XHJcbiAgICBtYXJnaW4tdG9wOiAtNjBweDtcclxuXHJcbn1cclxuaW1nIHtcclxuICB3aWR0aDogMjB2aDtcclxuICBoZWlnaHQ6MjB2aDtcclxuICBtYXJnaW4tdG9wOiA4dmg7IFxyXG4gIG1hcmdpbi1sZWZ0OiAxMHZoO1xyXG4gIG1hcmdpbi1yaWdodDoxMHZoO1xyXG4gIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuXHJcbn1cclxuXHJcbi5idXR0b24ge1xyXG4gIGRpc3BsYXk6IGZsZXg7XHJcbiAganVzdGlmeS1jb250ZW50OiBmbGV4LWVuZDtcclxuXHJcbn1cclxuLnRpdGxlIHtcclxuICBkaXNwbGF5OiBmbGV4O1xyXG4gIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIG1hcmdpbi10b3A6IDNyZW07XHJcbiAgLmhlYWRpbmcge1xyXG4gICAgZm9udC1mYW1pbHk6IFwiUG9wcGluc1wiO1xyXG4gICAgZm9udC1zaXplOiAxNXB4O1xyXG5cclxuICB9XHJcbiAgLnN1Yl9oZWFkaW5nIHtcclxuICAgIG1hcmdpbi10b3A6IDBweDtcclxuICB9XHJcbiAgc3BhbiB7XHJcbiAgICBjb2xvcjogIzBmMDYwMjtcclxuICB9XHJcbn1cclxuLm1haW5fZGl2IHtcclxuICBtYXJnaW46IDIwcHggMHB4IDMwcHggMHB4O1xyXG4gIHBhZGRpbmc6IDEwcHg7XHJcbiAgaW9uLWl0ZW0ge1xyXG4gICAgbWFyZ2luOiAyMHB4IDBweCAwcHggMHB4O1xyXG4gICAgYm9yZGVyOiAxcHggc29saWQgI2Q3ZDhkYTtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMHB4O1xyXG4gICAgLS1iYWNrZ3JvdW5kOiAjZjRmNWY4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICB9XHJcbiAgaW9uLWlucHV0IHtcclxuICAgIG1hcmdpbjogMTBweDtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMTBweDtcclxuICB9XHJcbiAgaW9uLWxhYmVsIHtcclxuICAgIG1hcmdpbjogMTZweDtcclxuICAgIC0tcGFkZGluZy1zdGFydDogMTBweDtcclxuICB9XHJcblxyXG4gIC5idG4ge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGp1c3RpZnktY29udGVudDogZmxleC1lbmQ7XHJcbiAgfVxyXG4gIC5vckRpdiB7XHJcbiAgICBtYXJnaW46IDFlbSAwcHggMWVtIDBweDtcclxuICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgLmxpbmUge1xyXG4gICAgICB3aWR0aDogMzAlO1xyXG4gICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG5cclxuLmNvbnRlbnRfYnV0dG9uIHtcclxuICBtYXJnaW4tdG9wOiA1MHB4O1xyXG59XHJcblxyXG5cclxuaW9uLWNvbnRlbnR7XHJcbiAgLS1pb24tYmFja2dyb3VuZC1jb2xvcjojRTFFQUY5ICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbmlvbi10b29sYmFye1xyXG4gIC0taW9uLWJhY2tncm91bmQtY29sb3I6IHRyYW5zcGFyZW50O1xyXG4gIC0tb3BhY2l0eTowO1xyXG59XHJcblxyXG5pb24tY2FyZHtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiB0cmFuc3BhcmVudCAhaW1wb3J0YW50O1xyXG4gIHBhZGRpbmc6IDAgIWltcG9ydGFudDtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcblxyXG5cclxuaW9uLWNhcmQtdGl0bGV7XHJcbiAgZm9udC1mYW1pbHk6IFwicmVndWxhclwiO1xyXG4gIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgZm9udC1zaXplOiAxMHB4O1xyXG4gIGNvbG9yOiNmYWY2ZjY7XHJcbiAgdGV4dC1hbGlnbjpjZW50ZXI7XHJcbiAgZm9udC13ZWlnaHQ6IDYwMDtcclxuICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbn1cclxuXHJcbmlvbi1jYXJkLXN1YnRpdGxle1xyXG4gIHBhZGRpbmctdG9wOiAxNXB4O1xyXG4gIGZvbnQtc2l6ZToxMXB4O1xyXG4gIGNvbG9yOiM4OTg1ODU7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGZvbnQtd2VpZ2h0OiAzMDA7XHJcbn1cclxuXHJcbmlvbi1oZWFkZXJ7XHJcbiAgcG9zaXRpb246IGFic29sdXRlO1xyXG59XHJcblxyXG5pb24tY2FyZHtcclxuICAtLWlvbi1iYWNrZ3JvdW5kLWNvbG9yOnRyYW5zcGFyZW50O1xyXG5ib3gtc2hhZG93OiBub25lICFpbXBvcnRhbnQ7XHJcbn1cclxuXHJcbi5zaWduaW4tYnRuc3tcclxuICBtYXJnaW4tdG9wOiAzNXB4O1xyXG4gIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICBjb2xvcjojRjBGNEZBO1xyXG59XHJcblxyXG4ubG9naW5idG57XHJcbiAgLS1pb24tY29sb3ItcHJpbWFyeTojMjE1QUI3O1xyXG59XHJcblxyXG4udGV4dC10YWd7XHJcbiAgbWFyZ2luLXRvcDogNDBweDtcclxuICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgc3BhbntcclxuICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgIGZvbnQtd2VpZ2h0OiBub3JtYWw7XHJcbiAgICBjb2xvcjojODk4NTg1O1xyXG4gIH1cclxufVxyXG5cclxuLnNvY2lhbC1idG5ze1xyXG4gIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xyXG4gIGlvbi1idXR0b257XHJcbiAgICB3aWR0aDo0MHB4O1xyXG4gICAgcGFkZGluZy1sZWZ0OiA1cHggIWltcG9ydGFudDtcclxuICB9XHJcbn1cclxuIl19 */";
    /***/
  },

  /***/
  "./src/app/login/login.page.ts":
  /*!*************************************!*\
    !*** ./src/app/login/login.page.ts ***!
    \*************************************/

  /*! exports provided: LoginPage */

  /***/
  function srcAppLoginLoginPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "LoginPage", function () {
      return LoginPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _register_register_page__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../register/register.page */
    "./src/app/register/register.page.ts");
    /* harmony import */


    var _services_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ../services/service.service */
    "./src/app/services/service.service.ts");

    var LoginPage = /*#__PURE__*/function () {
      function LoginPage(formBuilder, navCtrl, loadingController, modalController, platform, toastController, serviceService) {
        _classCallCheck(this, LoginPage);

        this.formBuilder = formBuilder;
        this.navCtrl = navCtrl;
        this.loadingController = loadingController;
        this.modalController = modalController;
        this.platform = platform;
        this.toastController = toastController;
        this.serviceService = serviceService;
        this.validations = {
          'nrp': [{
            type: 'required',
            message: 'nrp harus diisi.'
          }],
          'password': [{
            type: 'required',
            message: 'password harus diisi.'
          }]
        };
      }

      _createClass(LoginPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          //setting form login
          this.FormLogin = this.formBuilder.group({
            nrp: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])),
            password: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]))
          });
        } //fungsi login

      }, {
        key: "login",
        value: function login() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadingController.create({
                      message: 'Please wait...'
                    });

                  case 2:
                    loading = _context.sent;
                    _context.next = 5;
                    return loading.present();

                  case 5:
                    this.serviceService.loginApi(this.FormLogin.value, 'signin').subscribe(function (data) {
                      _this.dataLogin = data;
                      loading.dismiss();
                    }, function (error) {
                      _this.presentToast(error);

                      loading.dismiss();
                    });

                  case 6:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        } //menampilkan halaman register

      }, {
        key: "registerModal",
        value: function registerModal() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var modal;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.modalController.create({
                      component: _register_register_page__WEBPACK_IMPORTED_MODULE_4__["RegisterPage"]
                    });

                  case 2:
                    modal = _context2.sent;
                    _context2.next = 5;
                    return modal.present();

                  case 5:
                    return _context2.abrupt("return", _context2.sent);

                  case 6:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "presentToast",
        value: function presentToast(Message) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee3() {
            var toast;
            return regeneratorRuntime.wrap(function _callee3$(_context3) {
              while (1) {
                switch (_context3.prev = _context3.next) {
                  case 0:
                    _context3.next = 2;
                    return this.toastController.create({
                      message: Message,
                      duration: 2500,
                      position: "bottom"
                    });

                  case 2:
                    toast = _context3.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context3.stop();
                }
              }
            }, _callee3, this);
          }));
        }
      }, {
        key: "Login",
        value: function Login() {
          console.log("anda sekarang login");
          this.authService.login(this.nrp, this.password);
        }
      }, {
        key: "nrp",
        value: function nrp(_nrp, password) {
          throw new Error('Method not implemented.');
        }
      }, {
        key: "password",
        value: function password(nrp, _password) {
          throw new Error('Method not implemented.');
        }
      }]);

      return LoginPage;
    }();

    LoginPage.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"]
      }, {
        type: _services_service_service__WEBPACK_IMPORTED_MODULE_5__["ServiceService"]
      }];
    };

    LoginPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-login',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./login.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/login/login.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./login.page.scss */
      "./src/app/login/login.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"], _services_service_service__WEBPACK_IMPORTED_MODULE_5__["ServiceService"]])], LoginPage);
    /***/
  }
}]);
//# sourceMappingURL=login-login-module-es5.js.map