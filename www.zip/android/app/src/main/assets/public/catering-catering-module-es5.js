function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["catering-catering-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/catering/catering.page.html":
  /*!***********************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/catering/catering.page.html ***!
    \***********************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppCateringCateringPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\r\n  <ion-item lines=\"none\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-button (click)=\"util.openSideMenu()\">\r\n        <ion-icon name=\"menu\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-label color=\"light\">\r\n    Menu Catering\r\n  </ion-label>\r\n  <ion-buttons slot=\"end\">\r\n    <ion-icon (click)=\"onBack()\" name=\"arrow-undo\"></ion-icon>\r\n  </ion-buttons>\r\n  </ion-item>\r\n </ion-header>\r\n\r\n <ion-content [fullscreen]=\"true\" color=\"light\">\r\n  <div class=\"main-header\"></div>\r\n    <ion-grid>\r\n    <ion-note color=\"light\" class=\"ion-margin-start\">\r\n       <b></b> \r\n      </ion-note> \r\n<br>\r\n<br>\r\n\r\n\r\n        <div class=\"main_content\" *ngFor=\"let item of aduan\" (click)=\"openAduancat()\">\r\n          <ion-row>\r\n            <ion-col size=\"5\"><br>\r\n              <div class=\"img\" [style.backgroundImage]=\"'url(assets/svg/positive-feedback.svg)'\"></div>\r\n            </ion-col>\r\n            <ion-col size=\"7\">\r\n              <div class=\"title\">\r\n                <ion-label color=\"dark\" class=\"ttl\">Aduan Catering</ion-label>\r\n                <ion-label class=\"sub_ttl1\">Form Isian Aduan Pelayanan Catering</ion-label>\r\n                <div class=\"icon_title\">\r\n                  <ion-icon slot=\"start\" name=\"star\"></ion-icon>\r\n                  <ion-label color=\"dark\">Isikan Aduan Anda</ion-label>\r\n                </div>\r\n                <div class=\"icon_title\">\r\n                  <ion-icon slot=\"start\" name=\"location-sharp\"></ion-icon>\r\n                  <ion-label  color=\"dark\">Deskripsi dan Lokasi</ion-label>\r\n                </div>\r\n              </div>\r\n            </ion-col>\r\n          </ion-row>\r\n         <div class=\"line\"></div>\r\n         </div>\r\n\r\n          <div class=\"main_content\" *ngFor=\"let item of rating\" (click)=\"openRatingcat()\">\r\n          <ion-row>\r\n            <ion-col size=\"5\"><br>\r\n              <div class=\"img\" [style.backgroundImage]=\"'url(assets/svg/feedback-testimonial.svg)'\"></div>\r\n              </ion-col>\r\n              <ion-col size=\"7\">\r\n                <div class=\"title\">\r\n                  <ion-label class=\"ttl\">Rating Catering</ion-label>\r\n                  <ion-label class=\"sub_ttl\">Silahkan Memberikan Nilai </ion-label>\r\n                  <div class=\"icon_title\">\r\n                    <div class=\"rate\">\r\n                      <ion-icon name=\"star\"></ion-icon>\r\n                      <ion-icon name=\"star\"></ion-icon>\r\n                      <ion-icon name=\"star\"></ion-icon>\r\n                      <ion-icon name=\"star\"></ion-icon>\r\n                      <ion-icon name=\"star\"></ion-icon>\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"icon_title\">\r\n                    <ion-icon slot=\"start\" name=\"location-sharp\"></ion-icon>\r\n                    <ion-label color=\"dark\">Terdiri dari 5 (lima) pilihan</ion-label>\r\n                  </div>\r\n                </div>\r\n              </ion-col>\r\n            </ion-row>\r\n           <div class=\"line\"></div>\r\n           </div>\r\n    </ion-grid>\r\n  </ion-content>\r\n\r\n\r\n\r\n";
    /***/
  },

  /***/
  "./src/app/catering/catering-routing.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/catering/catering-routing.module.ts ***!
    \*****************************************************/

  /*! exports provided: CateringPageRoutingModule */

  /***/
  function srcAppCateringCateringRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CateringPageRoutingModule", function () {
      return CateringPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _catering_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./catering.page */
    "./src/app/catering/catering.page.ts");

    var routes = [{
      path: '',
      component: _catering_page__WEBPACK_IMPORTED_MODULE_3__["CateringPage"]
    }];

    var CateringPageRoutingModule = /*#__PURE__*/_createClass(function CateringPageRoutingModule() {
      _classCallCheck(this, CateringPageRoutingModule);
    });

    CateringPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], CateringPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/catering/catering.module.ts":
  /*!*********************************************!*\
    !*** ./src/app/catering/catering.module.ts ***!
    \*********************************************/

  /*! exports provided: CateringPageModule */

  /***/
  function srcAppCateringCateringModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CateringPageModule", function () {
      return CateringPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _catering_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./catering-routing.module */
    "./src/app/catering/catering-routing.module.ts");
    /* harmony import */


    var _catering_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./catering.page */
    "./src/app/catering/catering.page.ts");

    var CateringPageModule = /*#__PURE__*/_createClass(function CateringPageModule() {
      _classCallCheck(this, CateringPageModule);
    });

    CateringPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _catering_routing_module__WEBPACK_IMPORTED_MODULE_5__["CateringPageRoutingModule"]],
      declarations: [_catering_page__WEBPACK_IMPORTED_MODULE_6__["CateringPage"]]
    })], CateringPageModule);
    /***/
  },

  /***/
  "./src/app/catering/catering.page.scss":
  /*!*********************************************!*\
    !*** ./src/app/catering/catering.page.scss ***!
    \*********************************************/

  /*! exports provided: default */

  /***/
  function srcAppCateringCateringPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "@charset \"UTF-8\";\nion-header {\n  background: transparent;\n}\nion-header ion-label {\n  font-size: 13px;\n  font-family: \"regular\";\n}\nion-header ion-item {\n  --background: transparent;\n}\nion-header ion-item ion-avatar {\n  background: white;\n}\nion-content {\n  /*\n    Authors : bunchdevelopers (Rahul Jograna)\n    Website : https://bunchdevelopers.com/\n    App Name : ionic6Template Pack\n    This App Template Source code is licensed as per the\n    terms found in the Website https://bunchdevelopers.com/license\n    Copyright and Good Faith Purchasers © 2021-present bunchdevelopers.\n  */\n}\nion-content * {\n  font-family: \"regular\";\n}\nion-content .title {\n  font-family: \"regular\";\n}\nion-content .icon_title {\n  font-family: \"regular\";\n}\nion-content .main-header {\n  height: 26vh;\n  width: 150%;\n  background: linear-gradient(45deg, var(--ion-color-tertiary) 30%, var(--ion-color-primary) 100%);\n  box-shadow: 0 1px 30px var(--ion-color-light);\n  border-radius: 0 0 50% 50%;\n  margin-left: -14vh;\n  margin-top: -60px;\n}\nion-content ion-grid {\n  width: 100%;\n  position: absolute;\n  top: 35px;\n  left: 0;\n  transform: translateY(10vh);\n  padding-bottom: 8vh;\n}\nion-content ion-grid ion-row ion-col ion-label ion-note {\n  font-size: 0.7rem;\n}\nion-content ion-grid ion-row ion-col ion-label ion-chip ion-label {\n  position: absolute;\n  font-size: 1.4rem;\n  font-weight: bold;\n  letter-spacing: 0.5px;\n  text-shadow: 1px 1px 1px var(--ion-color-medium);\n}\nion-content ion-grid ion-row ion-col ion-label b {\n  font-size: 1.2rem;\n}\nion-content ion-grid ion-row ion-col ion-button {\n  height: 3em !important;\n  transform: translateY(10%);\n  text-transform: none;\n}\nion-content ion-grid ion-row ion-col ion-button ion-text {\n  font-size: 0.7rem;\n  font-weight: bold;\n  text-shadow: 1px 1px 1px var(--ion-color-medium);\n}\nion-content ion-grid ion-row ion-col ion-button ion-icon {\n  font-size: 1rem;\n}\nion-content ion-grid ion-row ion-col ion-card {\n  box-shadow: -1px 11px 10px -6px #f7b34e;\n  border-radius: 5px !important;\n  margin: 5px 5px;\n}\nion-content ion-grid ion-row ion-col ion-card ion-thumbnail {\n  width: 10vh;\n  height: 10vh;\n  border-radius: 10px;\n}\nion-content ion-grid ion-row ion-col ion-card ion-thumbnail img {\n  width: 10vh;\n  height: 10vh;\n  transform: translateY(10%);\n}\nion-content ion-grid ion-row ion-col ion-card ion-card-content ion-label {\n  font-weight: regular;\n  text-shadow: 1px 1px 1px var(--ion-color-medium);\n  letter-spacing: 0.5px;\n}\nion-content ion-grid ion-list {\n  background: transparent;\n}\nion-content ion-grid ion-list ion-item {\n  width: 95%;\n  margin: auto;\n  border-radius: 5px;\n  margin-bottom: 2vh;\n}\nion-content ion-grid ion-list ion-item p {\n  font-size: 0.65rem;\n}\nion-content ion-grid ion-list ion-item ion-text {\n  font-weight: 800;\n}\nion-content ion-header ion-toolbar ion-title {\n  padding: 0px;\n  font-family: \"regular\";\n}\nion-content ion-header ion-toolbar ion-buttons {\n  padding: 5px 2px 5px 2px;\n  margin: 10px;\n}\nion-content ion-header ion-toolbar ion-buttons ion-button {\n  height: 40px;\n  width: 40px;\n  border: 1px solid lightgray;\n  --border-radius: 50%;\n  border-radius: 50%;\n}\nion-content ion-header ion-toolbar ion-buttons ion-button ion-icon {\n  color: gray;\n}\nion-content .item_div ion-row .scroll_div {\n  overflow: scroll;\n}\nion-content .item_div ion-row .scroll_div .item {\n  width: -webkit-max-content;\n  width: -moz-max-content;\n  width: max-content;\n  display: flex;\n  flex-direction: row;\n}\nion-content .item_div ion-row .scroll_div .item ion-chip {\n  height: 50px;\n  border-radius: 10px;\n}\nion-content .main_content {\n  padding: 10px;\n  border-radius: 10px;\n}\nion-content .main_content ion-row ion-col .img {\n  height: 90px;\n  width: 90px;\n  border-radius: 10px;\n  background-position: center center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\nion-content .main_content ion-row ion-col .title {\n  font-family: \"regular\";\n  display: flex;\n  flex-direction: column;\n  margin-top: 12px;\n}\nion-content .main_content ion-row ion-col .title .ttl {\n  font-family: \"bold\";\n  font-size: 16px;\n}\nion-content .main_content ion-row ion-col .title .sub_ttl1 {\n  font-family: \"regular\";\n  font-size: 13px;\n  margin: 3px 0px 3px 0px;\n  color: #0a0101;\n}\nion-content .main_content ion-row ion-col .title .sub_ttl {\n  font-family: \"regular\";\n  font-size: 13px;\n  margin: 3px 0px 3px 0px;\n  color: #080000;\n}\nion-content .main_content ion-row ion-col .title .icon_title {\n  display: flex;\n  align-items: center;\n  color: #ff7c31;\n  margin: 2px 0px 2px 0px;\n}\nion-content .main_content ion-row ion-col .title .icon_title ion-icon {\n  font-family: \"regular\";\n  font-size: 20px;\n  margin-right: 5px;\n}\nion-content .main_content ion-row ion-col .title .icon_title ion-label {\n  font-size: 12px;\n}\nion-content .main_content .line {\n  width: 100%;\n  border-bottom: 1px solid lightgray;\n  margin: 20px 0px 0px 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvY2F0ZXJpbmcvY2F0ZXJpbmcucGFnZS5zY3NzIiwic3JjL2FwcC9jYXRlcmluZy9FOlxcYXNhc2VydmFuZHJvaWQvc3JjXFxhcHBcXGNhdGVyaW5nXFxjYXRlcmluZy5wYWdlLnNjc3MiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6IkFBQUEsZ0JBQWdCO0FDQWhCO0VBS0ksdUJBQUE7QURGSjtBQ0ZJO0VBQ0UsZUFBQTtFQUNBLHNCQUFBO0FESU47QUNESTtFQUNFLHlCQUFBO0FER047QUNGTTtFQUNFLGlCQUFBO0FESVI7QUNDRTtFQW9HQTs7Ozs7OztHQUFBO0FEMUZGO0FDVEk7RUFDRSxzQkFBQTtBRFdOO0FDUkk7RUFDRSxzQkFBQTtBRFVOO0FDUkk7RUFDRSxzQkFBQTtBRFVOO0FDUEk7RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGdHQUFBO0VBQ0EsNkNBQUE7RUFDQSwwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QURTTjtBQ1BJO0VBQ0UsV0FBQTtFQUNBLGtCQUFBO0VBQ0EsU0FBQTtFQUNBLE9BQUE7RUFDQSwyQkFBQTtFQUNBLG1CQUFBO0FEU047QUNMWTtFQUNFLGlCQUFBO0FET2Q7QUNKYztFQUNFLGtCQUFBO0VBQ0EsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLHFCQUFBO0VBQ0EsZ0RBQUE7QURNaEI7QUNIWTtFQUNFLGlCQUFBO0FES2Q7QUNGVTtFQUNFLHNCQUFBO0VBQ0EsMEJBQUE7RUFDQSxvQkFBQTtBRElaO0FDSFk7RUFDRSxpQkFBQTtFQUNBLGlCQUFBO0VBQ0EsZ0RBQUE7QURLZDtBQ0hZO0VBQ0UsZUFBQTtBREtkO0FDRlU7RUFDRSx1Q0FBQTtFQUNBLDZCQUFBO0VBQ0EsZUFBQTtBRElaO0FDSFk7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0FES2Q7QUNKYztFQUNFLFdBQUE7RUFDQSxZQUFBO0VBQ0EsMEJBQUE7QURNaEI7QUNGYztFQUNFLG9CQUFBO0VBQ0EsZ0RBQUE7RUFDQSxxQkFBQTtBREloQjtBQ0VNO0VBQ0UsdUJBQUE7QURBUjtBQ0NRO0VBQ0UsVUFBQTtFQUNBLFlBQUE7RUFDQSxrQkFBQTtFQUNBLGtCQUFBO0FEQ1Y7QUNBVTtFQUNFLGtCQUFBO0FERVo7QUNBVTtFQUNFLGdCQUFBO0FERVo7QUNhTTtFQUNFLFlBQUE7RUFDQSxzQkFBQTtBRFhSO0FDYU07RUFDRSx3QkFBQTtFQUNBLFlBQUE7QURYUjtBQ1lRO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSwyQkFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7QURWVjtBQ1dVO0VBQ0UsV0FBQTtBRFRaO0FDa0JNO0VBQ0UsZ0JBQUE7QURoQlI7QUNpQlE7RUFDRSwwQkFBQTtFQUFBLHVCQUFBO0VBQUEsa0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QURmVjtBQ2dCVTtFQUNFLFlBQUE7RUFDQSxtQkFBQTtBRGRaO0FDcUJFO0VBQ0UsYUFBQTtFQUNBLG1CQUFBO0FEbkJKO0FDc0JRO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxtQkFBQTtFQUNBLGtDQUFBO0VBQ0EsNEJBQUE7RUFDQSxzQkFBQTtBRHBCVjtBQ3NCUTtFQUNFLHNCQUFBO0VBQ0EsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QURwQlY7QUNxQlU7RUFDRSxtQkFBQTtFQUNBLGVBQUE7QURuQlo7QUNzQlU7RUFDRSxzQkFBQTtFQUNBLGVBQUE7RUFDQSx1QkFBQTtFQUNBLGNBQUE7QURwQlo7QUNzQlU7RUFDRSxzQkFBQTtFQUNBLGVBQUE7RUFDQSx1QkFBQTtFQUNBLGNBQUE7QURwQlo7QUN1QlU7RUFFRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsdUJBQUE7QUR0Qlo7QUN1Qlk7RUFDRSxzQkFBQTtFQUNBLGVBQUE7RUFDQSxpQkFBQTtBRHJCZDtBQ3VCWTtFQUNFLGVBQUE7QURyQmQ7QUMyQkk7RUFDRSxXQUFBO0VBQ0Esa0NBQUE7RUFDQSx3QkFBQTtBRHpCTiIsImZpbGUiOiJzcmMvYXBwL2NhdGVyaW5nL2NhdGVyaW5nLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBjaGFyc2V0IFwiVVRGLThcIjtcbmlvbi1oZWFkZXIge1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cbmlvbi1oZWFkZXIgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XG59XG5pb24taGVhZGVyIGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cbmlvbi1oZWFkZXIgaW9uLWl0ZW0gaW9uLWF2YXRhciB7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG5pb24tY29udGVudCB7XG4gIC8qXG4gICAgQXV0aG9ycyA6IGJ1bmNoZGV2ZWxvcGVycyAoUmFodWwgSm9ncmFuYSlcbiAgICBXZWJzaXRlIDogaHR0cHM6Ly9idW5jaGRldmVsb3BlcnMuY29tL1xuICAgIEFwcCBOYW1lIDogaW9uaWM2VGVtcGxhdGUgUGFja1xuICAgIFRoaXMgQXBwIFRlbXBsYXRlIFNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIGFzIHBlciB0aGVcbiAgICB0ZXJtcyBmb3VuZCBpbiB0aGUgV2Vic2l0ZSBodHRwczovL2J1bmNoZGV2ZWxvcGVycy5jb20vbGljZW5zZVxuICAgIENvcHlyaWdodCBhbmQgR29vZCBGYWl0aCBQdXJjaGFzZXJzIMKpIDIwMjEtcHJlc2VudCBidW5jaGRldmVsb3BlcnMuXG4gICovXG59XG5pb24tY29udGVudCAqIHtcbiAgZm9udC1mYW1pbHk6IFwicmVndWxhclwiO1xufVxuaW9uLWNvbnRlbnQgLnRpdGxlIHtcbiAgZm9udC1mYW1pbHk6IFwicmVndWxhclwiO1xufVxuaW9uLWNvbnRlbnQgLmljb25fdGl0bGUge1xuICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XG59XG5pb24tY29udGVudCAubWFpbi1oZWFkZXIge1xuICBoZWlnaHQ6IDI2dmg7XG4gIHdpZHRoOiAxNTAlO1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoNDVkZWcsIHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeSkgMzAlLCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgMTAwJSk7XG4gIGJveC1zaGFkb3c6IDAgMXB4IDMwcHggdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcbiAgYm9yZGVyLXJhZGl1czogMCAwIDUwJSA1MCU7XG4gIG1hcmdpbi1sZWZ0OiAtMTR2aDtcbiAgbWFyZ2luLXRvcDogLTYwcHg7XG59XG5pb24tY29udGVudCBpb24tZ3JpZCB7XG4gIHdpZHRoOiAxMDAlO1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHRvcDogMzVweDtcbiAgbGVmdDogMDtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDEwdmgpO1xuICBwYWRkaW5nLWJvdHRvbTogOHZoO1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLXJvdyBpb24tY29sIGlvbi1sYWJlbCBpb24tbm90ZSB7XG4gIGZvbnQtc2l6ZTogMC43cmVtO1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLXJvdyBpb24tY29sIGlvbi1sYWJlbCBpb24tY2hpcCBpb24tbGFiZWwge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIGZvbnQtc2l6ZTogMS40cmVtO1xuICBmb250LXdlaWdodDogYm9sZDtcbiAgbGV0dGVyLXNwYWNpbmc6IDAuNXB4O1xuICB0ZXh0LXNoYWRvdzogMXB4IDFweCAxcHggdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG59XG5pb24tY29udGVudCBpb24tZ3JpZCBpb24tcm93IGlvbi1jb2wgaW9uLWxhYmVsIGIge1xuICBmb250LXNpemU6IDEuMnJlbTtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1yb3cgaW9uLWNvbCBpb24tYnV0dG9uIHtcbiAgaGVpZ2h0OiAzZW0gIWltcG9ydGFudDtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDEwJSk7XG4gIHRleHQtdHJhbnNmb3JtOiBub25lO1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLXJvdyBpb24tY29sIGlvbi1idXR0b24gaW9uLXRleHQge1xuICBmb250LXNpemU6IDAuN3JlbTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIHRleHQtc2hhZG93OiAxcHggMXB4IDFweCB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1yb3cgaW9uLWNvbCBpb24tYnV0dG9uIGlvbi1pY29uIHtcbiAgZm9udC1zaXplOiAxcmVtO1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLXJvdyBpb24tY29sIGlvbi1jYXJkIHtcbiAgYm94LXNoYWRvdzogLTFweCAxMXB4IDEwcHggLTZweCAjZjdiMzRlO1xuICBib3JkZXItcmFkaXVzOiA1cHggIWltcG9ydGFudDtcbiAgbWFyZ2luOiA1cHggNXB4O1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLXJvdyBpb24tY29sIGlvbi1jYXJkIGlvbi10aHVtYm5haWwge1xuICB3aWR0aDogMTB2aDtcbiAgaGVpZ2h0OiAxMHZoO1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLXJvdyBpb24tY29sIGlvbi1jYXJkIGlvbi10aHVtYm5haWwgaW1nIHtcbiAgd2lkdGg6IDEwdmg7XG4gIGhlaWdodDogMTB2aDtcbiAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDEwJSk7XG59XG5pb24tY29udGVudCBpb24tZ3JpZCBpb24tcm93IGlvbi1jb2wgaW9uLWNhcmQgaW9uLWNhcmQtY29udGVudCBpb24tbGFiZWwge1xuICBmb250LXdlaWdodDogcmVndWxhcjtcbiAgdGV4dC1zaGFkb3c6IDFweCAxcHggMXB4IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xuICBsZXR0ZXItc3BhY2luZzogMC41cHg7XG59XG5pb24tY29udGVudCBpb24tZ3JpZCBpb24tbGlzdCB7XG4gIGJhY2tncm91bmQ6IHRyYW5zcGFyZW50O1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLWxpc3QgaW9uLWl0ZW0ge1xuICB3aWR0aDogOTUlO1xuICBtYXJnaW46IGF1dG87XG4gIGJvcmRlci1yYWRpdXM6IDVweDtcbiAgbWFyZ2luLWJvdHRvbTogMnZoO1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLWxpc3QgaW9uLWl0ZW0gcCB7XG4gIGZvbnQtc2l6ZTogMC42NXJlbTtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1saXN0IGlvbi1pdGVtIGlvbi10ZXh0IHtcbiAgZm9udC13ZWlnaHQ6IDgwMDtcbn1cbmlvbi1jb250ZW50IGlvbi1oZWFkZXIgaW9uLXRvb2xiYXIgaW9uLXRpdGxlIHtcbiAgcGFkZGluZzogMHB4O1xuICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XG59XG5pb24tY29udGVudCBpb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi1idXR0b25zIHtcbiAgcGFkZGluZzogNXB4IDJweCA1cHggMnB4O1xuICBtYXJnaW46IDEwcHg7XG59XG5pb24tY29udGVudCBpb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi1idXR0b25zIGlvbi1idXR0b24ge1xuICBoZWlnaHQ6IDQwcHg7XG4gIHdpZHRoOiA0MHB4O1xuICBib3JkZXI6IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gIC0tYm9yZGVyLXJhZGl1czogNTAlO1xuICBib3JkZXItcmFkaXVzOiA1MCU7XG59XG5pb24tY29udGVudCBpb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi1idXR0b25zIGlvbi1idXR0b24gaW9uLWljb24ge1xuICBjb2xvcjogZ3JheTtcbn1cbmlvbi1jb250ZW50IC5pdGVtX2RpdiBpb24tcm93IC5zY3JvbGxfZGl2IHtcbiAgb3ZlcmZsb3c6IHNjcm9sbDtcbn1cbmlvbi1jb250ZW50IC5pdGVtX2RpdiBpb24tcm93IC5zY3JvbGxfZGl2IC5pdGVtIHtcbiAgd2lkdGg6IG1heC1jb250ZW50O1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogcm93O1xufVxuaW9uLWNvbnRlbnQgLml0ZW1fZGl2IGlvbi1yb3cgLnNjcm9sbF9kaXYgLml0ZW0gaW9uLWNoaXAge1xuICBoZWlnaHQ6IDUwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5pb24tY29udGVudCAubWFpbl9jb250ZW50IHtcbiAgcGFkZGluZzogMTBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbmlvbi1jb250ZW50IC5tYWluX2NvbnRlbnQgaW9uLXJvdyBpb24tY29sIC5pbWcge1xuICBoZWlnaHQ6IDkwcHg7XG4gIHdpZHRoOiA5MHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuaW9uLWNvbnRlbnQgLm1haW5fY29udGVudCBpb24tcm93IGlvbi1jb2wgLnRpdGxlIHtcbiAgZm9udC1mYW1pbHk6IFwicmVndWxhclwiO1xuICBkaXNwbGF5OiBmbGV4O1xuICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xuICBtYXJnaW4tdG9wOiAxMnB4O1xufVxuaW9uLWNvbnRlbnQgLm1haW5fY29udGVudCBpb24tcm93IGlvbi1jb2wgLnRpdGxlIC50dGwge1xuICBmb250LWZhbWlseTogXCJib2xkXCI7XG4gIGZvbnQtc2l6ZTogMTZweDtcbn1cbmlvbi1jb250ZW50IC5tYWluX2NvbnRlbnQgaW9uLXJvdyBpb24tY29sIC50aXRsZSAuc3ViX3R0bDEge1xuICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgbWFyZ2luOiAzcHggMHB4IDNweCAwcHg7XG4gIGNvbG9yOiAjMGEwMTAxO1xufVxuaW9uLWNvbnRlbnQgLm1haW5fY29udGVudCBpb24tcm93IGlvbi1jb2wgLnRpdGxlIC5zdWJfdHRsIHtcbiAgZm9udC1mYW1pbHk6IFwicmVndWxhclwiO1xuICBmb250LXNpemU6IDEzcHg7XG4gIG1hcmdpbjogM3B4IDBweCAzcHggMHB4O1xuICBjb2xvcjogIzA4MDAwMDtcbn1cbmlvbi1jb250ZW50IC5tYWluX2NvbnRlbnQgaW9uLXJvdyBpb24tY29sIC50aXRsZSAuaWNvbl90aXRsZSB7XG4gIGRpc3BsYXk6IGZsZXg7XG4gIGFsaWduLWl0ZW1zOiBjZW50ZXI7XG4gIGNvbG9yOiAjZmY3YzMxO1xuICBtYXJnaW46IDJweCAwcHggMnB4IDBweDtcbn1cbmlvbi1jb250ZW50IC5tYWluX2NvbnRlbnQgaW9uLXJvdyBpb24tY29sIC50aXRsZSAuaWNvbl90aXRsZSBpb24taWNvbiB7XG4gIGZvbnQtZmFtaWx5OiBcInJlZ3VsYXJcIjtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBtYXJnaW4tcmlnaHQ6IDVweDtcbn1cbmlvbi1jb250ZW50IC5tYWluX2NvbnRlbnQgaW9uLXJvdyBpb24tY29sIC50aXRsZSAuaWNvbl90aXRsZSBpb24tbGFiZWwge1xuICBmb250LXNpemU6IDEycHg7XG59XG5pb24tY29udGVudCAubWFpbl9jb250ZW50IC5saW5lIHtcbiAgd2lkdGg6IDEwMCU7XG4gIGJvcmRlci1ib3R0b206IDFweCBzb2xpZCBsaWdodGdyYXk7XG4gIG1hcmdpbjogMjBweCAwcHggMHB4IDBweDtcbn0iLCJpb24taGVhZGVyIHtcclxuICAgIGlvbi1sYWJlbHtcclxuICAgICAgZm9udC1zaXplOjEzcHg7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiBcInJlZ3VsYXJcIjtcclxuICAgICB9XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGlvbi1pdGVtIHtcclxuICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgaW9uLWF2YXRhciB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIGlvbi1jb250ZW50IHtcclxuICAgICoge1xyXG4gICAgICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XHJcbiAgICB9XHJcblxyXG4gICAgLnRpdGxlIHtcclxuICAgICAgZm9udC1mYW1pbHk6IFwicmVndWxhclwiO1xyXG4gICAgfVxyXG4gICAgLmljb25fdGl0bGUge1xyXG4gICAgICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XHJcbiAgICB9XHJcblxyXG4gICAgLm1haW4taGVhZGVyIHtcclxuICAgICAgaGVpZ2h0OjI2dmg7XHJcbiAgICAgIHdpZHRoOiAxNTAlO1xyXG4gICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoNDVkZWcsIHZhcigtLWlvbi1jb2xvci10ZXJ0aWFyeSkgMzAlLCB2YXIoLS1pb24tY29sb3ItcHJpbWFyeSkgMTAwJSk7XHJcbiAgICAgIGJveC1zaGFkb3c6IDAgMXB4IDMwcHggdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMCAwIDUwJSA1MCU7XHJcbiAgICAgIG1hcmdpbi1sZWZ0OiAtMTR2aDtcclxuICAgICAgbWFyZ2luLXRvcDogLTYwcHg7XHJcbiAgICB9XHJcbiAgICBpb24tZ3JpZCB7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBwb3NpdGlvbjogYWJzb2x1dGU7XHJcbiAgICAgIHRvcDogMzVweDtcclxuICAgICAgbGVmdDogMDtcclxuICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDEwdmgpO1xyXG4gICAgICBwYWRkaW5nLWJvdHRvbTogOHZoO1xyXG4gICAgICBpb24tcm93IHtcclxuICAgICAgICBpb24tY29sIHtcclxuICAgICAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgICAgIGlvbi1ub3RlIHtcclxuICAgICAgICAgICAgICBmb250LXNpemU6IDAuN3JlbTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpb24tY2hpcCB7XHJcbiAgICAgICAgICAgICAgaW9uLWxhYmVsIHtcclxuICAgICAgICAgICAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgICAgICAgICAgIGZvbnQtc2l6ZTogMS40cmVtO1xyXG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgICAgICAgICBsZXR0ZXItc3BhY2luZzogMC41cHg7XHJcbiAgICAgICAgICAgICAgICB0ZXh0LXNoYWRvdzogMXB4IDFweCAxcHggdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGIge1xyXG4gICAgICAgICAgICAgIGZvbnQtc2l6ZTogMS4ycmVtO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICAgICAgaGVpZ2h0OiAzZW0gIWltcG9ydGFudDtcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiB0cmFuc2xhdGVZKDEwJSk7XHJcbiAgICAgICAgICAgIHRleHQtdHJhbnNmb3JtOiBub25lO1xyXG4gICAgICAgICAgICBpb24tdGV4dCB7XHJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAwLjdyZW07XHJcbiAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IGJvbGQ7XHJcbiAgICAgICAgICAgICAgdGV4dC1zaGFkb3c6IDFweCAxcHggMXB4IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICAgICAgICBmb250LXNpemU6IDFyZW07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlvbi1jYXJkIHtcclxuICAgICAgICAgICAgYm94LXNoYWRvdzogLTFweCAxMXB4IDEwcHggLTZweCByZ2IoMjQ3LCAxNzksIDc4KTtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4ICFpbXBvcnRhbnQ7XHJcbiAgICAgICAgICAgIG1hcmdpbjo1cHggNXB4O1xyXG4gICAgICAgICAgICBpb24tdGh1bWJuYWlsIHtcclxuICAgICAgICAgICAgICB3aWR0aDoxMHZoO1xyXG4gICAgICAgICAgICAgIGhlaWdodDoxMHZoO1xyXG4gICAgICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICAgICAgICAgICAgaW1nIHtcclxuICAgICAgICAgICAgICAgIHdpZHRoOiAxMHZoO1xyXG4gICAgICAgICAgICAgICAgaGVpZ2h0OjEwdmg7XHJcbiAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMTAlKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW9uLWNhcmQtY29udGVudCB7XHJcbiAgICAgICAgICAgICAgaW9uLWxhYmVsIHtcclxuICAgICAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiByZWd1bGFyO1xyXG4gICAgICAgICAgICAgICAgdGV4dC1zaGFkb3c6IDFweCAxcHggMXB4IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xyXG4gICAgICAgICAgICAgICAgbGV0dGVyLXNwYWNpbmc6IDAuNXB4O1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBpb24tbGlzdCB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogdHJhbnNwYXJlbnQ7XHJcbiAgICAgICAgaW9uLWl0ZW0ge1xyXG4gICAgICAgICAgd2lkdGg6IDk1JTtcclxuICAgICAgICAgIG1hcmdpbjogYXV0bztcclxuICAgICAgICAgIGJvcmRlci1yYWRpdXM6IDVweDtcclxuICAgICAgICAgIG1hcmdpbi1ib3R0b206IDJ2aDtcclxuICAgICAgICAgIHAge1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDAuNjVyZW07XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBpb24tdGV4dCB7XHJcbiAgICAgICAgICAgIGZvbnQtd2VpZ2h0OiA4MDA7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgLypcclxuICAgIEF1dGhvcnMgOiBidW5jaGRldmVsb3BlcnMgKFJhaHVsIEpvZ3JhbmEpXHJcbiAgICBXZWJzaXRlIDogaHR0cHM6Ly9idW5jaGRldmVsb3BlcnMuY29tL1xyXG4gICAgQXBwIE5hbWUgOiBpb25pYzZUZW1wbGF0ZSBQYWNrXHJcbiAgICBUaGlzIEFwcCBUZW1wbGF0ZSBTb3VyY2UgY29kZSBpcyBsaWNlbnNlZCBhcyBwZXIgdGhlXHJcbiAgICB0ZXJtcyBmb3VuZCBpbiB0aGUgV2Vic2l0ZSBodHRwczovL2J1bmNoZGV2ZWxvcGVycy5jb20vbGljZW5zZVxyXG4gICAgQ29weXJpZ2h0IGFuZCBHb29kIEZhaXRoIFB1cmNoYXNlcnMgwqkgMjAyMS1wcmVzZW50IGJ1bmNoZGV2ZWxvcGVycy5cclxuICAqL1xyXG4gIGlvbi1oZWFkZXIge1xyXG4gICAgaW9uLXRvb2xiYXIge1xyXG4gICAgICBpb24tdGl0bGUge1xyXG4gICAgICAgIHBhZGRpbmc6IDBweDtcclxuICAgICAgICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XHJcbiAgICAgIH1cclxuICAgICAgaW9uLWJ1dHRvbnMge1xyXG4gICAgICAgIHBhZGRpbmc6IDVweCAycHggNXB4IDJweDtcclxuICAgICAgICBtYXJnaW46IDEwcHg7XHJcbiAgICAgICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgICAgICBoZWlnaHQ6IDQwcHg7XHJcbiAgICAgICAgICB3aWR0aDogNDBweDtcclxuICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcclxuICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgICBjb2xvcjogZ3JheTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgXHJcbiAgLml0ZW1fZGl2IHtcclxuICAgIGlvbi1yb3cge1xyXG4gICAgICAuc2Nyb2xsX2RpdiB7XHJcbiAgICAgICAgb3ZlcmZsb3c6IHNjcm9sbDtcclxuICAgICAgICAuaXRlbSB7XHJcbiAgICAgICAgICB3aWR0aDogbWF4LWNvbnRlbnQ7XHJcbiAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICAgICAgICAgIGlvbi1jaGlwIHtcclxuICAgICAgICAgICAgaGVpZ2h0OiA1MHB4O1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBcclxuICAubWFpbl9jb250ZW50IHtcclxuICAgIHBhZGRpbmc6IDEwcHg7XHJcbiAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgaW9uLXJvdyB7XHJcbiAgICAgIGlvbi1jb2wge1xyXG4gICAgICAgIC5pbWcge1xyXG4gICAgICAgICAgaGVpZ2h0OiA5MHB4O1xyXG4gICAgICAgICAgd2lkdGg6IDkwcHg7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyIGNlbnRlcjtcclxuICAgICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICAgICAgIH1cclxuICAgICAgICAudGl0bGUge1xyXG4gICAgICAgICAgZm9udC1mYW1pbHk6ICdyZWd1bGFyJztcclxuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogY29sdW1uO1xyXG4gICAgICAgICAgbWFyZ2luLXRvcDogMTJweDtcclxuICAgICAgICAgIC50dGwge1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogXCJib2xkXCI7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTZweDtcclxuICAgICAgICAgICBcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC5zdWJfdHRsMSB7XHJcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAncmVndWxhcic7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgICAgbWFyZ2luOiAzcHggMHB4IDNweCAwcHg7XHJcbiAgICAgICAgICAgIGNvbG9yOiByZ2IoMTAsIDEsIDEpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgLnN1Yl90dGwge1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogJ3JlZ3VsYXInO1xyXG4gICAgICAgICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgICAgICAgIG1hcmdpbjogM3B4IDBweCAzcHggMHB4O1xyXG4gICAgICAgICAgICBjb2xvcjogcmdiKDgsIDAsIDApO1xyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIC5pY29uX3RpdGxlIHtcclxuXHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmY3YzMxO1xyXG4gICAgICAgICAgICBtYXJnaW46IDJweCAwcHggMnB4IDBweDtcclxuICAgICAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgICAgIGZvbnQtZmFtaWx5OiAncmVndWxhcic7XHJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAubGluZSB7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgcmdiKDIxMSwgMjExLCAyMTEpO1xyXG4gICAgICBtYXJnaW46IDIwcHggMHB4IDBweCAwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG4gIFxyXG4gIFxyXG4gIFxyXG4gIH0iXX0= */";
    /***/
  },

  /***/
  "./src/app/catering/catering.page.ts":
  /*!*******************************************!*\
    !*** ./src/app/catering/catering.page.ts ***!
    \*******************************************/

  /*! exports provided: CateringPage */

  /***/
  function srcAppCateringCateringPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "CateringPage", function () {
      return CateringPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_services_util_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/services/util.service */
    "./src/app/services/util.service.ts");
    /*
      Authors : bunchdevelopers (Rahul Jograna)
      Website : https://bunchdevelopers.com/
      App Name : ionic6Template Pack
      This App Template Source code is licensed as per the
      terms found in the Website https://bunchdevelopers.com/license
      Copyright and Good Faith Purchasers © 2021-present bunchdevelopers.
    */


    var CateringPage = /*#__PURE__*/function () {
      function CateringPage(loadingController, router, util) {
        _classCallCheck(this, CateringPage);

        this.loadingController = loadingController;
        this.router = router;
        this.util = util;
        this.aduan = [{
          id: 1,
          name: '',
          src: '',
          background: '',
          page: ''
        }];
        this.rating = [{
          id: 1,
          name: '',
          src: '',
          background: '',
          page: ''
        }];
      }

      _createClass(CateringPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "onBack",
        value: function onBack() {
          this.router.navigate(['home']);
        }
      }, {
        key: "openAduancat",
        value: function openAduancat() {
          this.router.navigate(['aduancatering']);
        }
      }, {
        key: "openRatingcat",
        value: function openRatingcat() {
          this.router.navigate(['ratingcatering']);
        }
      }]);

      return CateringPage;
    }();

    CateringPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }, {
        type: src_app_services_util_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"]
      }];
    };

    CateringPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-catering',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./catering.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/catering/catering.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./catering.page.scss */
      "./src/app/catering/catering.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"], src_app_services_util_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"]])], CateringPage);
    /***/
  }
}]);
//# sourceMappingURL=catering-catering-module-es5.js.map