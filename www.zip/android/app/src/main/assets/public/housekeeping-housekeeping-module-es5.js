function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["housekeeping-housekeeping-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/housekeeping/housekeeping.page.html":
  /*!*******************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/housekeeping/housekeeping.page.html ***!
    \*******************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppHousekeepingHousekeepingPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-header class=\"ion-no-border\">\r\n  <ion-item lines=\"none\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-button (click)=\"util.openSideMenu()\">\r\n        <ion-icon name=\"menu\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-label color=\"light\">\r\n   Menu House Keeping\r\n  </ion-label>\r\n  <ion-buttons slot=\"end\">\r\n    <ion-icon (click)=\"onBack()\" name=\"arrow-undo\"></ion-icon>\r\n  </ion-buttons>\r\n  </ion-item>\r\n </ion-header>\r\n \r\n<ion-content [fullscreen]=\"true\" color=\"light\">\r\n  <div class=\"main-header\"></div>\r\n  <ion-grid><br>\r\n    <ion-note color=\"light\" class=\"ion-margin-start\">\r\n      <b></b> \r\n     </ion-note> \r\n<br>\r\n<br>\r\n     \r\n        <div class=\"main_content\" *ngFor=\"let item of aduanhkeeping\" (click)=\"openAdhkeeping()\">\r\n          <ion-row>\r\n            <ion-col size=\"5\"><br>\r\n              <div class=\"img\" [style.backgroundImage]=\"'url(assets/svg/online-survey.svg)'\"></div>\r\n            </ion-col>\r\n            <ion-col size=\"7\">\r\n              <div class=\"title\">\r\n                <ion-label color=\"dark\" class=\"ttl\">Aduan House Keeping</ion-label>\r\n                <ion-label class=\"sub_ttl1\">Form Isian Aduan Pelayanan House Keeping</ion-label>\r\n                <div class=\"icon_title\">\r\n                  <ion-icon slot=\"start\" name=\"star\"></ion-icon>\r\n                  <ion-label color=\"dark\" >Aduan Anda</ion-label>\r\n                </div>\r\n                <div class=\"icon_title\">\r\n                  <ion-icon slot=\"start\" name=\"location-sharp\"></ion-icon>\r\n                  <ion-label color=\"dark\">Deskripsi dan Lokasi</ion-label>\r\n                </div>\r\n              </div>\r\n            </ion-col>\r\n          </ion-row>\r\n         <div class=\"line\"></div>\r\n         </div>\r\n\r\n          <div class=\"main_content\" *ngFor=\"let item of tugas\" (click)=\"openTugas()\">\r\n          <ion-row>\r\n            <ion-col size=\"5\"><br>\r\n              <div class=\"img\" [style.backgroundImage]=\"'url(assets/svg/chat-favorite.svg)'\"></div>\r\n              </ion-col>\r\n              <ion-col size=\"7\">\r\n                <div class=\"title\">\r\n                  <ion-label class=\"ttl\">Tugas House Keeping</ion-label>\r\n                  <ion-label class=\"sub_ttl\">Silahkan Checklist Tugas Anda </ion-label>\r\n                  <div class=\"icon_title\">\r\n                    <div class=\"rate\">\r\n                      <ion-icon name=\"star\"></ion-icon>\r\n                      <ion-icon name=\"star\"></ion-icon>\r\n                      <ion-icon name=\"star\"></ion-icon>\r\n                      <ion-icon name=\"star\"></ion-icon>\r\n                      <ion-icon name=\"star\"></ion-icon>\r\n                    </div>\r\n                  </div>\r\n                  <div class=\"icon_title\">\r\n                    <ion-icon slot=\"start\" name=\"location-sharp\"></ion-icon>\r\n                    <ion-label color=\"dark\">Petunjuk?</ion-label>\r\n                  </div>\r\n                </div>\r\n              </ion-col>\r\n            </ion-row>\r\n           <div class=\"line\"></div>\r\n           </div>\r\n          </ion-grid>\r\n        </ion-content>\r\n\r\n";
    /***/
  },

  /***/
  "./src/app/housekeeping/housekeeping-routing.module.ts":
  /*!*************************************************************!*\
    !*** ./src/app/housekeeping/housekeeping-routing.module.ts ***!
    \*************************************************************/

  /*! exports provided: HousekeepingPageRoutingModule */

  /***/
  function srcAppHousekeepingHousekeepingRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HousekeepingPageRoutingModule", function () {
      return HousekeepingPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _housekeeping_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./housekeeping.page */
    "./src/app/housekeeping/housekeeping.page.ts");

    var routes = [{
      path: '',
      component: _housekeeping_page__WEBPACK_IMPORTED_MODULE_3__["HousekeepingPage"]
    }];

    var HousekeepingPageRoutingModule = /*#__PURE__*/_createClass(function HousekeepingPageRoutingModule() {
      _classCallCheck(this, HousekeepingPageRoutingModule);
    });

    HousekeepingPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], HousekeepingPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/housekeeping/housekeeping.module.ts":
  /*!*****************************************************!*\
    !*** ./src/app/housekeeping/housekeeping.module.ts ***!
    \*****************************************************/

  /*! exports provided: HousekeepingPageModule */

  /***/
  function srcAppHousekeepingHousekeepingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HousekeepingPageModule", function () {
      return HousekeepingPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _housekeeping_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./housekeeping-routing.module */
    "./src/app/housekeeping/housekeeping-routing.module.ts");
    /* harmony import */


    var _housekeeping_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./housekeeping.page */
    "./src/app/housekeeping/housekeeping.page.ts");

    var HousekeepingPageModule = /*#__PURE__*/_createClass(function HousekeepingPageModule() {
      _classCallCheck(this, HousekeepingPageModule);
    });

    HousekeepingPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _housekeeping_routing_module__WEBPACK_IMPORTED_MODULE_5__["HousekeepingPageRoutingModule"]],
      declarations: [_housekeeping_page__WEBPACK_IMPORTED_MODULE_6__["HousekeepingPage"]]
    })], HousekeepingPageModule);
    /***/
  },

  /***/
  "./src/app/housekeeping/housekeeping.page.scss":
  /*!*****************************************************!*\
    !*** ./src/app/housekeeping/housekeeping.page.scss ***!
    \*****************************************************/

  /*! exports provided: default */

  /***/
  function srcAppHousekeepingHousekeepingPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "@charset \"UTF-8\";\nion-header {\n  background: transparent;\n}\nion-header ion-label {\n  font-size: 13px;\n  font-family: \"regular\";\n}\nion-header ion-item {\n  --background: transparent;\n}\nion-header ion-item ion-avatar {\n  background: white;\n}\nion-label {\n  font-size: 7px;\n}\nion-content {\n  /*\n    Authors : bunchdevelopers (Rahul Jograna)\n    Website : https://bunchdevelopers.com/\n    App Name : ionic6Template Pack\n    This App Template Source code is licensed as per the\n    terms found in the Website https://bunchdevelopers.com/license\n    Copyright and Good Faith Purchasers © 2021-present bunchdevelopers.\n  */\n}\nion-content * {\n  font-family: poppins;\n}\nion-content .main-header {\n  height: 25vh;\n  width: 150%;\n  background: linear-gradient(45deg, var(--ion-color-tertiary) 30%, var(--ion-color-primary) 100%);\n  box-shadow: 0 1px 30px var(--ion-color-light);\n  border-radius: 0 0 50% 50%;\n  margin-left: -14vh;\n  margin-top: -60px;\n}\nion-content ion-grid {\n  width: 100%;\n  position: absolute;\n  top: 35px;\n  left: 0;\n  transform: translateY(10vh);\n  padding-bottom: 8vh;\n}\nion-content ion-grid ion-row ion-col ion-label ion-note {\n  font-size: 0.2rem;\n}\nion-content ion-grid ion-row ion-col ion-label ion-chip ion-label {\n  position: absolute;\n  font-size: 1.4rem;\n  font-weight: bold;\n  letter-spacing: 0.5px;\n  text-shadow: 1px 1px 1px var(--ion-color-medium);\n}\nion-content ion-grid ion-row ion-col ion-label b {\n  font-size: 1.2rem;\n}\nion-content ion-grid ion-row ion-col ion-button {\n  height: 3em !important;\n  transform: translateY(10%);\n  text-transform: none;\n}\nion-content ion-grid ion-row ion-col ion-button ion-text {\n  font-size: 0.7rem;\n  font-weight: bold;\n  text-shadow: 1px 1px 1px var(--ion-color-medium);\n}\nion-content ion-grid ion-row ion-col ion-button ion-icon {\n  font-size: 1rem;\n}\nion-content ion-grid ion-row ion-col ion-card {\n  box-shadow: -1px 11px 10px -6px #f7b34e;\n  border-radius: 5px !important;\n  margin: 5px 5px;\n}\nion-content ion-grid ion-row ion-col ion-card ion-thumbnail {\n  width: 10vh;\n  height: 10vh;\n  border-radius: 10px;\n}\nion-content ion-grid ion-row ion-col ion-card ion-thumbnail img {\n  width: 10vh;\n  height: 10vh;\n  transform: translateY(10%);\n}\nion-content ion-grid ion-row ion-col ion-card ion-card-content ion-label {\n  font-weight: regular;\n  text-shadow: 1px 1px 1px var(--ion-color-medium);\n  letter-spacing: 0.5px;\n}\nion-content ion-grid ion-list {\n  background: transparent;\n}\nion-content ion-grid ion-list ion-item {\n  width: 95%;\n  margin: auto;\n  border-radius: 5px;\n  margin-bottom: 2vh;\n}\nion-content ion-grid ion-list ion-item p {\n  font-size: 0.65rem;\n}\nion-content ion-grid ion-list ion-item ion-text {\n  font-weight: 800;\n}\nion-content ion-header ion-toolbar ion-title {\n  padding: 0px;\n  font-family: \"regular\";\n}\nion-content ion-header ion-toolbar ion-buttons {\n  padding: 5px 2px 5px 2px;\n  margin: 10px;\n}\nion-content ion-header ion-toolbar ion-buttons ion-button {\n  height: 40px;\n  width: 40px;\n  border: 1px solid lightgray;\n  --border-radius: 50%;\n  border-radius: 50%;\n}\nion-content ion-header ion-toolbar ion-buttons ion-button ion-icon {\n  color: gray;\n}\nion-content .item_div ion-row .scroll_div {\n  overflow: scroll;\n}\nion-content .item_div ion-row .scroll_div .item {\n  width: -webkit-max-content;\n  width: -moz-max-content;\n  width: max-content;\n  display: flex;\n  flex-direction: row;\n}\nion-content .item_div ion-row .scroll_div .item ion-chip {\n  height: 50px;\n  border-radius: 10px;\n}\nion-content .main_content {\n  padding: 10px;\n  border-radius: 10px;\n}\nion-content .main_content ion-row ion-col .img {\n  height: 100px;\n  width: 100px;\n  border-radius: 10px;\n  background-position: center center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\nion-content .main_content ion-row ion-col .title {\n  display: flex;\n  flex-direction: column;\n  margin-top: 12px;\n}\nion-content .main_content ion-row ion-col .title .ttl {\n  font-size: 14px;\n  font-family: \"bold\";\n}\nion-content .main_content ion-row ion-col .title .sub_ttl1 {\n  font-size: 13px;\n  margin: 3px 0px 3px 0px;\n  color: #0c0101;\n  font-family: \"regular\";\n}\nion-content .main_content ion-row ion-col .title .sub_ttl {\n  font-size: 13px;\n  margin: 3px 0px 3px 0px;\n  color: #080000;\n  font-family: \"regular\";\n}\nion-content .main_content ion-row ion-col .title .icon_title {\n  display: flex;\n  align-items: center;\n  color: #ff7c31;\n  margin: 2px 0px 2px 0px;\n}\nion-content .main_content ion-row ion-col .title .icon_title ion-icon {\n  font-size: 20px;\n  margin-right: 5px;\n}\nion-content .main_content ion-row ion-col .title .icon_title ion-label {\n  font-size: 12px;\n}\nion-content .main_content .line {\n  width: 100%;\n  border-bottom: 1px solid lightgray;\n  margin: 20px 0px 0px 0px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvaG91c2VrZWVwaW5nL2hvdXNla2VlcGluZy5wYWdlLnNjc3MiLCJzcmMvYXBwL2hvdXNla2VlcGluZy9FOlxcYXNhc2VydmFuZHJvaWQvc3JjXFxhcHBcXGhvdXNla2VlcGluZ1xcaG91c2VrZWVwaW5nLnBhZ2Uuc2NzcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiQUFBQSxnQkFBZ0I7QUNBaEI7RUFLSSx1QkFBQTtBREZKO0FDRkk7RUFDRSxlQUFBO0VBQ0Esc0JBQUE7QURJTjtBQ0RJO0VBQ0UseUJBQUE7QURHTjtBQ0ZNO0VBQ0UsaUJBQUE7QURJUjtBQ0NFO0VBQ0UsY0FBQTtBREVKO0FDQ0U7RUE2RkE7Ozs7Ozs7R0FBQTtBRG5GRjtBQ1RJO0VBQ0Usb0JBQUE7QURXTjtBQ1JJO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSxnR0FBQTtFQUNBLDZDQUFBO0VBQ0EsMEJBQUE7RUFDQSxrQkFBQTtFQUNBLGlCQUFBO0FEVU47QUNSSTtFQUNFLFdBQUE7RUFDQSxrQkFBQTtFQUNBLFNBQUE7RUFDQSxPQUFBO0VBQ0EsMkJBQUE7RUFDQSxtQkFBQTtBRFVOO0FDTlk7RUFDRSxpQkFBQTtBRFFkO0FDTGM7RUFDRSxrQkFBQTtFQUNBLGlCQUFBO0VBQ0EsaUJBQUE7RUFDQSxxQkFBQTtFQUNBLGdEQUFBO0FET2hCO0FDSlk7RUFDRSxpQkFBQTtBRE1kO0FDSFU7RUFDRSxzQkFBQTtFQUNBLDBCQUFBO0VBQ0Esb0JBQUE7QURLWjtBQ0pZO0VBQ0UsaUJBQUE7RUFDQSxpQkFBQTtFQUNBLGdEQUFBO0FETWQ7QUNKWTtFQUNFLGVBQUE7QURNZDtBQ0hVO0VBQ0UsdUNBQUE7RUFDQSw2QkFBQTtFQUNBLGVBQUE7QURLWjtBQ0pZO0VBQ0UsV0FBQTtFQUNBLFlBQUE7RUFDQSxtQkFBQTtBRE1kO0FDTGM7RUFDRSxXQUFBO0VBQ0EsWUFBQTtFQUNBLDBCQUFBO0FET2hCO0FDSGM7RUFDRSxvQkFBQTtFQUNBLGdEQUFBO0VBQ0EscUJBQUE7QURLaEI7QUNDTTtFQUNFLHVCQUFBO0FEQ1I7QUNBUTtFQUNFLFVBQUE7RUFDQSxZQUFBO0VBQ0Esa0JBQUE7RUFDQSxrQkFBQTtBREVWO0FDRFU7RUFDRSxrQkFBQTtBREdaO0FDRFU7RUFDRSxnQkFBQTtBREdaO0FDWU07RUFDRSxZQUFBO0VBQ0Esc0JBQUE7QURWUjtBQ1lNO0VBQ0Usd0JBQUE7RUFDQSxZQUFBO0FEVlI7QUNXUTtFQUNFLFlBQUE7RUFDQSxXQUFBO0VBQ0EsMkJBQUE7RUFDQSxvQkFBQTtFQUNBLGtCQUFBO0FEVFY7QUNVVTtFQUNFLFdBQUE7QURSWjtBQ2lCSztFQUNHLGdCQUFBO0FEZlI7QUNnQlE7RUFDRSwwQkFBQTtFQUFBLHVCQUFBO0VBQUEsa0JBQUE7RUFDQSxhQUFBO0VBQ0EsbUJBQUE7QURkVjtBQ2VVO0VBQ0UsWUFBQTtFQUNBLG1CQUFBO0FEYlo7QUNvQkU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7QURsQko7QUNxQlE7RUFDRSxhQUFBO0VBQ0EsWUFBQTtFQUNBLG1CQUFBO0VBQ0Esa0NBQUE7RUFDQSw0QkFBQTtFQUNBLHNCQUFBO0FEbkJWO0FDcUJRO0VBQ0UsYUFBQTtFQUNBLHNCQUFBO0VBQ0EsZ0JBQUE7QURuQlY7QUNvQlU7RUFDRSxlQUFBO0VBQ0EsbUJBQUE7QURsQlo7QUNxQlU7RUFDRSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxjQUFBO0VBQ0Esc0JBQUE7QURuQlo7QUNxQlU7RUFDRSxlQUFBO0VBQ0EsdUJBQUE7RUFDQSxjQUFBO0VBQ0Esc0JBQUE7QURuQlo7QUNzQlU7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsdUJBQUE7QURwQlo7QUNxQlk7RUFDRSxlQUFBO0VBQ0EsaUJBQUE7QURuQmQ7QUNxQlk7RUFDRSxlQUFBO0FEbkJkO0FDeUJJO0VBQ0UsV0FBQTtFQUNBLGtDQUFBO0VBQ0Esd0JBQUE7QUR2Qk4iLCJmaWxlIjoic3JjL2FwcC9ob3VzZWtlZXBpbmcvaG91c2VrZWVwaW5nLnBhZ2Uuc2NzcyIsInNvdXJjZXNDb250ZW50IjpbIkBjaGFyc2V0IFwiVVRGLThcIjtcbmlvbi1oZWFkZXIge1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cbmlvbi1oZWFkZXIgaW9uLWxhYmVsIHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XG59XG5pb24taGVhZGVyIGlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cbmlvbi1oZWFkZXIgaW9uLWl0ZW0gaW9uLWF2YXRhciB7XG4gIGJhY2tncm91bmQ6IHdoaXRlO1xufVxuXG5pb24tbGFiZWwge1xuICBmb250LXNpemU6IDdweDtcbn1cblxuaW9uLWNvbnRlbnQge1xuICAvKlxuICAgIEF1dGhvcnMgOiBidW5jaGRldmVsb3BlcnMgKFJhaHVsIEpvZ3JhbmEpXG4gICAgV2Vic2l0ZSA6IGh0dHBzOi8vYnVuY2hkZXZlbG9wZXJzLmNvbS9cbiAgICBBcHAgTmFtZSA6IGlvbmljNlRlbXBsYXRlIFBhY2tcbiAgICBUaGlzIEFwcCBUZW1wbGF0ZSBTb3VyY2UgY29kZSBpcyBsaWNlbnNlZCBhcyBwZXIgdGhlXG4gICAgdGVybXMgZm91bmQgaW4gdGhlIFdlYnNpdGUgaHR0cHM6Ly9idW5jaGRldmVsb3BlcnMuY29tL2xpY2Vuc2VcbiAgICBDb3B5cmlnaHQgYW5kIEdvb2QgRmFpdGggUHVyY2hhc2VycyDCqSAyMDIxLXByZXNlbnQgYnVuY2hkZXZlbG9wZXJzLlxuICAqL1xufVxuaW9uLWNvbnRlbnQgKiB7XG4gIGZvbnQtZmFtaWx5OiBwb3BwaW5zO1xufVxuaW9uLWNvbnRlbnQgLm1haW4taGVhZGVyIHtcbiAgaGVpZ2h0OiAyNXZoO1xuICB3aWR0aDogMTUwJTtcbiAgYmFja2dyb3VuZDogbGluZWFyLWdyYWRpZW50KDQ1ZGVnLCB2YXIoLS1pb24tY29sb3ItdGVydGlhcnkpIDMwJSwgdmFyKC0taW9uLWNvbG9yLXByaW1hcnkpIDEwMCUpO1xuICBib3gtc2hhZG93OiAwIDFweCAzMHB4IHZhcigtLWlvbi1jb2xvci1saWdodCk7XG4gIGJvcmRlci1yYWRpdXM6IDAgMCA1MCUgNTAlO1xuICBtYXJnaW4tbGVmdDogLTE0dmg7XG4gIG1hcmdpbi10b3A6IC02MHB4O1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQge1xuICB3aWR0aDogMTAwJTtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICB0b3A6IDM1cHg7XG4gIGxlZnQ6IDA7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgxMHZoKTtcbiAgcGFkZGluZy1ib3R0b206IDh2aDtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1yb3cgaW9uLWNvbCBpb24tbGFiZWwgaW9uLW5vdGUge1xuICBmb250LXNpemU6IDAuMnJlbTtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1yb3cgaW9uLWNvbCBpb24tbGFiZWwgaW9uLWNoaXAgaW9uLWxhYmVsIHtcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBmb250LXNpemU6IDEuNHJlbTtcbiAgZm9udC13ZWlnaHQ6IGJvbGQ7XG4gIGxldHRlci1zcGFjaW5nOiAwLjVweDtcbiAgdGV4dC1zaGFkb3c6IDFweCAxcHggMXB4IHZhcigtLWlvbi1jb2xvci1tZWRpdW0pO1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLXJvdyBpb24tY29sIGlvbi1sYWJlbCBiIHtcbiAgZm9udC1zaXplOiAxLjJyZW07XG59XG5pb24tY29udGVudCBpb24tZ3JpZCBpb24tcm93IGlvbi1jb2wgaW9uLWJ1dHRvbiB7XG4gIGhlaWdodDogM2VtICFpbXBvcnRhbnQ7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgxMCUpO1xuICB0ZXh0LXRyYW5zZm9ybTogbm9uZTtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1yb3cgaW9uLWNvbCBpb24tYnV0dG9uIGlvbi10ZXh0IHtcbiAgZm9udC1zaXplOiAwLjdyZW07XG4gIGZvbnQtd2VpZ2h0OiBib2xkO1xuICB0ZXh0LXNoYWRvdzogMXB4IDFweCAxcHggdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XG59XG5pb24tY29udGVudCBpb24tZ3JpZCBpb24tcm93IGlvbi1jb2wgaW9uLWJ1dHRvbiBpb24taWNvbiB7XG4gIGZvbnQtc2l6ZTogMXJlbTtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1yb3cgaW9uLWNvbCBpb24tY2FyZCB7XG4gIGJveC1zaGFkb3c6IC0xcHggMTFweCAxMHB4IC02cHggI2Y3YjM0ZTtcbiAgYm9yZGVyLXJhZGl1czogNXB4ICFpbXBvcnRhbnQ7XG4gIG1hcmdpbjogNXB4IDVweDtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1yb3cgaW9uLWNvbCBpb24tY2FyZCBpb24tdGh1bWJuYWlsIHtcbiAgd2lkdGg6IDEwdmg7XG4gIGhlaWdodDogMTB2aDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1yb3cgaW9uLWNvbCBpb24tY2FyZCBpb24tdGh1bWJuYWlsIGltZyB7XG4gIHdpZHRoOiAxMHZoO1xuICBoZWlnaHQ6IDEwdmg7XG4gIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgxMCUpO1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLXJvdyBpb24tY29sIGlvbi1jYXJkIGlvbi1jYXJkLWNvbnRlbnQgaW9uLWxhYmVsIHtcbiAgZm9udC13ZWlnaHQ6IHJlZ3VsYXI7XG4gIHRleHQtc2hhZG93OiAxcHggMXB4IDFweCB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcbiAgbGV0dGVyLXNwYWNpbmc6IDAuNXB4O1xufVxuaW9uLWNvbnRlbnQgaW9uLWdyaWQgaW9uLWxpc3Qge1xuICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1saXN0IGlvbi1pdGVtIHtcbiAgd2lkdGg6IDk1JTtcbiAgbWFyZ2luOiBhdXRvO1xuICBib3JkZXItcmFkaXVzOiA1cHg7XG4gIG1hcmdpbi1ib3R0b206IDJ2aDtcbn1cbmlvbi1jb250ZW50IGlvbi1ncmlkIGlvbi1saXN0IGlvbi1pdGVtIHAge1xuICBmb250LXNpemU6IDAuNjVyZW07XG59XG5pb24tY29udGVudCBpb24tZ3JpZCBpb24tbGlzdCBpb24taXRlbSBpb24tdGV4dCB7XG4gIGZvbnQtd2VpZ2h0OiA4MDA7XG59XG5pb24tY29udGVudCBpb24taGVhZGVyIGlvbi10b29sYmFyIGlvbi10aXRsZSB7XG4gIHBhZGRpbmc6IDBweDtcbiAgZm9udC1mYW1pbHk6IFwicmVndWxhclwiO1xufVxuaW9uLWNvbnRlbnQgaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tYnV0dG9ucyB7XG4gIHBhZGRpbmc6IDVweCAycHggNXB4IDJweDtcbiAgbWFyZ2luOiAxMHB4O1xufVxuaW9uLWNvbnRlbnQgaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tYnV0dG9ucyBpb24tYnV0dG9uIHtcbiAgaGVpZ2h0OiA0MHB4O1xuICB3aWR0aDogNDBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xuICAtLWJvcmRlci1yYWRpdXM6IDUwJTtcbiAgYm9yZGVyLXJhZGl1czogNTAlO1xufVxuaW9uLWNvbnRlbnQgaW9uLWhlYWRlciBpb24tdG9vbGJhciBpb24tYnV0dG9ucyBpb24tYnV0dG9uIGlvbi1pY29uIHtcbiAgY29sb3I6IGdyYXk7XG59XG5pb24tY29udGVudCAuaXRlbV9kaXYgaW9uLXJvdyAuc2Nyb2xsX2RpdiB7XG4gIG92ZXJmbG93OiBzY3JvbGw7XG59XG5pb24tY29udGVudCAuaXRlbV9kaXYgaW9uLXJvdyAuc2Nyb2xsX2RpdiAuaXRlbSB7XG4gIHdpZHRoOiBtYXgtY29udGVudDtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbn1cbmlvbi1jb250ZW50IC5pdGVtX2RpdiBpb24tcm93IC5zY3JvbGxfZGl2IC5pdGVtIGlvbi1jaGlwIHtcbiAgaGVpZ2h0OiA1MHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xufVxuaW9uLWNvbnRlbnQgLm1haW5fY29udGVudCB7XG4gIHBhZGRpbmc6IDEwcHg7XG4gIGJvcmRlci1yYWRpdXM6IDEwcHg7XG59XG5pb24tY29udGVudCAubWFpbl9jb250ZW50IGlvbi1yb3cgaW9uLWNvbCAuaW1nIHtcbiAgaGVpZ2h0OiAxMDBweDtcbiAgd2lkdGg6IDEwMHB4O1xuICBib3JkZXItcmFkaXVzOiAxMHB4O1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuaW9uLWNvbnRlbnQgLm1haW5fY29udGVudCBpb24tcm93IGlvbi1jb2wgLnRpdGxlIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IGNvbHVtbjtcbiAgbWFyZ2luLXRvcDogMTJweDtcbn1cbmlvbi1jb250ZW50IC5tYWluX2NvbnRlbnQgaW9uLXJvdyBpb24tY29sIC50aXRsZSAudHRsIHtcbiAgZm9udC1zaXplOiAxNHB4O1xuICBmb250LWZhbWlseTogXCJib2xkXCI7XG59XG5pb24tY29udGVudCAubWFpbl9jb250ZW50IGlvbi1yb3cgaW9uLWNvbCAudGl0bGUgLnN1Yl90dGwxIHtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBtYXJnaW46IDNweCAwcHggM3B4IDBweDtcbiAgY29sb3I6ICMwYzAxMDE7XG4gIGZvbnQtZmFtaWx5OiBcInJlZ3VsYXJcIjtcbn1cbmlvbi1jb250ZW50IC5tYWluX2NvbnRlbnQgaW9uLXJvdyBpb24tY29sIC50aXRsZSAuc3ViX3R0bCB7XG4gIGZvbnQtc2l6ZTogMTNweDtcbiAgbWFyZ2luOiAzcHggMHB4IDNweCAwcHg7XG4gIGNvbG9yOiAjMDgwMDAwO1xuICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XG59XG5pb24tY29udGVudCAubWFpbl9jb250ZW50IGlvbi1yb3cgaW9uLWNvbCAudGl0bGUgLmljb25fdGl0bGUge1xuICBkaXNwbGF5OiBmbGV4O1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBjb2xvcjogI2ZmN2MzMTtcbiAgbWFyZ2luOiAycHggMHB4IDJweCAwcHg7XG59XG5pb24tY29udGVudCAubWFpbl9jb250ZW50IGlvbi1yb3cgaW9uLWNvbCAudGl0bGUgLmljb25fdGl0bGUgaW9uLWljb24ge1xuICBmb250LXNpemU6IDIwcHg7XG4gIG1hcmdpbi1yaWdodDogNXB4O1xufVxuaW9uLWNvbnRlbnQgLm1haW5fY29udGVudCBpb24tcm93IGlvbi1jb2wgLnRpdGxlIC5pY29uX3RpdGxlIGlvbi1sYWJlbCB7XG4gIGZvbnQtc2l6ZTogMTJweDtcbn1cbmlvbi1jb250ZW50IC5tYWluX2NvbnRlbnQgLmxpbmUge1xuICB3aWR0aDogMTAwJTtcbiAgYm9yZGVyLWJvdHRvbTogMXB4IHNvbGlkIGxpZ2h0Z3JheTtcbiAgbWFyZ2luOiAyMHB4IDBweCAwcHggMHB4O1xufSIsImlvbi1oZWFkZXIge1xyXG4gICAgaW9uLWxhYmVse1xyXG4gICAgICBmb250LXNpemU6MTNweDtcclxuICAgICAgZm9udC1mYW1pbHk6ICdyZWd1bGFyJztcclxuICAgICB9XHJcbiAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGlvbi1pdGVtIHtcclxuICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgaW9uLWF2YXRhciB7XHJcbiAgICAgICAgYmFja2dyb3VuZDogd2hpdGU7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgXHJcbiAgaW9uLWxhYmVse1xyXG4gICAgZm9udC1zaXplOjdweDtcclxuICBcclxuICB9XHJcbiAgaW9uLWNvbnRlbnQge1xyXG4gICAgKiB7XHJcbiAgICAgIGZvbnQtZmFtaWx5OnBvcHBpbnM7XHJcbiAgICB9XHJcbiAgXHJcbiAgICAubWFpbi1oZWFkZXIge1xyXG4gICAgICBoZWlnaHQ6MjV2aDtcclxuICAgICAgd2lkdGg6IDE1MCU7XHJcbiAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg0NWRlZywgdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KSAzMCUsIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAxMDAlKTtcclxuICAgICAgYm94LXNoYWRvdzogMCAxcHggMzBweCB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xyXG4gICAgICBib3JkZXItcmFkaXVzOiAwIDAgNTAlIDUwJTtcclxuICAgICAgbWFyZ2luLWxlZnQ6IC0xNHZoO1xyXG4gICAgICBtYXJnaW4tdG9wOiAtNjBweDtcclxuICAgIH1cclxuICAgIGlvbi1ncmlkIHtcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgdG9wOiAzNXB4O1xyXG4gICAgICBsZWZ0OiAwO1xyXG4gICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMTB2aCk7XHJcbiAgICAgIHBhZGRpbmctYm90dG9tOiA4dmg7XHJcbiAgICAgIGlvbi1yb3cge1xyXG4gICAgICAgIGlvbi1jb2wge1xyXG4gICAgICAgICAgaW9uLWxhYmVsIHtcclxuICAgICAgICAgICAgaW9uLW5vdGUge1xyXG4gICAgICAgICAgICAgIGZvbnQtc2l6ZTogMC4ycmVtO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlvbi1jaGlwIHtcclxuICAgICAgICAgICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgICAgICAgZm9udC1zaXplOiAxLjRyZW07XHJcbiAgICAgICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgICAgICAgIGxldHRlci1zcGFjaW5nOiAwLjVweDtcclxuICAgICAgICAgICAgICAgIHRleHQtc2hhZG93OiAxcHggMXB4IDFweCB2YXIoLS1pb24tY29sb3ItbWVkaXVtKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYiB7XHJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAxLjJyZW07XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDNlbSAhaW1wb3J0YW50O1xyXG4gICAgICAgICAgICB0cmFuc2Zvcm06IHRyYW5zbGF0ZVkoMTAlKTtcclxuICAgICAgICAgICAgdGV4dC10cmFuc2Zvcm06IG5vbmU7XHJcbiAgICAgICAgICAgIGlvbi10ZXh0IHtcclxuICAgICAgICAgICAgICBmb250LXNpemU6IDAuN3JlbTtcclxuICAgICAgICAgICAgICBmb250LXdlaWdodDogYm9sZDtcclxuICAgICAgICAgICAgICB0ZXh0LXNoYWRvdzogMXB4IDFweCAxcHggdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaW9uLWljb24ge1xyXG4gICAgICAgICAgICAgIGZvbnQtc2l6ZTogMXJlbTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgaW9uLWNhcmQge1xyXG4gICAgICAgICAgICBib3gtc2hhZG93OiAtMXB4IDExcHggMTBweCAtNnB4IHJnYigyNDcsIDE3OSwgNzgpO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1cHggIWltcG9ydGFudDtcclxuICAgICAgICAgICAgbWFyZ2luOjVweCA1cHg7XHJcbiAgICAgICAgICAgIGlvbi10aHVtYm5haWwge1xyXG4gICAgICAgICAgICAgIHdpZHRoOjEwdmg7XHJcbiAgICAgICAgICAgICAgaGVpZ2h0OjEwdmg7XHJcbiAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgICAgICAgICBpbWcge1xyXG4gICAgICAgICAgICAgICAgd2lkdGg6IDEwdmg7XHJcbiAgICAgICAgICAgICAgICBoZWlnaHQ6MTB2aDtcclxuICAgICAgICAgICAgICAgIHRyYW5zZm9ybTogdHJhbnNsYXRlWSgxMCUpO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpb24tY2FyZC1jb250ZW50IHtcclxuICAgICAgICAgICAgICBpb24tbGFiZWwge1xyXG4gICAgICAgICAgICAgICAgZm9udC13ZWlnaHQ6IHJlZ3VsYXI7XHJcbiAgICAgICAgICAgICAgICB0ZXh0LXNoYWRvdzogMXB4IDFweCAxcHggdmFyKC0taW9uLWNvbG9yLW1lZGl1bSk7XHJcbiAgICAgICAgICAgICAgICBsZXR0ZXItc3BhY2luZzogMC41cHg7XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGlvbi1saXN0IHtcclxuICAgICAgICBiYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgICBpb24taXRlbSB7XHJcbiAgICAgICAgICB3aWR0aDogOTUlO1xyXG4gICAgICAgICAgbWFyZ2luOiBhdXRvO1xyXG4gICAgICAgICAgYm9yZGVyLXJhZGl1czogNXB4O1xyXG4gICAgICAgICAgbWFyZ2luLWJvdHRvbTogMnZoO1xyXG4gICAgICAgICAgcCB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMC42NXJlbTtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlvbi10ZXh0IHtcclxuICAgICAgICAgICAgZm9udC13ZWlnaHQ6IDgwMDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAvKlxyXG4gICAgQXV0aG9ycyA6IGJ1bmNoZGV2ZWxvcGVycyAoUmFodWwgSm9ncmFuYSlcclxuICAgIFdlYnNpdGUgOiBodHRwczovL2J1bmNoZGV2ZWxvcGVycy5jb20vXHJcbiAgICBBcHAgTmFtZSA6IGlvbmljNlRlbXBsYXRlIFBhY2tcclxuICAgIFRoaXMgQXBwIFRlbXBsYXRlIFNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIGFzIHBlciB0aGVcclxuICAgIHRlcm1zIGZvdW5kIGluIHRoZSBXZWJzaXRlIGh0dHBzOi8vYnVuY2hkZXZlbG9wZXJzLmNvbS9saWNlbnNlXHJcbiAgICBDb3B5cmlnaHQgYW5kIEdvb2QgRmFpdGggUHVyY2hhc2VycyDCqSAyMDIxLXByZXNlbnQgYnVuY2hkZXZlbG9wZXJzLlxyXG4gICovXHJcbiAgaW9uLWhlYWRlciB7XHJcbiAgICBpb24tdG9vbGJhciB7XHJcbiAgICAgIGlvbi10aXRsZSB7XHJcbiAgICAgICAgcGFkZGluZzogMHB4O1xyXG4gICAgICAgIGZvbnQtZmFtaWx5OiBcInJlZ3VsYXJcIjtcclxuICAgICAgfVxyXG4gICAgICBpb24tYnV0dG9ucyB7XHJcbiAgICAgICAgcGFkZGluZzogNXB4IDJweCA1cHggMnB4O1xyXG4gICAgICAgIG1hcmdpbjogMTBweDtcclxuICAgICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICAgIGhlaWdodDogNDBweDtcclxuICAgICAgICAgIHdpZHRoOiA0MHB4O1xyXG4gICAgICAgICAgYm9yZGVyOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG4gICAgICAgICAgLS1ib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICAgIGNvbG9yOiBncmF5O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBcclxuICAuaXRlbV9kaXYge1xyXG4gICAgaW9uLXJvdyB7XHJcbiAgICAgLnNjcm9sbF9kaXYge1xyXG4gICAgICAgIG92ZXJmbG93OiBzY3JvbGw7XHJcbiAgICAgICAgLml0ZW0ge1xyXG4gICAgICAgICAgd2lkdGg6IG1heC1jb250ZW50O1xyXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICAgICAgICBpb24tY2hpcCB7XHJcbiAgICAgICAgICAgIGhlaWdodDogNTBweDtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgXHJcbiAgLm1haW5fY29udGVudCB7XHJcbiAgICBwYWRkaW5nOiAxMHB4O1xyXG4gICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgIGlvbi1yb3cge1xyXG4gICAgICBpb24tY29sIHtcclxuICAgICAgICAuaW1nIHtcclxuICAgICAgICAgIGhlaWdodDogMTAwcHg7XHJcbiAgICAgICAgICB3aWR0aDogMTAwcHg7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiAxMHB4O1xyXG4gICAgICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyIGNlbnRlcjtcclxuICAgICAgICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICAgICAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICAgICAgIH1cclxuICAgICAgICAudGl0bGUge1xyXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgIGZsZXgtZGlyZWN0aW9uOiBjb2x1bW47XHJcbiAgICAgICAgICBtYXJnaW4tdG9wOiAxMnB4O1xyXG4gICAgICAgICAgLnR0bCB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTRweDtcclxuICAgICAgICAgICAgZm9udC1mYW1pbHk6IFwiYm9sZFwiO1xyXG4gICAgICAgICAgICBcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIC5zdWJfdHRsMSB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgICAgbWFyZ2luOiAzcHggMHB4IDNweCAwcHg7XHJcbiAgICAgICAgICAgIGNvbG9yOiByZ2IoMTIsIDEsIDEpO1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICAuc3ViX3R0bCB7XHJcbiAgICAgICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICAgICAgbWFyZ2luOiAzcHggMHB4IDNweCAwcHg7XHJcbiAgICAgICAgICAgIGNvbG9yOiByZ2IoOCwgMCwgMCk7XHJcbiAgICAgICAgICAgIGZvbnQtZmFtaWx5OiBcInJlZ3VsYXJcIjtcclxuICAgICAgICAgIH1cclxuICBcclxuICAgICAgICAgIC5pY29uX3RpdGxlIHtcclxuICAgICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgICAgICAgY29sb3I6ICNmZjdjMzE7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMnB4IDBweCAycHggMHB4O1xyXG4gICAgICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4O1xyXG4gICAgICAgICAgICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgICAgICAgZm9udC1zaXplOiAxMnB4O1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICAubGluZSB7XHJcbiAgICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgICBib3JkZXItYm90dG9tOiAxcHggc29saWQgbGlnaHRncmF5O1xyXG4gICAgICBtYXJnaW46IDIwcHggMHB4IDBweCAwcHg7XHJcbiAgICB9XHJcbiAgfVxyXG4gIFxyXG4gIFxyXG4gIFxyXG4gIH0iXX0= */";
    /***/
  },

  /***/
  "./src/app/housekeeping/housekeeping.page.ts":
  /*!***************************************************!*\
    !*** ./src/app/housekeeping/housekeeping.page.ts ***!
    \***************************************************/

  /*! exports provided: HousekeepingPage */

  /***/
  function srcAppHousekeepingHousekeepingPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "HousekeepingPage", function () {
      return HousekeepingPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var src_app_services_util_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! src/app/services/util.service */
    "./src/app/services/util.service.ts");

    var HousekeepingPage = /*#__PURE__*/function () {
      function HousekeepingPage(loadingController, util, router) {
        _classCallCheck(this, HousekeepingPage);

        this.loadingController = loadingController;
        this.util = util;
        this.router = router;
        this.aduanhkeeping = [{
          id: 1,
          name: '',
          src: '',
          background: '',
          page: ''
        }];
        this.tugas = [{
          id: 1,
          name: '',
          src: '',
          background: '',
          page: ''
        }];
      }

      _createClass(HousekeepingPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {}
      }, {
        key: "openAdhkeeping",
        value: function openAdhkeeping() {
          this.router.navigate(['aduanhk']);
        }
      }, {
        key: "openTugas",
        value: function openTugas() {
          this.router.navigate(['tugashk']);
        }
      }, {
        key: "onBack",
        value: function onBack() {
          this.router.navigate(['home']);
        }
      }]);

      return HousekeepingPage;
    }();

    HousekeepingPage.ctorParameters = function () {
      return [{
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
      }, {
        type: src_app_services_util_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]
      }];
    };

    HousekeepingPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-housekeeping',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./housekeeping.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/housekeeping/housekeeping.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./housekeeping.page.scss */
      "./src/app/housekeeping/housekeeping.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"], src_app_services_util_service__WEBPACK_IMPORTED_MODULE_4__["UtilService"], _angular_router__WEBPACK_IMPORTED_MODULE_2__["Router"]])], HousekeepingPage);
    /***/
  }
}]);
//# sourceMappingURL=housekeeping-housekeeping-module-es5.js.map