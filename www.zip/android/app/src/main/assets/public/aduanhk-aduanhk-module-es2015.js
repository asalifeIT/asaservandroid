(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["aduanhk-aduanhk-module"],{

/***/ "./node_modules/raw-loader/dist/cjs.js!./src/app/aduanhk/aduanhk.page.html":
/*!*********************************************************************************!*\
  !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/aduanhk/aduanhk.page.html ***!
  \*********************************************************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("<ion-content>\r\n  <ion-header class=\"ion-no-border\">\r\n    <ion-item lines=\"none\">\r\n      <ion-buttons slot=\"start\">\r\n        <ion-button (click)=\"util.openSideMenu()\">\r\n          <ion-icon name=\"menu\"></ion-icon>\r\n        </ion-button>\r\n      </ion-buttons>\r\n      <ion-label color=\"dark\">\r\n      Form Aduan House Keeping\r\n    </ion-label>\r\n    <ion-buttons slot=\"end\">\r\n      <ion-icon (click)=\"onBack()\" name=\"arrow-undo\"></ion-icon>\r\n    </ion-buttons>\r\n    </ion-item>\r\n   </ion-header>\r\n  \r\n   <div class=\"main_content ion-padding\">\r\n    <ion-label class=\"sub_heading\">Deskripsi</ion-label>\r\n    <ion-label class=\"sub_heading\">Silahkan mengisi aduan apabila ditemukan hal-hal yang tidak berkenan</ion-label>\r\n      <!-- Tambahkan ini pada bagian form -->\r\n    <div>\r\n      <form class=\"container\" [formGroup]=\"FormAduanHk\" (ngSubmit)=\"submitAduanHk()\">\r\n        <ion-item>\r\n          <ion-input type=\"text\" name=\"lokasi\" placeholder=\"Lokasi\" formControlName=\"lokasi\"></ion-input>\r\n        </ion-item>\r\n        <ion-item>\r\n          <ion-input type=\"text\" name=\"deskripsi_aduan\" placeholder=\"Deskripsi Aduan\"  formControlName=\"deskripsi\"></ion-input>\r\n        </ion-item>\r\n        <ion-button type=\"submit\" expand=\"block\" color=\"primary\">Submit</ion-button>\r\n      </form>\r\n    </div>\r\n   </div>\r\n  </ion-content>");

/***/ }),

/***/ "./src/app/aduanhk/aduanhk-routing.module.ts":
/*!***************************************************!*\
  !*** ./src/app/aduanhk/aduanhk-routing.module.ts ***!
  \***************************************************/
/*! exports provided: AduanhkPageRoutingModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AduanhkPageRoutingModule", function() { return AduanhkPageRoutingModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _aduanhk_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./aduanhk.page */ "./src/app/aduanhk/aduanhk.page.ts");




const routes = [
    {
        path: '',
        component: _aduanhk_page__WEBPACK_IMPORTED_MODULE_3__["AduanhkPage"]
    }
];
let AduanhkPageRoutingModule = class AduanhkPageRoutingModule {
};
AduanhkPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
        exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]],
    })
], AduanhkPageRoutingModule);



/***/ }),

/***/ "./src/app/aduanhk/aduanhk.module.ts":
/*!*******************************************!*\
  !*** ./src/app/aduanhk/aduanhk.module.ts ***!
  \*******************************************/
/*! exports provided: AduanhkPageModule */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AduanhkPageModule", function() { return AduanhkPageModule; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/common */ "./node_modules/@angular/common/fesm2015/common.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _aduanhk_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./aduanhk-routing.module */ "./src/app/aduanhk/aduanhk-routing.module.ts");
/* harmony import */ var _aduanhk_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! ./aduanhk.page */ "./src/app/aduanhk/aduanhk.page.ts");







let AduanhkPageModule = class AduanhkPageModule {
};
AduanhkPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
        imports: [
            _angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"],
            _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"],
            _aduanhk_routing_module__WEBPACK_IMPORTED_MODULE_5__["AduanhkPageRoutingModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"],
            _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]
        ],
        declarations: [_aduanhk_page__WEBPACK_IMPORTED_MODULE_6__["AduanhkPage"]]
    })
], AduanhkPageModule);



/***/ }),

/***/ "./src/app/aduanhk/aduanhk.page.scss":
/*!*******************************************!*\
  !*** ./src/app/aduanhk/aduanhk.page.scss ***!
  \*******************************************/
/*! exports provided: default */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony default export */ __webpack_exports__["default"] = ("@charset \"UTF-8\";\n/*\n  Authors : bunchdevelopers (Rahul Jograna)\n  Website : https://bunchdevelopers.com/\n  App Name : ionic6Template Pack\n  This App Template Source code is licensed as per the\n  terms found in the Website https://bunchdevelopers.com/license\n  Copyright and Good Faith Purchasers © 2021-present bunchdevelopers.\n*/\n.main-header {\n  height: 26vh;\n  width: 150%;\n  background: linear-gradient(45deg, var(--ion-color-tertiary) 30%, var(--ion-color-primary) 100%);\n  box-shadow: 0 1px 30px var(--ion-color-light);\n  border-radius: 0 0 50% 50%;\n  margin-left: -14vh;\n  margin-top: -60px;\n}\n.bg_img {\n  height: 250px;\n  width: 100%;\n  background-position: center center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n.bg_img .back_div {\n  width: 100%;\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n  padding-top: 40px;\n}\n.bg_img .back_div ion-buttons {\n  padding: 5px 2px 5px 2px;\n  margin: 10px;\n}\n.bg_img .back_div ion-buttons ion-button {\n  height: 40px;\n  width: 40px;\n  border: 1px solid #0a0000;\n  --border-radius: 50%;\n  border-radius: 50%;\n}\n.bg_img .back_div ion-buttons ion-button ion-icon {\n  color: #030000;\n}\n.bg_img .back_div .btn ion-button {\n  border: none;\n}\n.title {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n  position: relative;\n}\n.title .sub_heading {\n  font-family: \"regular\";\n  font-size: 15px;\n}\n.title .sub_ttl {\n  position: absolute;\n  right: 5px;\n  top: 45px;\n  font-size: 13px;\n  color: #0b0501;\n}\n.rate ion-icon {\n  margin-right: 5px;\n  font-size: 20px;\n  color: #ff7c31;\n}\n.sub_heading {\n  font-family: \"bold\";\n  color: #0f0e0e;\n  margin-top: 10px;\n  font-size: 13px;\n}\n.main_title {\n  font-family: \"bold\";\n  color: black;\n  font-size: 18px;\n  margin-top: 20px;\n}\np {\n  font-family: \"regular\";\n}\nion-item {\n  --background: transparent;\n  background: #f8f9fff3;\n  padding: 10px 0px 10px 0px;\n  margin: 20px 0px 20px 0px;\n  border-radius: 10px;\n}\nion-item ion-label {\n  font-family: \"bold\";\n  font-size: 15px;\n  --background: #f8f9fff3;\n  margin-bottom: 11px;\n}\nion-item ion-select {\n  font-size: 13px;\n  --background: #f8f9fff3;\n}\nion-item ion-select ion-select-option {\n  --background: #f8f9fff3;\n}\nion-row ion-col {\n  position: relative;\n  padding: 0px;\n}\nion-row ion-col .btn {\n  display: flex;\n  flex-direction: row;\n  position: absolute;\n  bottom: 5px;\n  right: 0px;\n}\nion-row ion-col .btn ion-buttons {\n  display: flex;\n  text-align: center;\n  margin: 0px 0px 0px 0px;\n}\nion-row ion-col .btn ion-buttons ion-button {\n  background: linear-gradient(#ffa124, #ff7c31);\n  border-radius: 30%;\n  height: 35px;\n  width: 40px;\n}\nion-row ion-col .btn .label_number {\n  display: flex;\n  justify-content: center;\n}\nion-row ion-col .btn .label_number ion-button {\n  border: 1px solid #ff7c31;\n  background: #ffff;\n}\nion-row ion-col .btn .label_number ion-label {\n  color: #ff7c31;\n  font-family: \"bold\";\n}\n.content_button {\n  margin-top: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWR1YW5oay9hZHVhbmhrLnBhZ2Uuc2NzcyIsInNyYy9hcHAvYWR1YW5oay9FOlxcYXNhc2VydmFuZHJvaWQvc3JjXFxhcHBcXGFkdWFuaGtcXGFkdWFuaGsucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQjtBQ0FoQjs7Ozs7OztDQUFBO0FBU0E7RUFDSSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGdHQUFBO0VBQ0EsNkNBQUE7RUFDQSwwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QURDSjtBQ0NFO0VBQ0ksYUFBQTtFQUNBLFdBQUE7RUFDQSxrQ0FBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7QURFTjtBQ0RNO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBREdSO0FDRlE7RUFDRSx3QkFBQTtFQUNBLFlBQUE7QURJVjtBQ0hVO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7QURLWjtBQ0pZO0VBQ0UsY0FBQTtBRE1kO0FDRFU7RUFDRSxZQUFBO0FER1o7QUNHSTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBREFOO0FDQ007RUFDRSxzQkFBQTtFQUNBLGVBQUE7QURDUjtBQ0NNO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FEQ1I7QUNJTTtFQUNFLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QUREUjtBQ0tJO0VBQ0UsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FERk47QUNLSTtFQUNFLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBREZOO0FDS0k7RUFDRSxzQkFBQTtBREZOO0FDS0k7RUFDRSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0EsMEJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FERk47QUNHTTtFQUNFLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QUREUjtBQ0dNO0VBQ0UsZUFBQTtFQUNBLHVCQUFBO0FERFI7QUNFUTtFQUNFLHVCQUFBO0FEQVY7QUNNTTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtBREhSO0FDSVE7RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0FERlY7QUNHVTtFQUNFLGFBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0FERFo7QUNFWTtFQUNFLDZDQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBREFkO0FDR1U7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7QUREWjtBQ0VZO0VBQ0UseUJBQUE7RUFDQSxpQkFBQTtBREFkO0FDRVk7RUFDRSxjQUFBO0VBQ0EsbUJBQUE7QURBZDtBQ09JO0VBQ0UsZ0JBQUE7QURKTiIsImZpbGUiOiJzcmMvYXBwL2FkdWFuaGsvYWR1YW5oay5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAY2hhcnNldCBcIlVURi04XCI7XG4vKlxuICBBdXRob3JzIDogYnVuY2hkZXZlbG9wZXJzIChSYWh1bCBKb2dyYW5hKVxuICBXZWJzaXRlIDogaHR0cHM6Ly9idW5jaGRldmVsb3BlcnMuY29tL1xuICBBcHAgTmFtZSA6IGlvbmljNlRlbXBsYXRlIFBhY2tcbiAgVGhpcyBBcHAgVGVtcGxhdGUgU291cmNlIGNvZGUgaXMgbGljZW5zZWQgYXMgcGVyIHRoZVxuICB0ZXJtcyBmb3VuZCBpbiB0aGUgV2Vic2l0ZSBodHRwczovL2J1bmNoZGV2ZWxvcGVycy5jb20vbGljZW5zZVxuICBDb3B5cmlnaHQgYW5kIEdvb2QgRmFpdGggUHVyY2hhc2VycyDCqSAyMDIxLXByZXNlbnQgYnVuY2hkZXZlbG9wZXJzLlxuKi9cbi5tYWluLWhlYWRlciB7XG4gIGhlaWdodDogMjZ2aDtcbiAgd2lkdGg6IDE1MCU7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg0NWRlZywgdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KSAzMCUsIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAxMDAlKTtcbiAgYm94LXNoYWRvdzogMCAxcHggMzBweCB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICBib3JkZXItcmFkaXVzOiAwIDAgNTAlIDUwJTtcbiAgbWFyZ2luLWxlZnQ6IC0xNHZoO1xuICBtYXJnaW4tdG9wOiAtNjBweDtcbn1cblxuLmJnX2ltZyB7XG4gIGhlaWdodDogMjUwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuLmJnX2ltZyAuYmFja19kaXYge1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwYWRkaW5nLXRvcDogNDBweDtcbn1cbi5iZ19pbWcgLmJhY2tfZGl2IGlvbi1idXR0b25zIHtcbiAgcGFkZGluZzogNXB4IDJweCA1cHggMnB4O1xuICBtYXJnaW46IDEwcHg7XG59XG4uYmdfaW1nIC5iYWNrX2RpdiBpb24tYnV0dG9ucyBpb24tYnV0dG9uIHtcbiAgaGVpZ2h0OiA0MHB4O1xuICB3aWR0aDogNDBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgIzBhMDAwMDtcbiAgLS1ib3JkZXItcmFkaXVzOiA1MCU7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cbi5iZ19pbWcgLmJhY2tfZGl2IGlvbi1idXR0b25zIGlvbi1idXR0b24gaW9uLWljb24ge1xuICBjb2xvcjogIzAzMDAwMDtcbn1cbi5iZ19pbWcgLmJhY2tfZGl2IC5idG4gaW9uLWJ1dHRvbiB7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuLnRpdGxlIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4udGl0bGUgLnN1Yl9oZWFkaW5nIHtcbiAgZm9udC1mYW1pbHk6IFwicmVndWxhclwiO1xuICBmb250LXNpemU6IDE1cHg7XG59XG4udGl0bGUgLnN1Yl90dGwge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiA1cHg7XG4gIHRvcDogNDVweDtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBjb2xvcjogIzBiMDUwMTtcbn1cblxuLnJhdGUgaW9uLWljb24ge1xuICBtYXJnaW4tcmlnaHQ6IDVweDtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBjb2xvcjogI2ZmN2MzMTtcbn1cblxuLnN1Yl9oZWFkaW5nIHtcbiAgZm9udC1mYW1pbHk6IFwiYm9sZFwiO1xuICBjb2xvcjogIzBmMGUwZTtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuXG4ubWFpbl90aXRsZSB7XG4gIGZvbnQtZmFtaWx5OiBcImJvbGRcIjtcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG59XG5cbnAge1xuICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XG59XG5cbmlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgYmFja2dyb3VuZDogI2Y4ZjlmZmYzO1xuICBwYWRkaW5nOiAxMHB4IDBweCAxMHB4IDBweDtcbiAgbWFyZ2luOiAyMHB4IDBweCAyMHB4IDBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbmlvbi1pdGVtIGlvbi1sYWJlbCB7XG4gIGZvbnQtZmFtaWx5OiBcImJvbGRcIjtcbiAgZm9udC1zaXplOiAxNXB4O1xuICAtLWJhY2tncm91bmQ6ICNmOGY5ZmZmMztcbiAgbWFyZ2luLWJvdHRvbTogMTFweDtcbn1cbmlvbi1pdGVtIGlvbi1zZWxlY3Qge1xuICBmb250LXNpemU6IDEzcHg7XG4gIC0tYmFja2dyb3VuZDogI2Y4ZjlmZmYzO1xufVxuaW9uLWl0ZW0gaW9uLXNlbGVjdCBpb24tc2VsZWN0LW9wdGlvbiB7XG4gIC0tYmFja2dyb3VuZDogI2Y4ZjlmZmYzO1xufVxuXG5pb24tcm93IGlvbi1jb2wge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHBhZGRpbmc6IDBweDtcbn1cbmlvbi1yb3cgaW9uLWNvbCAuYnRuIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDVweDtcbiAgcmlnaHQ6IDBweDtcbn1cbmlvbi1yb3cgaW9uLWNvbCAuYnRuIGlvbi1idXR0b25zIHtcbiAgZGlzcGxheTogZmxleDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDBweCAwcHggMHB4IDBweDtcbn1cbmlvbi1yb3cgaW9uLWNvbCAuYnRuIGlvbi1idXR0b25zIGlvbi1idXR0b24ge1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoI2ZmYTEyNCwgI2ZmN2MzMSk7XG4gIGJvcmRlci1yYWRpdXM6IDMwJTtcbiAgaGVpZ2h0OiAzNXB4O1xuICB3aWR0aDogNDBweDtcbn1cbmlvbi1yb3cgaW9uLWNvbCAuYnRuIC5sYWJlbF9udW1iZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cbmlvbi1yb3cgaW9uLWNvbCAuYnRuIC5sYWJlbF9udW1iZXIgaW9uLWJ1dHRvbiB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZjdjMzE7XG4gIGJhY2tncm91bmQ6ICNmZmZmO1xufVxuaW9uLXJvdyBpb24tY29sIC5idG4gLmxhYmVsX251bWJlciBpb24tbGFiZWwge1xuICBjb2xvcjogI2ZmN2MzMTtcbiAgZm9udC1mYW1pbHk6IFwiYm9sZFwiO1xufVxuXG4uY29udGVudF9idXR0b24ge1xuICBtYXJnaW4tdG9wOiAzMHB4O1xufSIsIi8qXHJcbiAgQXV0aG9ycyA6IGJ1bmNoZGV2ZWxvcGVycyAoUmFodWwgSm9ncmFuYSlcclxuICBXZWJzaXRlIDogaHR0cHM6Ly9idW5jaGRldmVsb3BlcnMuY29tL1xyXG4gIEFwcCBOYW1lIDogaW9uaWM2VGVtcGxhdGUgUGFja1xyXG4gIFRoaXMgQXBwIFRlbXBsYXRlIFNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIGFzIHBlciB0aGVcclxuICB0ZXJtcyBmb3VuZCBpbiB0aGUgV2Vic2l0ZSBodHRwczovL2J1bmNoZGV2ZWxvcGVycy5jb20vbGljZW5zZVxyXG4gIENvcHlyaWdodCBhbmQgR29vZCBGYWl0aCBQdXJjaGFzZXJzIMKpIDIwMjEtcHJlc2VudCBidW5jaGRldmVsb3BlcnMuXHJcbiovXHJcblxyXG4ubWFpbi1oZWFkZXIge1xyXG4gICAgaGVpZ2h0OjI2dmg7XHJcbiAgICB3aWR0aDogMTUwJTtcclxuICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg0NWRlZywgdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KSAzMCUsIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAxMDAlKTtcclxuICAgIGJveC1zaGFkb3c6IDAgMXB4IDMwcHggdmFyKC0taW9uLWNvbG9yLWxpZ2h0KTtcclxuICAgIGJvcmRlci1yYWRpdXM6IDAgMCA1MCUgNTAlO1xyXG4gICAgbWFyZ2luLWxlZnQ6IC0xNHZoO1xyXG4gICAgbWFyZ2luLXRvcDogLTYwcHg7XHJcbiAgfVxyXG4gIC5iZ19pbWcge1xyXG4gICAgICBoZWlnaHQ6IDI1MHB4O1xyXG4gICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyIGNlbnRlcjtcclxuICAgICAgYmFja2dyb3VuZC1yZXBlYXQ6IG5vLXJlcGVhdDtcclxuICAgICAgYmFja2dyb3VuZC1zaXplOiBjb3ZlcjtcclxuICAgICAgLmJhY2tfZGl2IHtcclxuICAgICAgICB3aWR0aDogMTAwJTtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICAgIGFsaWduLWl0ZW1zOiBjZW50ZXI7XHJcbiAgICAgICAgcGFkZGluZy10b3A6IDQwcHg7XHJcbiAgICAgICAgaW9uLWJ1dHRvbnMge1xyXG4gICAgICAgICAgcGFkZGluZzogNXB4IDJweCA1cHggMnB4O1xyXG4gICAgICAgICAgbWFyZ2luOiAxMHB4O1xyXG4gICAgICAgICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgICAgICAgIGhlaWdodDogNDBweDtcclxuICAgICAgICAgICAgd2lkdGg6IDQwcHg7XHJcbiAgICAgICAgICAgIGJvcmRlcjogMXB4IHNvbGlkIHJnYigxMCwgMCwgMCk7XHJcbiAgICAgICAgICAgIC0tYm9yZGVyLXJhZGl1czogNTAlO1xyXG4gICAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICAgICAgICBjb2xvcjogcmdiKDMsIDAsIDApO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIC5idG4ge1xyXG4gICAgICAgICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgICAgICAgIGJvcmRlcjogbm9uZTtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG4gICAgLnRpdGxlIHtcclxuICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgZmxleC1kaXJlY3Rpb246IHJvdztcclxuICAgICAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xyXG4gICAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgICBwb3NpdGlvbjogcmVsYXRpdmU7XHJcbiAgICAgIC5zdWJfaGVhZGluZyB7XHJcbiAgICAgICAgZm9udC1mYW1pbHk6IFwicmVndWxhclwiO1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgfVxyXG4gICAgICAuc3ViX3R0bCB7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIHJpZ2h0OiA1cHg7XHJcbiAgICAgICAgdG9wOiA0NXB4O1xyXG4gICAgICAgIGZvbnQtc2l6ZTogMTNweDtcclxuICAgICAgICBjb2xvcjogIzBiMDUwMTtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgXHJcbiAgICAucmF0ZSB7XHJcbiAgICAgIGlvbi1pY29uIHtcclxuICAgICAgICBtYXJnaW4tcmlnaHQ6IDVweDtcclxuICAgICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgICAgY29sb3I6ICNmZjdjMzE7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIFxyXG4gICAgLnN1Yl9oZWFkaW5nIHtcclxuICAgICAgZm9udC1mYW1pbHk6IFwiYm9sZFwiO1xyXG4gICAgICBjb2xvcjogIzBmMGUwZTtcclxuICAgICAgbWFyZ2luLXRvcDogMTBweDtcclxuICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgfVxyXG4gICAgXHJcbiAgICAubWFpbl90aXRsZSB7XHJcbiAgICAgIGZvbnQtZmFtaWx5OiBcImJvbGRcIjtcclxuICAgICAgY29sb3I6IGJsYWNrO1xyXG4gICAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICAgIG1hcmdpbi10b3A6IDIwcHg7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIHAge1xyXG4gICAgICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XHJcbiAgICB9XHJcbiAgICBcclxuICAgIGlvbi1pdGVtIHtcclxuICAgICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgICAgYmFja2dyb3VuZDogI2Y4ZjlmZmYzO1xyXG4gICAgICBwYWRkaW5nOiAxMHB4IDBweCAxMHB4IDBweDtcclxuICAgICAgbWFyZ2luOiAyMHB4IDBweCAyMHB4IDBweDtcclxuICAgICAgYm9yZGVyLXJhZGl1czogMTBweDtcclxuICAgICAgaW9uLWxhYmVsIHtcclxuICAgICAgICBmb250LWZhbWlseTogXCJib2xkXCI7XHJcbiAgICAgICAgZm9udC1zaXplOiAxNXB4O1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogI2Y4ZjlmZmYzO1xyXG4gICAgICAgIG1hcmdpbi1ib3R0b206IDExcHg7XHJcbiAgICAgIH1cclxuICAgICAgaW9uLXNlbGVjdCB7XHJcbiAgICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogI2Y4ZjlmZmYzO1xyXG4gICAgICAgIGlvbi1zZWxlY3Qtb3B0aW9uIHtcclxuICAgICAgICAgIC0tYmFja2dyb3VuZDogI2Y4ZjlmZmYzO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgXHJcbiAgICBpb24tcm93IHtcclxuICAgICAgaW9uLWNvbCB7XHJcbiAgICAgICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgICAgIHBhZGRpbmc6IDBweDtcclxuICAgICAgICAuYnRuIHtcclxuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICBmbGV4LWRpcmVjdGlvbjogcm93O1xyXG4gICAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgICAgYm90dG9tOiA1cHg7XHJcbiAgICAgICAgICByaWdodDogMHB4O1xyXG4gICAgICAgICAgaW9uLWJ1dHRvbnMge1xyXG4gICAgICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgICAgICB0ZXh0LWFsaWduOiBjZW50ZXI7XHJcbiAgICAgICAgICAgIG1hcmdpbjogMHB4IDBweCAwcHggMHB4O1xyXG4gICAgICAgICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICAgICAgICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoI2ZmYTEyNCwgI2ZmN2MzMSk7XHJcbiAgICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMzAlO1xyXG4gICAgICAgICAgICAgIGhlaWdodDogMzVweDtcclxuICAgICAgICAgICAgICB3aWR0aDogNDBweDtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgLmxhYmVsX251bWJlciB7XHJcbiAgICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICAgIGp1c3RpZnktY29udGVudDogY2VudGVyO1xyXG4gICAgICAgICAgICBpb24tYnV0dG9uIHtcclxuICAgICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZmY3YzMxO1xyXG4gICAgICAgICAgICAgIGJhY2tncm91bmQ6ICNmZmZmO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgICAgICAgY29sb3I6ICNmZjdjMzE7XHJcbiAgICAgICAgICAgICAgZm9udC1mYW1pbHk6IFwiYm9sZFwiO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBcclxuICAgIC5jb250ZW50X2J1dHRvbiB7XHJcbiAgICAgIG1hcmdpbi10b3A6IDMwcHg7XHJcbiAgICB9XHJcbiAgICAiXX0= */");

/***/ }),

/***/ "./src/app/aduanhk/aduanhk.page.ts":
/*!*****************************************!*\
  !*** ./src/app/aduanhk/aduanhk.page.ts ***!
  \*****************************************/
/*! exports provided: AduanhkPage */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "AduanhkPage", function() { return AduanhkPage; });
/* harmony import */ var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! tslib */ "./node_modules/tslib/tslib.es6.js");
/* harmony import */ var _angular_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @angular/router */ "./node_modules/@angular/router/fesm2015/router.js");
/* harmony import */ var _angular_core__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @angular/core */ "./node_modules/@angular/core/fesm2015/core.js");
/* harmony import */ var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @angular/forms */ "./node_modules/@angular/forms/fesm2015/forms.js");
/* harmony import */ var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @ionic/angular */ "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
/* harmony import */ var _services_service_service__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ../services/service.service */ "./src/app/services/service.service.ts");
/* harmony import */ var rxjs_index__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! rxjs/index */ "./node_modules/rxjs/index.js");
/* harmony import */ var rxjs_index__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(rxjs_index__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var src_app_services_util_service__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! src/app/services/util.service */ "./src/app/services/util.service.ts");








let AduanhkPage = class AduanhkPage {
    constructor(formBuilder, navCtrl, loadingController, modalController, platform, toastController, serviceService, router, util) {
        this.formBuilder = formBuilder;
        this.navCtrl = navCtrl;
        this.loadingController = loadingController;
        this.modalController = modalController;
        this.platform = platform;
        this.toastController = toastController;
        this.serviceService = serviceService;
        this.router = router;
        this.util = util;
        this.authenticationState = new rxjs_index__WEBPACK_IMPORTED_MODULE_6__["ReplaySubject"]();
        this.validations = {
            'lokasi': [
                { type: 'required', message: 'lokasi harus diisi.' }
            ],
            'deskripsi': [
                { type: 'required', message: 'deskripsi harus diisi.' }
            ]
        };
    }
    ngOnInit() {
        this.FormAduanHk = this.formBuilder.group({
            lokasi: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required
            ])),
            deskripsi: new _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].compose([
                _angular_forms__WEBPACK_IMPORTED_MODULE_3__["Validators"].required
            ]))
        });
    }
    submitAduanHk() {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const loading = yield this.loadingController.create({
                message: 'Please wait...'
            });
            yield loading.present();
            this.serviceService.submitaduanhk(this.FormAduanHk.value, 'housekeeping/add').subscribe(data => {
                this.presentToast("Aduan Anda Terkirim");
                console.log(this.FormAduanHk.value);
                this.FormAduanHk.reset();
                loading.dismiss();
            }, error => {
                this.presentToast(error);
                loading.dismiss();
            });
        });
    }
    presentToast(Message) {
        return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, function* () {
            const toast = yield this.toastController.create({
                message: Message,
                duration: 2500,
                position: "bottom"
            });
            toast.present();
        });
    }
    onBack() {
        this.router.navigate(['home']);
    }
};
AduanhkPage.ctorParameters = () => [
    { type: _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"] },
    { type: _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"] },
    { type: _services_service_service__WEBPACK_IMPORTED_MODULE_5__["ServiceService"] },
    { type: _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"] },
    { type: src_app_services_util_service__WEBPACK_IMPORTED_MODULE_7__["UtilService"] }
];
AduanhkPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([
    Object(_angular_core__WEBPACK_IMPORTED_MODULE_2__["Component"])({
        selector: 'app-aduanhk',
        template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! raw-loader!./aduanhk.page.html */ "./node_modules/raw-loader/dist/cjs.js!./src/app/aduanhk/aduanhk.page.html")).default,
        styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(/*! ./aduanhk.page.scss */ "./src/app/aduanhk/aduanhk.page.scss")).default]
    }),
    tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormBuilder"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["NavController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["LoadingController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ModalController"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["Platform"],
        _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["ToastController"],
        _services_service_service__WEBPACK_IMPORTED_MODULE_5__["ServiceService"],
        _angular_router__WEBPACK_IMPORTED_MODULE_1__["Router"],
        src_app_services_util_service__WEBPACK_IMPORTED_MODULE_7__["UtilService"]])
], AduanhkPage);



/***/ })

}]);
//# sourceMappingURL=aduanhk-aduanhk-module-es2015.js.map