function _defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } }

function _createClass(Constructor, protoProps, staticProps) { if (protoProps) _defineProperties(Constructor.prototype, protoProps); if (staticProps) _defineProperties(Constructor, staticProps); Object.defineProperty(Constructor, "prototype", { writable: false }); return Constructor; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

(window["webpackJsonp"] = window["webpackJsonp"] || []).push([["aduancatering-aduancatering-module"], {
  /***/
  "./node_modules/raw-loader/dist/cjs.js!./src/app/aduancatering/aduancatering.page.html":
  /*!*********************************************************************************************!*\
    !*** ./node_modules/raw-loader/dist/cjs.js!./src/app/aduancatering/aduancatering.page.html ***!
    \*********************************************************************************************/

  /*! exports provided: default */

  /***/
  function node_modulesRawLoaderDistCjsJsSrcAppAduancateringAduancateringPageHtml(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "<ion-content>\r\n\r\n<ion-header class=\"ion-no-border\">\r\n  <ion-item lines=\"none\">\r\n    <ion-buttons slot=\"start\">\r\n      <ion-button (click)=\"util.openSideMenu()\">\r\n        <ion-icon name=\"menu\"></ion-icon>\r\n      </ion-button>\r\n    </ion-buttons>\r\n    <ion-label color=\"dark\">\r\n    Form Aduan Catering\r\n  </ion-label>\r\n  <ion-buttons slot=\"end\">\r\n    <ion-icon (click)=\"onBack()\" name=\"arrow-undo\"></ion-icon>\r\n  </ion-buttons>\r\n  </ion-item>\r\n </ion-header>\r\n\r\n <div class=\"main_content ion-padding\">\r\n  <ion-label class=\"sub_heading\">Deskripsi</ion-label>\r\n  <ion-label class=\"sub_heading\">Silahkan mengisi aduan apabila ditemukan hal-hal yang tidak berkenan</ion-label>\r\n    <!-- Tambahkan ini pada bagian form -->\r\n  <div>\r\n    <form class=\"container\" [formGroup]=\"FormAduanCatering\" (ngSubmit)=\"submitAduanCatering()\">\r\n      <ion-item>\r\n        <ion-input type=\"text\" name=\"lokasi\" placeholder=\"Lokasi\" formControlName=\"lokasi\"></ion-input>\r\n      </ion-item>\r\n      <ion-item>\r\n        <ion-input type=\"text\" name=\"deskripsi\" placeholder=\"Deskripsi\"  formControlName=\"deskripsi\"></ion-input>\r\n      </ion-item>\r\n      <ion-item>\r\n        <ion-input type=\"text\" name=\"kritik_saran\" placeholder=\"Kritik dan saran\"  formControlName=\"kritik_saran\"></ion-input>\r\n      </ion-item>    \r\n      <ion-button type=\"submit\" expand=\"block\" color=\"primary\">Submit</ion-button>\r\n\r\n      \r\n    </form>\r\n  </div>\r\n </div>\r\n</ion-content>";
    /***/
  },

  /***/
  "./src/app/aduancatering/aduancatering-routing.module.ts":
  /*!***************************************************************!*\
    !*** ./src/app/aduancatering/aduancatering-routing.module.ts ***!
    \***************************************************************/

  /*! exports provided: AduancateringPageRoutingModule */

  /***/
  function srcAppAduancateringAduancateringRoutingModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AduancateringPageRoutingModule", function () {
      return AduancateringPageRoutingModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");
    /* harmony import */


    var _aduancatering_page__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! ./aduancatering.page */
    "./src/app/aduancatering/aduancatering.page.ts");

    var routes = [{
      path: '',
      component: _aduancatering_page__WEBPACK_IMPORTED_MODULE_3__["AduancateringPage"]
    }];

    var AduancateringPageRoutingModule = /*#__PURE__*/_createClass(function AduancateringPageRoutingModule() {
      _classCallCheck(this, AduancateringPageRoutingModule);
    });

    AduancateringPageRoutingModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"].forChild(routes)],
      exports: [_angular_router__WEBPACK_IMPORTED_MODULE_2__["RouterModule"]]
    })], AduancateringPageRoutingModule);
    /***/
  },

  /***/
  "./src/app/aduancatering/aduancatering.module.ts":
  /*!*******************************************************!*\
    !*** ./src/app/aduancatering/aduancatering.module.ts ***!
    \*******************************************************/

  /*! exports provided: AduancateringPageModule */

  /***/
  function srcAppAduancateringAduancateringModuleTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AduancateringPageModule", function () {
      return AduancateringPageModule;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_common__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/common */
    "./node_modules/@angular/common/fesm2015/common.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _aduancatering_routing_module__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! ./aduancatering-routing.module */
    "./src/app/aduancatering/aduancatering-routing.module.ts");
    /* harmony import */


    var _aduancatering_page__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! ./aduancatering.page */
    "./src/app/aduancatering/aduancatering.page.ts");

    var AduancateringPageModule = /*#__PURE__*/_createClass(function AduancateringPageModule() {
      _classCallCheck(this, AduancateringPageModule);
    });

    AduancateringPageModule = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["NgModule"])({
      imports: [_angular_common__WEBPACK_IMPORTED_MODULE_2__["CommonModule"], _ionic_angular__WEBPACK_IMPORTED_MODULE_4__["IonicModule"], _aduancatering_routing_module__WEBPACK_IMPORTED_MODULE_5__["AduancateringPageRoutingModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["FormsModule"], _angular_forms__WEBPACK_IMPORTED_MODULE_3__["ReactiveFormsModule"]],
      declarations: [_aduancatering_page__WEBPACK_IMPORTED_MODULE_6__["AduancateringPage"]]
    })], AduancateringPageModule);
    /***/
  },

  /***/
  "./src/app/aduancatering/aduancatering.page.scss":
  /*!*******************************************************!*\
    !*** ./src/app/aduancatering/aduancatering.page.scss ***!
    \*******************************************************/

  /*! exports provided: default */

  /***/
  function srcAppAduancateringAduancateringPageScss(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony default export */


    __webpack_exports__["default"] = "@charset \"UTF-8\";\n/*\n  Authors : bunchdevelopers (Rahul Jograna)\n  Website : https://bunchdevelopers.com/\n  App Name : ionic6Template Pack\n  This App Template Source code is licensed as per the\n  terms found in the Website https://bunchdevelopers.com/license\n  Copyright and Good Faith Purchasers © 2021-present bunchdevelopers.\n*/\n.main-header {\n  height: 26vh;\n  width: 150%;\n  background: linear-gradient(45deg, var(--ion-color-tertiary) 30%, var(--ion-color-primary) 100%);\n  box-shadow: 0 1px 30px var(--ion-color-light);\n  border-radius: 0 0 50% 50%;\n  margin-left: -14vh;\n  margin-top: -60px;\n}\n.bg_img {\n  height: 250px;\n  width: 100%;\n  background-position: center center;\n  background-repeat: no-repeat;\n  background-size: cover;\n}\n.bg_img .back_div {\n  width: 100%;\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n  padding-top: 40px;\n}\n.bg_img .back_div ion-buttons {\n  padding: 5px 2px 5px 2px;\n  margin: 10px;\n}\n.bg_img .back_div ion-buttons ion-button {\n  height: 40px;\n  width: 40px;\n  border: 1px solid #0a0000;\n  --border-radius: 50%;\n  border-radius: 50%;\n}\n.bg_img .back_div ion-buttons ion-button ion-icon {\n  color: #030000;\n}\n.bg_img .back_div .btn ion-button {\n  border: none;\n}\n.title {\n  display: flex;\n  flex-direction: row;\n  justify-content: space-between;\n  align-items: center;\n  position: relative;\n}\n.title .sub_heading {\n  font-family: \"regular\";\n  font-size: 15px;\n}\n.title .sub_ttl {\n  position: absolute;\n  right: 5px;\n  top: 45px;\n  font-size: 13px;\n  color: #0b0501;\n}\n.rate ion-icon {\n  margin-right: 5px;\n  font-size: 20px;\n  color: #ff7c31;\n}\n.sub_heading {\n  font-family: \"bold\";\n  color: #0f0e0e;\n  margin-top: 10px;\n  font-size: 13px;\n}\n.main_title {\n  font-family: \"bold\";\n  color: black;\n  font-size: 18px;\n  margin-top: 20px;\n}\np {\n  font-family: \"regular\";\n}\nion-item {\n  --background: transparent;\n  background: #f8f9fff3;\n  padding: 10px 0px 10px 0px;\n  margin: 20px 0px 20px 0px;\n  border-radius: 10px;\n}\nion-item ion-label {\n  font-family: \"bold\";\n  font-size: 15px;\n  --background: #f8f9fff3;\n  margin-bottom: 11px;\n}\nion-item ion-select {\n  font-size: 13px;\n  --background: #f8f9fff3;\n}\nion-item ion-select ion-select-option {\n  --background: #f8f9fff3;\n}\nion-row ion-col {\n  position: relative;\n  padding: 0px;\n}\nion-row ion-col .btn {\n  display: flex;\n  flex-direction: row;\n  position: absolute;\n  bottom: 5px;\n  right: 0px;\n}\nion-row ion-col .btn ion-buttons {\n  display: flex;\n  text-align: center;\n  margin: 0px 0px 0px 0px;\n}\nion-row ion-col .btn ion-buttons ion-button {\n  background: linear-gradient(#ffa124, #ff7c31);\n  border-radius: 30%;\n  height: 35px;\n  width: 40px;\n}\nion-row ion-col .btn .label_number {\n  display: flex;\n  justify-content: center;\n}\nion-row ion-col .btn .label_number ion-button {\n  border: 1px solid #ff7c31;\n  background: #ffff;\n}\nion-row ion-col .btn .label_number ion-label {\n  color: #ff7c31;\n  font-family: \"bold\";\n}\n.content_button {\n  margin-top: 30px;\n}\n/*# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbInNyYy9hcHAvYWR1YW5jYXRlcmluZy9hZHVhbmNhdGVyaW5nLnBhZ2Uuc2NzcyIsInNyYy9hcHAvYWR1YW5jYXRlcmluZy9FOlxcYXNhc2VydmFuZHJvaWQvc3JjXFxhcHBcXGFkdWFuY2F0ZXJpbmdcXGFkdWFuY2F0ZXJpbmcucGFnZS5zY3NzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLGdCQUFnQjtBQ0FoQjs7Ozs7OztDQUFBO0FBU0E7RUFDRSxZQUFBO0VBQ0EsV0FBQTtFQUNBLGdHQUFBO0VBQ0EsNkNBQUE7RUFDQSwwQkFBQTtFQUNBLGtCQUFBO0VBQ0EsaUJBQUE7QURDRjtBQ0NBO0VBQ0ksYUFBQTtFQUNBLFdBQUE7RUFDQSxrQ0FBQTtFQUNBLDRCQUFBO0VBQ0Esc0JBQUE7QURFSjtBQ0RJO0VBQ0UsV0FBQTtFQUNBLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxpQkFBQTtBREdOO0FDRk07RUFDRSx3QkFBQTtFQUNBLFlBQUE7QURJUjtBQ0hRO0VBQ0UsWUFBQTtFQUNBLFdBQUE7RUFDQSx5QkFBQTtFQUNBLG9CQUFBO0VBQ0Esa0JBQUE7QURLVjtBQ0pVO0VBQ0UsY0FBQTtBRE1aO0FDRFE7RUFDRSxZQUFBO0FER1Y7QUNHRTtFQUNFLGFBQUE7RUFDQSxtQkFBQTtFQUNBLDhCQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtBREFKO0FDQ0k7RUFDRSxzQkFBQTtFQUNBLGVBQUE7QURDTjtBQ0NJO0VBQ0Usa0JBQUE7RUFDQSxVQUFBO0VBQ0EsU0FBQTtFQUNBLGVBQUE7RUFDQSxjQUFBO0FEQ047QUNJSTtFQUNFLGlCQUFBO0VBQ0EsZUFBQTtFQUNBLGNBQUE7QURETjtBQ0tFO0VBQ0UsbUJBQUE7RUFDQSxjQUFBO0VBQ0EsZ0JBQUE7RUFDQSxlQUFBO0FERko7QUNLRTtFQUNFLG1CQUFBO0VBQ0EsWUFBQTtFQUNBLGVBQUE7RUFDQSxnQkFBQTtBREZKO0FDS0U7RUFDRSxzQkFBQTtBREZKO0FDS0U7RUFDRSx5QkFBQTtFQUNBLHFCQUFBO0VBQ0EsMEJBQUE7RUFDQSx5QkFBQTtFQUNBLG1CQUFBO0FERko7QUNHSTtFQUNFLG1CQUFBO0VBQ0EsZUFBQTtFQUNBLHVCQUFBO0VBQ0EsbUJBQUE7QURETjtBQ0dJO0VBQ0UsZUFBQTtFQUNBLHVCQUFBO0FERE47QUNFTTtFQUNFLHVCQUFBO0FEQVI7QUNNSTtFQUNFLGtCQUFBO0VBQ0EsWUFBQTtBREhOO0FDSU07RUFDRSxhQUFBO0VBQ0EsbUJBQUE7RUFDQSxrQkFBQTtFQUNBLFdBQUE7RUFDQSxVQUFBO0FERlI7QUNHUTtFQUNFLGFBQUE7RUFDQSxrQkFBQTtFQUNBLHVCQUFBO0FERFY7QUNFVTtFQUNFLDZDQUFBO0VBQ0Esa0JBQUE7RUFDQSxZQUFBO0VBQ0EsV0FBQTtBREFaO0FDR1E7RUFDRSxhQUFBO0VBQ0EsdUJBQUE7QUREVjtBQ0VVO0VBQ0UseUJBQUE7RUFDQSxpQkFBQTtBREFaO0FDRVU7RUFDRSxjQUFBO0VBQ0EsbUJBQUE7QURBWjtBQ09FO0VBQ0UsZ0JBQUE7QURKSiIsImZpbGUiOiJzcmMvYXBwL2FkdWFuY2F0ZXJpbmcvYWR1YW5jYXRlcmluZy5wYWdlLnNjc3MiLCJzb3VyY2VzQ29udGVudCI6WyJAY2hhcnNldCBcIlVURi04XCI7XG4vKlxuICBBdXRob3JzIDogYnVuY2hkZXZlbG9wZXJzIChSYWh1bCBKb2dyYW5hKVxuICBXZWJzaXRlIDogaHR0cHM6Ly9idW5jaGRldmVsb3BlcnMuY29tL1xuICBBcHAgTmFtZSA6IGlvbmljNlRlbXBsYXRlIFBhY2tcbiAgVGhpcyBBcHAgVGVtcGxhdGUgU291cmNlIGNvZGUgaXMgbGljZW5zZWQgYXMgcGVyIHRoZVxuICB0ZXJtcyBmb3VuZCBpbiB0aGUgV2Vic2l0ZSBodHRwczovL2J1bmNoZGV2ZWxvcGVycy5jb20vbGljZW5zZVxuICBDb3B5cmlnaHQgYW5kIEdvb2QgRmFpdGggUHVyY2hhc2VycyDCqSAyMDIxLXByZXNlbnQgYnVuY2hkZXZlbG9wZXJzLlxuKi9cbi5tYWluLWhlYWRlciB7XG4gIGhlaWdodDogMjZ2aDtcbiAgd2lkdGg6IDE1MCU7XG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg0NWRlZywgdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KSAzMCUsIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAxMDAlKTtcbiAgYm94LXNoYWRvdzogMCAxcHggMzBweCB2YXIoLS1pb24tY29sb3ItbGlnaHQpO1xuICBib3JkZXItcmFkaXVzOiAwIDAgNTAlIDUwJTtcbiAgbWFyZ2luLWxlZnQ6IC0xNHZoO1xuICBtYXJnaW4tdG9wOiAtNjBweDtcbn1cblxuLmJnX2ltZyB7XG4gIGhlaWdodDogMjUwcHg7XG4gIHdpZHRoOiAxMDAlO1xuICBiYWNrZ3JvdW5kLXBvc2l0aW9uOiBjZW50ZXIgY2VudGVyO1xuICBiYWNrZ3JvdW5kLXJlcGVhdDogbm8tcmVwZWF0O1xuICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xufVxuLmJnX2ltZyAuYmFja19kaXYge1xuICB3aWR0aDogMTAwJTtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwYWRkaW5nLXRvcDogNDBweDtcbn1cbi5iZ19pbWcgLmJhY2tfZGl2IGlvbi1idXR0b25zIHtcbiAgcGFkZGluZzogNXB4IDJweCA1cHggMnB4O1xuICBtYXJnaW46IDEwcHg7XG59XG4uYmdfaW1nIC5iYWNrX2RpdiBpb24tYnV0dG9ucyBpb24tYnV0dG9uIHtcbiAgaGVpZ2h0OiA0MHB4O1xuICB3aWR0aDogNDBweDtcbiAgYm9yZGVyOiAxcHggc29saWQgIzBhMDAwMDtcbiAgLS1ib3JkZXItcmFkaXVzOiA1MCU7XG4gIGJvcmRlci1yYWRpdXM6IDUwJTtcbn1cbi5iZ19pbWcgLmJhY2tfZGl2IGlvbi1idXR0b25zIGlvbi1idXR0b24gaW9uLWljb24ge1xuICBjb2xvcjogIzAzMDAwMDtcbn1cbi5iZ19pbWcgLmJhY2tfZGl2IC5idG4gaW9uLWJ1dHRvbiB7XG4gIGJvcmRlcjogbm9uZTtcbn1cblxuLnRpdGxlIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAganVzdGlmeS1jb250ZW50OiBzcGFjZS1iZXR3ZWVuO1xuICBhbGlnbi1pdGVtczogY2VudGVyO1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG59XG4udGl0bGUgLnN1Yl9oZWFkaW5nIHtcbiAgZm9udC1mYW1pbHk6IFwicmVndWxhclwiO1xuICBmb250LXNpemU6IDE1cHg7XG59XG4udGl0bGUgLnN1Yl90dGwge1xuICBwb3NpdGlvbjogYWJzb2x1dGU7XG4gIHJpZ2h0OiA1cHg7XG4gIHRvcDogNDVweDtcbiAgZm9udC1zaXplOiAxM3B4O1xuICBjb2xvcjogIzBiMDUwMTtcbn1cblxuLnJhdGUgaW9uLWljb24ge1xuICBtYXJnaW4tcmlnaHQ6IDVweDtcbiAgZm9udC1zaXplOiAyMHB4O1xuICBjb2xvcjogI2ZmN2MzMTtcbn1cblxuLnN1Yl9oZWFkaW5nIHtcbiAgZm9udC1mYW1pbHk6IFwiYm9sZFwiO1xuICBjb2xvcjogIzBmMGUwZTtcbiAgbWFyZ2luLXRvcDogMTBweDtcbiAgZm9udC1zaXplOiAxM3B4O1xufVxuXG4ubWFpbl90aXRsZSB7XG4gIGZvbnQtZmFtaWx5OiBcImJvbGRcIjtcbiAgY29sb3I6IGJsYWNrO1xuICBmb250LXNpemU6IDE4cHg7XG4gIG1hcmdpbi10b3A6IDIwcHg7XG59XG5cbnAge1xuICBmb250LWZhbWlseTogXCJyZWd1bGFyXCI7XG59XG5cbmlvbi1pdGVtIHtcbiAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcbiAgYmFja2dyb3VuZDogI2Y4ZjlmZmYzO1xuICBwYWRkaW5nOiAxMHB4IDBweCAxMHB4IDBweDtcbiAgbWFyZ2luOiAyMHB4IDBweCAyMHB4IDBweDtcbiAgYm9yZGVyLXJhZGl1czogMTBweDtcbn1cbmlvbi1pdGVtIGlvbi1sYWJlbCB7XG4gIGZvbnQtZmFtaWx5OiBcImJvbGRcIjtcbiAgZm9udC1zaXplOiAxNXB4O1xuICAtLWJhY2tncm91bmQ6ICNmOGY5ZmZmMztcbiAgbWFyZ2luLWJvdHRvbTogMTFweDtcbn1cbmlvbi1pdGVtIGlvbi1zZWxlY3Qge1xuICBmb250LXNpemU6IDEzcHg7XG4gIC0tYmFja2dyb3VuZDogI2Y4ZjlmZmYzO1xufVxuaW9uLWl0ZW0gaW9uLXNlbGVjdCBpb24tc2VsZWN0LW9wdGlvbiB7XG4gIC0tYmFja2dyb3VuZDogI2Y4ZjlmZmYzO1xufVxuXG5pb24tcm93IGlvbi1jb2wge1xuICBwb3NpdGlvbjogcmVsYXRpdmU7XG4gIHBhZGRpbmc6IDBweDtcbn1cbmlvbi1yb3cgaW9uLWNvbCAuYnRuIHtcbiAgZGlzcGxheTogZmxleDtcbiAgZmxleC1kaXJlY3Rpb246IHJvdztcbiAgcG9zaXRpb246IGFic29sdXRlO1xuICBib3R0b206IDVweDtcbiAgcmlnaHQ6IDBweDtcbn1cbmlvbi1yb3cgaW9uLWNvbCAuYnRuIGlvbi1idXR0b25zIHtcbiAgZGlzcGxheTogZmxleDtcbiAgdGV4dC1hbGlnbjogY2VudGVyO1xuICBtYXJnaW46IDBweCAwcHggMHB4IDBweDtcbn1cbmlvbi1yb3cgaW9uLWNvbCAuYnRuIGlvbi1idXR0b25zIGlvbi1idXR0b24ge1xuICBiYWNrZ3JvdW5kOiBsaW5lYXItZ3JhZGllbnQoI2ZmYTEyNCwgI2ZmN2MzMSk7XG4gIGJvcmRlci1yYWRpdXM6IDMwJTtcbiAgaGVpZ2h0OiAzNXB4O1xuICB3aWR0aDogNDBweDtcbn1cbmlvbi1yb3cgaW9uLWNvbCAuYnRuIC5sYWJlbF9udW1iZXIge1xuICBkaXNwbGF5OiBmbGV4O1xuICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcbn1cbmlvbi1yb3cgaW9uLWNvbCAuYnRuIC5sYWJlbF9udW1iZXIgaW9uLWJ1dHRvbiB7XG4gIGJvcmRlcjogMXB4IHNvbGlkICNmZjdjMzE7XG4gIGJhY2tncm91bmQ6ICNmZmZmO1xufVxuaW9uLXJvdyBpb24tY29sIC5idG4gLmxhYmVsX251bWJlciBpb24tbGFiZWwge1xuICBjb2xvcjogI2ZmN2MzMTtcbiAgZm9udC1mYW1pbHk6IFwiYm9sZFwiO1xufVxuXG4uY29udGVudF9idXR0b24ge1xuICBtYXJnaW4tdG9wOiAzMHB4O1xufSIsIi8qXHJcbiAgQXV0aG9ycyA6IGJ1bmNoZGV2ZWxvcGVycyAoUmFodWwgSm9ncmFuYSlcclxuICBXZWJzaXRlIDogaHR0cHM6Ly9idW5jaGRldmVsb3BlcnMuY29tL1xyXG4gIEFwcCBOYW1lIDogaW9uaWM2VGVtcGxhdGUgUGFja1xyXG4gIFRoaXMgQXBwIFRlbXBsYXRlIFNvdXJjZSBjb2RlIGlzIGxpY2Vuc2VkIGFzIHBlciB0aGVcclxuICB0ZXJtcyBmb3VuZCBpbiB0aGUgV2Vic2l0ZSBodHRwczovL2J1bmNoZGV2ZWxvcGVycy5jb20vbGljZW5zZVxyXG4gIENvcHlyaWdodCBhbmQgR29vZCBGYWl0aCBQdXJjaGFzZXJzIMKpIDIwMjEtcHJlc2VudCBidW5jaGRldmVsb3BlcnMuXHJcbiovXHJcblxyXG4ubWFpbi1oZWFkZXIge1xyXG4gIGhlaWdodDoyNnZoO1xyXG4gIHdpZHRoOiAxNTAlO1xyXG4gIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCg0NWRlZywgdmFyKC0taW9uLWNvbG9yLXRlcnRpYXJ5KSAzMCUsIHZhcigtLWlvbi1jb2xvci1wcmltYXJ5KSAxMDAlKTtcclxuICBib3gtc2hhZG93OiAwIDFweCAzMHB4IHZhcigtLWlvbi1jb2xvci1saWdodCk7XHJcbiAgYm9yZGVyLXJhZGl1czogMCAwIDUwJSA1MCU7XHJcbiAgbWFyZ2luLWxlZnQ6IC0xNHZoO1xyXG4gIG1hcmdpbi10b3A6IC02MHB4O1xyXG59XHJcbi5iZ19pbWcge1xyXG4gICAgaGVpZ2h0OiAyNTBweDtcclxuICAgIHdpZHRoOiAxMDAlO1xyXG4gICAgYmFja2dyb3VuZC1wb3NpdGlvbjogY2VudGVyIGNlbnRlcjtcclxuICAgIGJhY2tncm91bmQtcmVwZWF0OiBuby1yZXBlYXQ7XHJcbiAgICBiYWNrZ3JvdW5kLXNpemU6IGNvdmVyO1xyXG4gICAgLmJhY2tfZGl2IHtcclxuICAgICAgd2lkdGg6IDEwMCU7XHJcbiAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICAgIGp1c3RpZnktY29udGVudDogc3BhY2UtYmV0d2VlbjtcclxuICAgICAgYWxpZ24taXRlbXM6IGNlbnRlcjtcclxuICAgICAgcGFkZGluZy10b3A6IDQwcHg7XHJcbiAgICAgIGlvbi1idXR0b25zIHtcclxuICAgICAgICBwYWRkaW5nOiA1cHggMnB4IDVweCAycHg7XHJcbiAgICAgICAgbWFyZ2luOiAxMHB4O1xyXG4gICAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgICAgaGVpZ2h0OiA0MHB4O1xyXG4gICAgICAgICAgd2lkdGg6IDQwcHg7XHJcbiAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCByZ2IoMTAsIDAsIDApO1xyXG4gICAgICAgICAgLS1ib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICBib3JkZXItcmFkaXVzOiA1MCU7XHJcbiAgICAgICAgICBpb24taWNvbiB7XHJcbiAgICAgICAgICAgIGNvbG9yOiByZ2IoMywgMCwgMCk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIC5idG4ge1xyXG4gICAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgICAgYm9yZGVyOiBub25lO1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBcclxuICAudGl0bGUge1xyXG4gICAgZGlzcGxheTogZmxleDtcclxuICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICBqdXN0aWZ5LWNvbnRlbnQ6IHNwYWNlLWJldHdlZW47XHJcbiAgICBhbGlnbi1pdGVtczogY2VudGVyO1xyXG4gICAgcG9zaXRpb246IHJlbGF0aXZlO1xyXG4gICAgLnN1Yl9oZWFkaW5nIHtcclxuICAgICAgZm9udC1mYW1pbHk6IFwicmVndWxhclwiO1xyXG4gICAgICBmb250LXNpemU6IDE1cHg7XHJcbiAgICB9XHJcbiAgICAuc3ViX3R0bCB7XHJcbiAgICAgIHBvc2l0aW9uOiBhYnNvbHV0ZTtcclxuICAgICAgcmlnaHQ6IDVweDtcclxuICAgICAgdG9wOiA0NXB4O1xyXG4gICAgICBmb250LXNpemU6IDEzcHg7XHJcbiAgICAgIGNvbG9yOiAjMGIwNTAxO1xyXG4gICAgfVxyXG4gIH1cclxuICBcclxuICAucmF0ZSB7XHJcbiAgICBpb24taWNvbiB7XHJcbiAgICAgIG1hcmdpbi1yaWdodDogNXB4O1xyXG4gICAgICBmb250LXNpemU6IDIwcHg7XHJcbiAgICAgIGNvbG9yOiAjZmY3YzMxO1xyXG4gICAgfVxyXG4gIH1cclxuICBcclxuICAuc3ViX2hlYWRpbmcge1xyXG4gICAgZm9udC1mYW1pbHk6IFwiYm9sZFwiO1xyXG4gICAgY29sb3I6ICMwZjBlMGU7XHJcbiAgICBtYXJnaW4tdG9wOiAxMHB4O1xyXG4gICAgZm9udC1zaXplOiAxM3B4O1xyXG4gIH1cclxuICBcclxuICAubWFpbl90aXRsZSB7XHJcbiAgICBmb250LWZhbWlseTogXCJib2xkXCI7XHJcbiAgICBjb2xvcjogYmxhY2s7XHJcbiAgICBmb250LXNpemU6IDE4cHg7XHJcbiAgICBtYXJnaW4tdG9wOiAyMHB4O1xyXG4gIH1cclxuICBcclxuICBwIHtcclxuICAgIGZvbnQtZmFtaWx5OiBcInJlZ3VsYXJcIjtcclxuICB9XHJcbiAgXHJcbiAgaW9uLWl0ZW0ge1xyXG4gICAgLS1iYWNrZ3JvdW5kOiB0cmFuc3BhcmVudDtcclxuICAgIGJhY2tncm91bmQ6ICNmOGY5ZmZmMztcclxuICAgIHBhZGRpbmc6IDEwcHggMHB4IDEwcHggMHB4O1xyXG4gICAgbWFyZ2luOiAyMHB4IDBweCAyMHB4IDBweDtcclxuICAgIGJvcmRlci1yYWRpdXM6IDEwcHg7XHJcbiAgICBpb24tbGFiZWwge1xyXG4gICAgICBmb250LWZhbWlseTogXCJib2xkXCI7XHJcbiAgICAgIGZvbnQtc2l6ZTogMTVweDtcclxuICAgICAgLS1iYWNrZ3JvdW5kOiAjZjhmOWZmZjM7XHJcbiAgICAgIG1hcmdpbi1ib3R0b206IDExcHg7XHJcbiAgICB9XHJcbiAgICBpb24tc2VsZWN0IHtcclxuICAgICAgZm9udC1zaXplOiAxM3B4O1xyXG4gICAgICAtLWJhY2tncm91bmQ6ICNmOGY5ZmZmMztcclxuICAgICAgaW9uLXNlbGVjdC1vcHRpb24ge1xyXG4gICAgICAgIC0tYmFja2dyb3VuZDogI2Y4ZjlmZmYzO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIFxyXG4gIGlvbi1yb3cge1xyXG4gICAgaW9uLWNvbCB7XHJcbiAgICAgIHBvc2l0aW9uOiByZWxhdGl2ZTtcclxuICAgICAgcGFkZGluZzogMHB4O1xyXG4gICAgICAuYnRuIHtcclxuICAgICAgICBkaXNwbGF5OiBmbGV4O1xyXG4gICAgICAgIGZsZXgtZGlyZWN0aW9uOiByb3c7XHJcbiAgICAgICAgcG9zaXRpb246IGFic29sdXRlO1xyXG4gICAgICAgIGJvdHRvbTogNXB4O1xyXG4gICAgICAgIHJpZ2h0OiAwcHg7XHJcbiAgICAgICAgaW9uLWJ1dHRvbnMge1xyXG4gICAgICAgICAgZGlzcGxheTogZmxleDtcclxuICAgICAgICAgIHRleHQtYWxpZ246IGNlbnRlcjtcclxuICAgICAgICAgIG1hcmdpbjogMHB4IDBweCAwcHggMHB4O1xyXG4gICAgICAgICAgaW9uLWJ1dHRvbiB7XHJcbiAgICAgICAgICAgIGJhY2tncm91bmQ6IGxpbmVhci1ncmFkaWVudCgjZmZhMTI0LCAjZmY3YzMxKTtcclxuICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogMzAlO1xyXG4gICAgICAgICAgICBoZWlnaHQ6IDM1cHg7XHJcbiAgICAgICAgICAgIHdpZHRoOiA0MHB4O1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICAubGFiZWxfbnVtYmVyIHtcclxuICAgICAgICAgIGRpc3BsYXk6IGZsZXg7XHJcbiAgICAgICAgICBqdXN0aWZ5LWNvbnRlbnQ6IGNlbnRlcjtcclxuICAgICAgICAgIGlvbi1idXR0b24ge1xyXG4gICAgICAgICAgICBib3JkZXI6IDFweCBzb2xpZCAjZmY3YzMxO1xyXG4gICAgICAgICAgICBiYWNrZ3JvdW5kOiAjZmZmZjtcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIGlvbi1sYWJlbCB7XHJcbiAgICAgICAgICAgIGNvbG9yOiAjZmY3YzMxO1xyXG4gICAgICAgICAgICBmb250LWZhbWlseTogXCJib2xkXCI7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIFxyXG4gIC5jb250ZW50X2J1dHRvbiB7XHJcbiAgICBtYXJnaW4tdG9wOiAzMHB4O1xyXG4gIH1cclxuICAiXX0= */";
    /***/
  },

  /***/
  "./src/app/aduancatering/aduancatering.page.ts":
  /*!*****************************************************!*\
    !*** ./src/app/aduancatering/aduancatering.page.ts ***!
    \*****************************************************/

  /*! exports provided: AduancateringPage */

  /***/
  function srcAppAduancateringAduancateringPageTs(module, __webpack_exports__, __webpack_require__) {
    "use strict";

    __webpack_require__.r(__webpack_exports__);
    /* harmony export (binding) */


    __webpack_require__.d(__webpack_exports__, "AduancateringPage", function () {
      return AduancateringPage;
    });
    /* harmony import */


    var tslib__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(
    /*! tslib */
    "./node_modules/tslib/tslib.es6.js");
    /* harmony import */


    var _angular_core__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(
    /*! @angular/core */
    "./node_modules/@angular/core/fesm2015/core.js");
    /* harmony import */


    var _angular_forms__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(
    /*! @angular/forms */
    "./node_modules/@angular/forms/fesm2015/forms.js");
    /* harmony import */


    var _ionic_angular__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(
    /*! @ionic/angular */
    "./node_modules/@ionic/angular/fesm2015/ionic-angular.js");
    /* harmony import */


    var _services_service_service__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(
    /*! ../services/service.service */
    "./src/app/services/service.service.ts");
    /* harmony import */


    var rxjs_index__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(
    /*! rxjs/index */
    "./node_modules/rxjs/index.js");
    /* harmony import */


    var rxjs_index__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(rxjs_index__WEBPACK_IMPORTED_MODULE_5__);
    /* harmony import */


    var src_app_services_util_service__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(
    /*! src/app/services/util.service */
    "./src/app/services/util.service.ts");
    /* harmony import */


    var _angular_router__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(
    /*! @angular/router */
    "./node_modules/@angular/router/fesm2015/router.js");

    var AduancateringPage = /*#__PURE__*/function () {
      function AduancateringPage(formBuilder, navCtrl, loadingController, modalController, platform, toastController, serviceService, router, util) {
        _classCallCheck(this, AduancateringPage);

        this.formBuilder = formBuilder;
        this.navCtrl = navCtrl;
        this.loadingController = loadingController;
        this.modalController = modalController;
        this.platform = platform;
        this.toastController = toastController;
        this.serviceService = serviceService;
        this.router = router;
        this.util = util;
        this.authenticationState = new rxjs_index__WEBPACK_IMPORTED_MODULE_5__["ReplaySubject"]();
        this.validations = {
          'lokasi': [{
            type: 'required',
            message: 'lokasi harus diisi.'
          }],
          'deskripsi': [{
            type: 'required',
            message: 'deskripsi harus diisi.'
          }],
          'kritik_saran': [{
            type: 'required',
            message: 'kritik dan saran harus diisi.'
          }]
        };
      }

      _createClass(AduancateringPage, [{
        key: "ngOnInit",
        value: function ngOnInit() {
          this.FormAduanCatering = this.formBuilder.group({
            lokasi: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])),
            kritik_saran: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required])),
            deskripsi: new _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormControl"]('', _angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].compose([_angular_forms__WEBPACK_IMPORTED_MODULE_2__["Validators"].required]))
          });
        }
      }, {
        key: "submitAduanCatering",
        value: function submitAduanCatering() {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee() {
            var _this = this;

            var loading;
            return regeneratorRuntime.wrap(function _callee$(_context) {
              while (1) {
                switch (_context.prev = _context.next) {
                  case 0:
                    _context.next = 2;
                    return this.loadingController.create({
                      message: 'Please wait...'
                    });

                  case 2:
                    loading = _context.sent;
                    _context.next = 5;
                    return loading.present();

                  case 5:
                    this.serviceService.submitaduan(this.FormAduanCatering.value, 'catering/add').subscribe(function (data) {
                      _this.presentToast("Aduan Anda Terkirim");

                      console.log(_this.FormAduanCatering.value);

                      _this.FormAduanCatering.reset();

                      loading.dismiss();
                    }, function (error) {
                      _this.presentToast(error);

                      loading.dismiss();
                    });

                  case 6:
                  case "end":
                    return _context.stop();
                }
              }
            }, _callee, this);
          }));
        }
      }, {
        key: "presentToast",
        value: function presentToast(Message) {
          return tslib__WEBPACK_IMPORTED_MODULE_0__["__awaiter"](this, void 0, void 0, /*#__PURE__*/regeneratorRuntime.mark(function _callee2() {
            var toast;
            return regeneratorRuntime.wrap(function _callee2$(_context2) {
              while (1) {
                switch (_context2.prev = _context2.next) {
                  case 0:
                    _context2.next = 2;
                    return this.toastController.create({
                      message: Message,
                      duration: 2500,
                      position: "bottom"
                    });

                  case 2:
                    toast = _context2.sent;
                    toast.present();

                  case 4:
                  case "end":
                    return _context2.stop();
                }
              }
            }, _callee2, this);
          }));
        }
      }, {
        key: "onBack",
        value: function onBack() {
          this.router.navigate(['catering']);
        }
      }]);

      return AduancateringPage;
    }();

    AduancateringPage.ctorParameters = function () {
      return [{
        type: _angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"]
      }, {
        type: _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"]
      }, {
        type: _services_service_service__WEBPACK_IMPORTED_MODULE_4__["ServiceService"]
      }, {
        type: _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"]
      }, {
        type: src_app_services_util_service__WEBPACK_IMPORTED_MODULE_6__["UtilService"]
      }];
    };

    AduancateringPage = tslib__WEBPACK_IMPORTED_MODULE_0__["__decorate"]([Object(_angular_core__WEBPACK_IMPORTED_MODULE_1__["Component"])({
      selector: 'app-aduancatering',
      template: tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! raw-loader!./aduancatering.page.html */
      "./node_modules/raw-loader/dist/cjs.js!./src/app/aduancatering/aduancatering.page.html"))["default"],
      styles: [tslib__WEBPACK_IMPORTED_MODULE_0__["__importDefault"](__webpack_require__(
      /*! ./aduancatering.page.scss */
      "./src/app/aduancatering/aduancatering.page.scss"))["default"]]
    }), tslib__WEBPACK_IMPORTED_MODULE_0__["__metadata"]("design:paramtypes", [_angular_forms__WEBPACK_IMPORTED_MODULE_2__["FormBuilder"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["NavController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["LoadingController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ModalController"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["Platform"], _ionic_angular__WEBPACK_IMPORTED_MODULE_3__["ToastController"], _services_service_service__WEBPACK_IMPORTED_MODULE_4__["ServiceService"], _angular_router__WEBPACK_IMPORTED_MODULE_7__["Router"], src_app_services_util_service__WEBPACK_IMPORTED_MODULE_6__["UtilService"]])], AduancateringPage);
    /***/
  }
}]);
//# sourceMappingURL=aduancatering-aduancatering-module-es5.js.map