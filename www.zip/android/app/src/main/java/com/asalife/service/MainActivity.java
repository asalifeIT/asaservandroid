package com.asalife.service;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
