import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tgsmaintenance',
  templateUrl: './tgsmaintenance.page.html',
  styleUrls: ['./tgsmaintenance.page.scss'],
})
export class TgsmaintenancePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
