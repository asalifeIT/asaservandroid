import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tugashk',
  templateUrl: './tugashk.page.html',
  styleUrls: ['./tugashk.page.scss'],
})
export class TugashkPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
