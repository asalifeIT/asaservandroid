import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ratingcatering',
  templateUrl: './ratingcatering.page.html',
  styleUrls: ['./ratingcatering.page.scss'],
})
export class RatingcateringPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
