import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ratinghk',
  templateUrl: './ratinghk.page.html',
  styleUrls: ['./ratinghk.page.scss'],
})
export class RatinghkPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
