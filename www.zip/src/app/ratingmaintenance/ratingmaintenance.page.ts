import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-ratingmaintenance',
  templateUrl: './ratingmaintenance.page.html',
  styleUrls: ['./ratingmaintenance.page.scss'],
})
export class RatingmaintenancePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
