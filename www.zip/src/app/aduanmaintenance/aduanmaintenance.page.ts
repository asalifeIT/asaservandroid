import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-aduanmaintenance',
  templateUrl: './aduanmaintenance.page.html',
  styleUrls: ['./aduanmaintenance.page.scss'],
})
export class AduanmaintenancePage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
